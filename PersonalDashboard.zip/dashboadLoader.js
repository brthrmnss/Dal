/**
 * Created by user1 on 7/24/2016.
 */

$(document).ready(setupApp)

//http://www.listjs.com/docs
function setupApp() {


    var options = {
        valueNames: [ 'name', 'born',
            { name: 'url', attr: 'href' },],
       // item: '<li><h3 class="name"></h3><p class="born"></p></li>'
        item: 'task-item'
    };

    var values = [
    /*    {
            name: 'Jonny Strömberg',
            born: 1986
        },
        {
            name: 'Jonas Arnklint',
            born: 1985
        },*/
        {
            name: 'Make Project',
            url: "evernote:///view/1269954/s11/b9bea39f-ac58-42be-8ee0-e3c948002cec/b9bea39f-ac58-42be-8ee0-e3c948002cec/"
        },
        {
            name: 'Make Date',
            url: "evernote:///view/1269954/s11/fe682b44-1253-46ee-a5b2-925640010a0e/fe682b44-1253-46ee-a5b2-925640010a0e/"
        },
        {
            name: 'Daily',
            url: 'evernote:///view/1269954/s11/e8181a13-9270-4b2a-9057-79cc2f338d3b/e8181a13-9270-4b2a-9057-79cc2f338d3b/',
        },
    ];

    var userList = new List('main_tasks', options, values);





    var options = {
        valueNames: [ 'name', 'city' ],
        item: 'hacker-item'
    };

    var values = [
        { name: 'Jonny', city:'Stockholm' }
        , { name: 'Jonas', city:'Berlin' }
    ];

    var hackerList = new List('hacker-list', options, values);

}