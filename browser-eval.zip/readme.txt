run serve.js first



block loading of app on certain domains
require certain domain before loading app

when app loaded ...
try to connect to socket server (3rd)
talk to socket to make things happen


