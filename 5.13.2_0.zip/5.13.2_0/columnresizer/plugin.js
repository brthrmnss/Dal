/**
 * columnresizer/plugin.js
 *
 * This is a customized version of CKEditor's tableresize plugin that
 * has been modified for use with the tinyMCE WYSIWYG Editor.
 *
 * CKEditor's license can be found at: http://ckeditor.com/license
 * tinyMCE's license can be found at: http://www.tinymce.com/license
 */
/*global tinymce:true */

tinymce.PluginManager.add('columnresizer', function (editor) {
	function custSetTimeout(func, milliseconds, scope, args, ownerWindow) {
		if (!ownerWindow) {
			ownerWindow = window;
		}

		if (!scope) {
			scope = ownerWindow;
		}

		return ownerWindow.setTimeout(
			function () {
				if (args) {
					func.apply(scope, [].concat(args));
				} else {
					func.apply(scope);
				}
			}, milliseconds || 0);
	}

	function getWidth(elm) {
		return parseInt(editor.dom.getStyle(elm, 'width', true), 10);
	}

	function getBorderWidth(elm, side) {
		var dom = editor.dom;
		var styleName = 'border-' + side + '-width';
		var computed = dom.getStyle(elm, styleName, true);
		var borderMap = {
			thin : '0px',
			medium : '1px',
			thick : '2px'
		};

		if (computed.indexOf('px') < 0) {
			// Look up keywords.
			if ((computed in borderMap) && (dom.getStyle(elm, 'border-style', true) != 'none')) {
				computed = borderMap[computed];
			} else {
				computed = 0;
			}
		}

		return parseInt(computed, 10);
	}

	// Gets the table row that contains the most columns.
	function getMasterPillarRow(table) {
		var rows = table.rows;
		var maxCells = 0;
		var cellsCount, masterRow, tr;

		for (var i = 0, len = rows.length; i < len; i++) {
			tr = rows[i];
			cellsCount = tr.cells.length;

			if (cellsCount > maxCells) {
				maxCells = cellsCount;
				masterRow = tr;
			}
		}

		return masterRow;
	}

	function buildTableColumnPillars(table) {
		var dom = editor.dom;
		var pillars = [];
		var pillarIndex = -1;

		// Get the raw row element that cointains the most columns.
		var tr = getMasterPillarRow(table);

		// Get the tbody element and position, which will be used to set the
		// top and bottom boundaries.
		var tbody = table.tBodies[0];
		var tbodyPosition = dom.getPos(tbody);

		// Loop through all of master row's cells, building pillars after each one of them.
		for (var i = 0, len = tr.cells.length; i < len; i++) {
			// Both the current cell and the successive one will be used in the
			// pillar size calculation.
			var td = tr.cells[i];
			var nextTd = tr.cells[i + 1];

			pillarIndex += parseInt(dom.getAttrib(td, 'colspan'), 10) || 1;

			// Calculate the pillar boundary positions.
			var pillarLeft, pillarRight, pillarWidth;
			var x = dom.getPos(td).x;

			// Calculate positions based on the current cell.
			pillarLeft = x + td.offsetWidth - getBorderWidth(td, 'right') - 1;
			// console.log('pillarLeft = ' + pillarLeft);

			// Calculate positions based on the next cell, if available.
			if (nextTd) {
				x = dom.getPos(nextTd).x;
				pillarRight = x + getBorderWidth(nextTd, 'left') + 1;
			}
			// Otherwise calculate positions based on the table (for last cell).
			else {
				x = dom.getPos(table).x;
				pillarRight = x + table.offsetWidth + 1;
			}
			// console.log('pillarRight = ' + pillarRight);

			pillarWidth = Math.max(pillarRight - pillarLeft, 4);
			// console.log('pillarWidth = ' + pillarWidth);

			// The pillar should reflect exactly the shape of the hovered
			// column border line.
			pillars.push({
				table : table,
				index : pillarIndex,
				x : pillarLeft,
				y : tbodyPosition.y,
				width : pillarWidth,
				height : tbody.offsetHeight
			});
		}

		return pillars;
	}

	function getPillarAtPosition(pillars, positionX) {
		for (var i = 0, len = pillars.length; i < len; i++) {
			var pillar = pillars[i];

			if (positionX >= pillar.x && positionX <= (pillar.x + pillar.width)) {
				return pillar;
			}
		}

		return null;
	}

	function cancel(e) {
		e.preventDefault();
	}

	function buildTableMap(table) {
		var aRows = table.rows;
		var aMap = [];

		// Row and Column counters.
		var r = -1;
		for (var i = 0; i < aRows.length; i++) {
			r++;

			if (!aMap[r]) {
				aMap[r] = [];
			}

			var c = -1;
			for (var j = 0; j < aRows[i].cells.length; j++) {
				var oCell = aRows[i].cells[j];
				c++;

				while (aMap[r][c]) {
					c++;
				}

				var iColSpan = isNaN(oCell.colSpan) ? 1 : oCell.colSpan;
				var iRowSpan = isNaN(oCell.rowSpan) ? 1 : oCell.rowSpan;
				for (var rs = 0; rs < iRowSpan; rs++) {
					if (!aMap[r + rs]) {
						aMap[r + rs] = [];
					}

					for (var cs = 0; cs < iColSpan; cs++) {
						aMap[r + rs][c + cs] = aRows[i].cells[j];
					}
				}

				c += iColSpan - 1;
			}
		}

		return aMap;
	}

	// Constructor function that exposes only 2 methods
	function ColumnResizer(editor) {
		var self = this;
		var dom = editor.dom;
		var pillar, resizer, isResizing, startOffset, currentShift;
		var leftSideCells, rightSideCells, leftShiftBoundary, rightShiftBoundary;
		var editableDoc = editor.getDoc();
		var rootElement = editor.getBody();

		function detach() {
			pillar = null;
			currentShift = 0;
			isResizing = 0;

			dom.unbind(editableDoc, 'mouseup', onMouseUp);
			dom.unbind(document, 'mouseup', onMouseUp);

			dom.unbind(resizer, 'mousemove', onMouseMove);
			dom.unbind(resizer, 'mousedown', onMouseDown);

			rootElement.style.cursor = 'auto';
			$(resizer).hide(); //using jQuery
		}

		function resizeStart() {
			// Before starting to resize, figure out which cells to change
			// and the boundaries of this resizing shift.
			var columnIndex = pillar.index;
			var map = buildTableMap(pillar.table);
			var leftColumnCells = [];
			var rightColumnCells = [];
			var leftMinSize = 5000;
			var rightMinSize = leftMinSize;

			for (var i = 0, len = map.length; i < len; i++) {
				var row = map[i];
				var leftCell = row[columnIndex];
				var rightCell = row[columnIndex + 1];

				if (!leftCell || !rightCell || leftCell !== rightCell) {
					if (leftCell) {
						leftMinSize = Math.min(leftMinSize, getWidth(leftCell));
					}
					if (rightCell) {
						rightMinSize = Math.min(rightMinSize, getWidth(rightCell));
					}
					leftColumnCells.push(leftCell);
					rightColumnCells.push(rightCell);
				}
			}

			// Cache the list of cells to be resized.
			leftSideCells = leftColumnCells;
			rightSideCells = rightColumnCells;

			// Cache the resize limit boundaries.
			leftShiftBoundary = pillar.x - leftMinSize;
			rightShiftBoundary = pillar.x + rightMinSize;

			resizer.style.opacity = '0.5';
			startOffset = parseInt(editor.dom.getStyle(resizer, 'left'), 10);
			currentShift = 0;
			isResizing = 1;

			editor.dom.bind(resizer, 'mousemove', onMouseMove);

			// Prevent the native drag behavior otherwise 'mousemove' won't fire.
			editor.on('dragstart', cancel);
		}

		function resizeEnd() {
			isResizing = 0;
			resizer.style.opacity = '0';

			if (currentShift) {
				resizeColumn();
			}

			var table = pillar.table;
			setTimeout(function () {
				$(table).removeData();
			}, 0);

			editor.on('dragstart', cancel);
		}

		function resizeColumn() {
			var cellsCount = leftSideCells.length;

			// Perform the actual resize to table cells, only for those by side of the pillar.
			for (var i = 0; i < cellsCount; i++) {
				var leftCell = leftSideCells[i];
				var rightCell = rightSideCells[i];
				var table = pillar.table;

				// Defer the resizing to avoid any interference among cells.
				custSetTimeout(function (leftCell, leftOldWidth, rightCell, rightOldWidth, tableWidth, sizeShift) {
					var temp;
					var dom = editor.dom;

					// 2px is the minimum valid width.
					if (leftCell) {
						temp = Math.max(leftOldWidth + sizeShift, 1);
						dom.setStyle(leftCell, 'width', temp + 'px');
					}
					if (rightCell) {
						temp = Math.max(rightOldWidth - sizeShift, 1);
						dom.setStyle(rightCell, 'width', temp + 'px');
					}

					// If we're in the last cell, we need to resize the table as well.
					if (tableWidth) {
						temp = (tableWidth + sizeShift);
						dom.setStyle(table, 'width', temp + 'px');
					}

					editor.fire('shadeSaveBtn');
					editor.undoManager.add();

				}, 0, this, [
						leftCell, leftCell && getWidth(leftCell),
						rightCell, rightCell && getWidth(rightCell),
						(!leftCell || !rightCell) && (getWidth(table) + getBorderWidth(table, 'left') + getBorderWidth(table, 'right')),
						currentShift
					]
				);
			}
		}

		function onMouseDown(e) {
			cancel(e);

			// Remove data-mce-selected from all elements since they might have been copied using Ctrl+c/v
			tinymce.each(editor.dom.select('*[data-mce-selected],*[data-mce-selected]'), function (elm) {
				elm.removeAttribute('data-mce-selected');
			});
			// editor.fire('hide');

			resizeStart();
			editor.dom.bind(editableDoc, 'mouseup', onMouseUp, this);
		}

		function onMouseUp() {
			// e.removeListener();
			editor.dom.unbind(editableDoc, 'mouseup', onMouseUp);
			editor.dom.unbind(document, 'mouseup', onMouseUp);

			resizeEnd();
		}

		function onMouseMove(e) {
			move(e.pageX);
		}

		resizer = document.createElement('div');

		// Hide resizer when viewed in code editor and
		// ensure that the resizer gets removed when saving to Evernote
		resizer.setAttribute('data-mce-bogus', 'all');

		resizer.className = 'column-resizer';
		resizer.contentEditable = false;
		resizer.unSelectable = 'on';
		resizer.style.cssText = 'position: absolute; cursor: e-resize; filter: alpha(opacity=0); opacity: 0; ' +
			'padding: 0; background-color: #004; background-image: none; border: 0px none; z-index: 10;';

		// Clean DOM when editor is destroyed.
		editor.on('destroy', function () {
			resizer.remove();
		});

		// Place the resizer at end of body, but before any footnotes container
		if (rootElement.lastChild.title === 'footnotes-container') {
			rootElement.insertBefore(resizer, rootElement.lastChild);
		} else {
			rootElement.appendChild(resizer);
		}

		self.attachTo = function (targetPillar) {
			// Accept only one pillar at a time.
			if (isResizing) {
				return;
			}

			pillar = targetPillar;

			resizer.style.width = targetPillar.width + 'px';
			resizer.style.height = targetPillar.height + 'px';
			resizer.style.left = targetPillar.x + 'px';
			resizer.style.top = targetPillar.y + 'px';

			editor.dom.bind(resizer, 'mousedown', onMouseDown, this);

			rootElement.style.cursor = 'e-resize';

			// Display the resizer to receive events but don't show it,
			// only change the cursor to resizable shape.
			$(resizer).show(); //using jQuery
		};

		var move = self.move = function (posX) {
			var resizerNewPosition;

			if (!pillar) {
				return 0;
			}

			if (!isResizing && (posX < pillar.x || posX > (pillar.x + pillar.width))) {
				detach();
				return 0;
			}

			resizerNewPosition = posX - Math.round(resizer.offsetWidth / 2);

			if (isResizing) {
				if (resizerNewPosition == leftShiftBoundary || resizerNewPosition == rightShiftBoundary) {
					return 1;
				}

				resizerNewPosition = Math.max(resizerNewPosition, leftShiftBoundary);
				resizerNewPosition = Math.min(resizerNewPosition, rightShiftBoundary);

				currentShift = resizerNewPosition - startOffset;
			}

			resizer.style.left = resizerNewPosition + 'px';

			return 1;
		};
	}

	function clearPillarsCache(e) {
		var target = e.target;
		var dom = editor.dom;
		var dest, table, $table;

		if (e.type == 'mouseout') {
			// Bypass internal mouse move.
			if (!dom.is(target, 'table')) {
				return;
			}

			dest = e.toElement;
			while (dest && (dest !== target) && !dom.is(dest, 'body')) {
				dest = dest.parentNode;
			}
			if (!dest || (dest === target)) {
				return;
			}
		}

		table = dom.getParent(target, 'table');
		$table = $(table);
		$table.removeData();
		// e.removeListener();
		$table.off('mouseout', clearPillarsCache);
		$table.off('mousedown', clearPillarsCache);
		// resizer.unbind().html('').remove();
	}

	editor.on('init', function () {
		var resizer;

		editor.on('mousemove', function (e) {
			var target = e.target;
			var pageX = e.pageX;
			var dom = editor.dom;
			var table, $table, pillars, pillar;

			// If we're already attached to a pillar, simply move the resizer.
			if (resizer && resizer.move(pageX)) {
				cancel(e);
				return;
			}

			// Considering table, tr, td, tbody but nothing else.
			if (!dom.is(target, 'table') && !dom.getParent(target, 'tbody')) {
				return;
			}

			table = dom.getParent(target, 'table');
			$table = $(table);
			pillars = $table.data('an-table-pillars');

			if (!pillars) {
				// Cache table pillars calculation result.
				$table.data('an-table-pillars', (pillars = buildTableColumnPillars(table)));
				$table.on('mouseout', clearPillarsCache);
				$table.on('mousedown', clearPillarsCache);
			}

			pillar = getPillarAtPosition(pillars, pageX);
			if (pillar) {
				if (!resizer) {
					resizer = new ColumnResizer(editor);
				}

				resizer.attachTo(pillar);
			}
		});

		// Remove table data from all tables when toggling sidenotes view and
		// collapsing/uncollapsing list items
		editor.on('clearTableData', function () {
			if (resizer) {
				$(editor.dom.select('table')).removeData();
			}
		});

		// Instantiate a new resizer upon an undo or redo or source code change
		editor.on('undo redo srcCode', function () {
			if (editor.dom.select('table').length) {
				resizer = new ColumnResizer(editor);
			}
		});
	});
});
