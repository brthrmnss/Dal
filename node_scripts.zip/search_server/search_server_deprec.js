// server.js

// BASE SETUP
// =============================================================================

// call the packages we need
var express    = require('express'); 		// call express
var app        = express(); 				// define our app using express
var bodyParser = require('body-parser');
var mysql      = require('mysql');
var cookieParser = require('cookie-parser'); // the session is stored in a cookie, so we use this to parse it
var rh = require('rhelpers');

var cluster_settings = rh.loadRServerConfig(true);

//console.log( cluster_settings );


var connection = mysql.createConnection({
    host     : cluster_settings.general_mysql_ip,
    database	: cluster_settings.general_mysql_databasename,
    user     : cluster_settings.general_mysql_user,
    password : cluster_settings.general_mysql_pass
});

// configure app to use bodyParser()
// this will let us get the data from a POST
app.use(bodyParser());
app.use(cookieParser());

var port = process.env.PORT || 33310; 		// set our port
//var port = cluster_settings.general_mysql_port;


// REGISTER OUR ROUTES -------------------------------
var api_router = express.Router();


// ROUTES FOR OUR API
// =============================================================================

// all requests
api_router.use(function(req, res, next) {
    console.log('Something is happening.yo');
    /*
    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', cluster_settings.server_hostname);

    //var origin = cors.origin.indexOf(req.header('host').toLowerCase()) > -1 ? req.headers.origin : cors.default;
    var origin = null;
    if ( req.header('origin') != null && req.header('origin').toLowerCase().indexOf(cluster_settings.searchserver_hostname)
        == 0 ) {
        origin =  req.header('origin');
    }
    var hostnameWithoutColon = cluster_settings.searchserver_hostname.split('://')[1];
    if (  req.header('origin') != null && req.header('origin').toLowerCase().indexOf(hostnameWithoutColon)
        == 0 ) {
        origin =  req.header('origin');
    }
    res.header("Access-Control-Allow-Origin", origin);
*/

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);



    rh.validateOrigins(req, res, true);

    next(); // make sure we go to the next routes and don't stop here
});


api_router.get('/', function generalRoute(req, res) {
    var sessioninfo = req.cookies;
    res.json({ message: 'hooray! welcome to our root!' });
    console.log(  "someone is coming in", sessioninfo.filehosting );
});

api_router.route('/medialookup:media_id').get(function(req,res){ // domain/api/medialookup:id
    var sessionid_cookie = req.cookies.filehosting,
        sessionid_querystr = req.query.sessionid,
        sessionid = ( typeof( sessionid_cookie ) != "undefined" )? sessionid_cookie : sessionid_querystr;

    var databaseIDofMedia = sanitizeSearchKeyword( req.params.media_id );

    isUserLoggedIn( sessionid, databaseIDofMedia, res, doSpotSearch );

    return true;

});

api_router.route('/quicksearch').get(function(req,res){ // domain/api/quicksearch?name=xxx&season=xxxx&episode=xxx&year=xxx&server_id=xxx
    var sessionid_cookie = req.cookies.filehosting,
        sessionid_querystr = req.query.sessionid,
        sessionid = ( typeof( sessionid_cookie ) != "undefined" )? sessionid_cookie : sessionid_querystr;

    var req_searchterms = {
        name    : sanitizeSearchKeyword( req.param('name') ),
        season  : sanitizeSearchKeyword( req.param('season') ),
        episode : sanitizeSearchKeyword( req.param('episode') ),
        year    : sanitizeSearchKeyword( req.param('year') ),
        server  : sanitizeSearchKeyword( req.param('server') )
    }

    isUserLoggedIn( sessionid, req_searchterms, res, doQuickSearch );

    return true;

});

api_router.route('/search:keyword').get(function(req,res){ // domain/api/search:keyword
    var sessionid_cookie = req.cookies.filehosting,
        sessionid_querystr = req.query.sessionid,
        sessionid = ( typeof( sessionid_cookie ) != "undefined" )? sessionid_cookie : sessionid_querystr;

    var search_keyword = sanitizeSearchKeyword( req.params.keyword );

    isUserLoggedIn( sessionid, search_keyword, res, doFullSearch );
    //console.log('WARNING: Make users login ',sessionid_cookie,sessionid_querystr, req.body);
    //doFullSearch(search_keyword, res);//todo: check for user logged in
    return true;

});

app.use('/api', api_router);


// START THE SERVER -------------------------------

app.listen(port);
console.log('Magic happens on port ' + port);


//SEARCH FUNCTIONS -------------------------------

function doSpotSearch( databaseIDofMedia , res){
    var query_findfiles = 'SELECT file.originalFilename, file.shortUrl , file.fileType, file.extension, file.fileSize , file.uploadedDate , file.statusId , file.visits FROM file AS file WHERE id= \'' + databaseIDofMedia + '\' LIMIT 1';

    performQuery( query_findfiles, databaseIDofMedia, res, sendJSONResponse);
}


function doQuickSearch( search_obj , res ){ //name episode# season# year
    var query_findfiles = 'SELECT file.id, file.originalFilename, file.shortUrl , file.fileType, file.extension, file.fileSize , file.uploadedDate , file.statusId , file.visits FROM file AS file WHERE originalFilename LIKE "%' + search_obj.name + '%' + search_obj.season + '%' + search_obj.episode + '%' + search_obj.year + '%" LIMIT 1';

    performQuery( query_findfiles, search_obj, res, sendJSONResponse);
}


function doFullSearch( search_keyword , res){
    //search for file name if starts with tt
    if (search_keyword.slice(0,2)=='tt') {
        var query_findfiles = 'SELECT file.id, file.originalFilename, file.shortUrl , file.fileType, file.extension, file.fileSize , file.uploadedDate , file.statusId , file.visits FROM file AS file WHERE localFilePath LIKE "%'+search_keyword+'%" LIMIT 100';

        performQuery( query_findfiles, search_keyword, res, sendJSONResponse);
        return;
    }

    var query_findfiles = 'SELECT file.id, file.originalFilename, file.shortUrl , file.fileType, file.extension, file.fileSize , file.uploadedDate , file.statusId , file.visits FROM file AS file WHERE originalFilename LIKE "%'+search_keyword+'%" LIMIT 100';

    performQuery( query_findfiles, search_keyword, res, sendJSONResponse);
}

