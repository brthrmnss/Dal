/**
 * Created by user on 6/28/15.
 * This is a re-write of the regular server tha supports login and has a test
 */

var shelpers = require('shelpers');
var sh = shelpers.shelpers;
var EasyRemoteTester = shelpers.EasyRemoteTester;

var rh = require('rhelpers');
//rh.requireSequelizeV2_();
var mysql      = require('mysql');
var RestHelperSQLTest = require('shelpers').RestHelperSQLTest;
var cQS = require('./../credentials_server/CredentialServerQuickStartHelper').CredentialServerQuickStartHelper;
var LoginAPIConsumerService = cQS.LoginAPIConsumerService

function SearchServer2() {
    var p = SearchServer2.prototype;
    p = this;
    var self = this;
    p.init = function init(url, appCode) {
        var settings = rh.loadRServerConfig(true);
        self.settings = settings;

        var connection = mysql.createConnection({
            host        : settings.mysql.ip,
            port        : settings.mysql.port,
            database    : settings.mysql.databasename,
            user        : settings.mysql.user,
            password    : settings.mysql.pass
        });
        self.connection = connection;


        self.login =   self.settings.search.login  ;
        // self.login = false;
        self.config();
        self.cQS = new cQS();
        sh.waitXSecs(1,self.test);
        return;
    }

    p.config = function config(url, appCode) {
        var cPSettings = {}//settings.contentProviderAPI;
        self.cPSettings = cPSettings;
        cPSettings = {
            port: self.settings.search.port
        };

        cPSettings.portProducer = self.settings.loginAPI.port;
        cPSettings.dirSession = self.settings.global.dir_session;
        cPSettings.fxValidateOrigin = rh.validateOrigins;

        //Req: To Set cookies, set on IP address and domain name
        cPSettings.fullUrl = self.settings.ip + ':' + self.settings.search.port

        //create a new server for contentProviderAPI
        if (self.login == true) {
            var c = new LoginAPIConsumerService();
            c.startExampleCredentialsAPIConsumerService2(cPSettings);
            self.server = c.server;
        } else {
            var express    = require('express'); 		// call express
            var app        = express(); 				// define our app using express
            //app.use(bodyParser());
            //app.use(cookieParser());
            app.listen(self.settings.search.port);
            console.log('self', self.settings.search.port)
            app.use(function topMiddleware_AllowCrossDomain(req, res, next) {
                rh.validateOrigins(req,res, true);
                next();
            });
            self.server = app
        }

        self.createRoutes();
    }

    self.createRoutes = function createRoutes() {

        var server = self.server;

      /*  server.get('/api/medialookup:media_id', function(req,res){ // domain/api/medialookup:id
            var sessionid_cookie = req.cookies.filehosting,
                sessionid_querystr = req.query.sessionid,
                sessionid = ( typeof( sessionid_cookie ) != "undefined" )? sessionid_cookie : sessionid_querystr;

            var databaseIDofMedia = sanitizeSearchKeyword( req.params.media_id );

            isUserLoggedIn( sessionid, databaseIDofMedia, res, doSpotSearch );

            return true;

        });*/

/*
        server.get('/api/quicksearch', function(req,res){ // domain/api/quicksearch?name=xxx&season=xxxx&episode=xxx&year=xxx&server_id=xxx
            var sessionid_cookie = req.cookies.filehosting,
                sessionid_querystr = req.query.sessionid,
                sessionid = ( typeof( sessionid_cookie ) != "undefined" )? sessionid_cookie : sessionid_querystr;

            var req_searchterms = {
                name    : sanitizeSearchKeyword( req.param('name') ),
                season  : sanitizeSearchKeyword( req.param('season') ),
                episode : sanitizeSearchKeyword( req.param('episode') ),
                year    : sanitizeSearchKeyword( req.param('year') ),
                server  : sanitizeSearchKeyword( req.param('server') )
            }

            isUserLoggedIn( sessionid, req_searchterms, res, doQuickSearch );

            return true;

        });
        */

        server.get('/api/search:keyword', function onFullSearch(req,res){
            var search_keyword = sanitizeSearchKeyword( req.params.keyword );

            console.log('req', req.query.yay)
            //isUserLoggedIn( sessionid, search_keyword, res, doFullSearch );
            //console.log('WARNING: Make users login ',sessionid_cookie,sessionid_querystr, req.body);
            doFullSearch(search_keyword, res);//todo: check for user logged in
            //return true;
        });


// HELPER FUNCIONS -------------------------------

        function sendJSONResponse( res_obj, return_obj ){

            res_obj.json(return_obj);
        }


        function sanitizeSearchKeyword( keyword ){

            if( typeof keyword == undefined || keyword == null )
                keyword = ' ';

            var search_keyword = keyword.replace(/:/,'').replace(/ /g,'%').replace(/\+/g,'%'); //must remove leading ':' charector and replace spaces and '+' with %

            switch( search_keyword ){
                case "all":case "*":case "":
                search_keyword = '%'
                break;
            }

            return search_keyword;
        }

        function performQuery( query, keyword, res_obj, responseCallback ){

            var return_obj = {
                message : 'no_op',
                params  : keyword ,
                media   : null,
                success : false };

            console.log('--searching for:"', keyword,'" with:', query);
            var connection = self.connection;
            connection.escape( query )
            connection.query( query, function(err, rows, fields) {
                if (err){

                    return_obj.message = 'server_error';
                    return_obj.success = false;

                    console.log(  err );
                }
                else{

                    if ( self.settings.files != null &&
                        self.settings.files.default_server != null )
                    {
                        //prefer files in local db
                        var default_server = self.settings.files.default_server;
                    };
                    var returnRows = [];
                    console.log('result rows', rows)
                    console.log('1. The result has: ', rows.length, ' rows', default_server);
                    if (default_server != null) {
                        for (var i = 0; i < rows.length; i++) {
                            var row = rows[i];
                            if (row.server == null) { //give path to file
                                var mediaServer = default_server; //assume default server
                                var getAddressOfServer = function getAddressOfServer(){
                                    var isIpAddressDefined = row.ipAddress != '' && row.ipAddress != null
                                    if ( isIpAddressDefined ) {
                                        //remove 11111 from code ... not sure why that is here
                                        row.ipAddress =  row.ipAddress.replace(':11111', '')
                                        var isPortSpecified = row.ipAddress.indexOf(':') > 8; //http://1.2.3.4:4454
                                    }
                                    //if ip add is local machine, use local port?
                                    //c3: if port not defined, used default port
                                    //3 types: file on local machine, file on remote machine, file or local with port
                                    if ( isIpAddressDefined ) { //if has port
                                        if ( isPortSpecified == false ) { //if there is a port
                                            mediaServer = row.ipAddress + ':'+self.settings.files.port +'/' + 'api/get_content/'
                                            if (mediaServer.indexOf('http:') != 0) {
                                                mediaServer = 'http://' + mediaServer;
                                            }
                                        } else {
                                            mediaServer = row.ipAddress + '/' + 'api/get_content/'
                                            if (mediaServer.indexOf('http:') != 0) {
                                                mediaServer = 'http://' + mediaServer;
                                            }
                                        }
                                    }

                                    return mediaServer;
                                }


                                mediaServer = getAddressOfServer();

                                row.server = mediaServer; //for debug, but unecessary
                                row.shortUrl = mediaServer + row.shortUrl;
                            };
                            if ( row.shortUrl == null ) {
                                console.log('null shorturl', row);
                                return;
                            }
                            var ending = row.shortUrl.slice(-5);
                            //console.log('dbg', ending, row.shortUrl)
                            //must be directory remove from results
                            if (ending.indexOf('.') == -1) {
                                continue; // cannot return result
                            }
                            //console.log('2', ending, row.shortUrl)
                            if (ending.indexOf('.srt') != -1) {
                                continue;
                            }

                            // console.log('3', ending, row.shortUrl)
                            returnRows.push(row)
                        } ;
                    } ;

                    console.log('2. The result has: ', returnRows.length, ' rows');
                    return_obj = {
                        message : 'here is your media!',
                        params  : keyword ,
                        media   : returnRows,
                        success : true
                    };
                }

                responseCallback( res_obj, return_obj );


            });

        }


        function doFullSearch( search_keyword , res){
          /*  //search for file name if starts with tt
            if (search_keyword.slice(0,2)=='tt') {
                var query_findfiles = 'SELECT file.id, file.originalFilename, file.shortUrl , file.fileType, file.extension, file.fileSize , file.uploadedDate , file.statusId , file.visits FROM file AS file WHERE localFilePath LIKE "%'+search_keyword+'%" LIMIT 25';

                performQuery( query_findfiles, search_keyword, res, sendJSONResponse);
                return;
            }
            //TODO: remove if not needed
*/
            var query_findfiles = 'SELECT file.id, file.originalFilename, file.shortUrl , file.ipAddress, file.fileType, file.extension, file.fileSize , file.uploadedDate , file.statusId , file.visits  FROM file AS file '+
                ' WHERE localFilePath LIKE "%'+search_keyword+'%" ' +
                'ORDER BY originalFilename' +' LIMIT 100';
            //query_findfiles += ' ' + 'ORDER BY originalFilename'
            performQuery( query_findfiles, search_keyword, res, sendJSONResponse);
        }

        //media//media/sda/finished/Root/media/tv_seasons/tt0944947/Game_of_Thrones_Season_1/Game.of.Thrones.S01.720p.BluRay.x264.ShAaNiG/Game.of.Thrones.S01.720p.BluRay.x264.ShAaNiG/Game.of.Thrones.S01E01.720p.BluRay.500MB.ShAaNiG.com.mkv
        //media//media/sda/finished/Root/media/tv_seasons/Game_of_Thrones_Season_2/Game.of.Thrones.S01.720p.BluRay.x264.ShAaNiG/Game.of.Thrones.S01.720p.BluRay.x264.ShAaNiG/Game.of.Thrones.S01E01.720p.BluRay.500MB.ShAaNiG.com.mkv
    }


    p.test = function test() {
        function testContentProviderAPIInterface(fxDone) {

            var c = sh.clone(self.settings.search)
            c.fxDone = fxDone;
            var t = EasyRemoteTester.create('test search server API', c);


            var urls = {}
            urls.search = t.utils.createTestingUrl('api/search');

            urls.verifyConsumer = t.utils.createTestingUrl('api/verify');
            t.settings.portOverride = self.settings.loginAPI.port;
            urls.login = t.utils.createTestingUrl('api/login');
            t.settings.portOverride = null;


            t.wait(5)
            if ( self.login != false ) {

                t.add(function doSearchWithNoLogin() {
                        t.quickRequest( urls.search,
                            'get', result, {originalFilename: "randomTask"})
                        function result(body) {
                            console.log(body);
                            t.assert(body.success==false, 'no ok');
                            t.cb();
                        }
                    }
                );

                self.cQS.testUtils.loginFail(t, urls.login, 'mark', 'randomTask')
                self.cQS.testUtils.login(t, urls.login, 'mark', 'randomTask2')
                self.cQS.testUtils.verifyKey(t, urls.verifyConsumer, t.key)
            }
            var query = 'e'
            t.add(function doSearchAfterLogin() {
                    t.quickRequest( urls.search+':'+ query,
                        'get', result   )
                    function result(body) {
                        console.log('result', body.media.length, body)
                        t.assert(body.media.length >=0, 'post-verify did not let me do a search .. not enough');
                        t.cb();
                    }
                }
            );

            function defineX() {
                t.add(function createMovie_to_search() {
                        t.quickRequest(urls.search,
                            'get', result, {originalFilename: 'jack.mp4'});
                        function result(body) {
                            console.log('body', body);
                            t.data.idOfFakeMovie = body;

                            // t.content = body[0];
                            // asdf.g
                            if (body.success == false) {
                                throw 'not logged in anymore';
                            }
                            ;
                            t.assert(parseInt(body) > 0, 'could not create new content item .... ');
                            t.cb();
                        }
                    }
                );


                t.add(function doSearchWithLikeInName_VerifySearchWorks() {
                        t.quickRequest(urls.search,
                            'get', result, {originalFilename: {like: "%mp4%"}});
                        function result(body) {
                            console.log('body', body);
                            t.content = body[0];
                            if (body.success == false) {
                                throw 'not logged in anymore';
                            }
                            ;
                            t.assert(body.length > 0, 'post-verify did not let me do a search. Searched for mp4 got back 0 results .... ');
                            t.cb();
                        }
                    }
                );


                t.add(function createMovie_to_search_delete() {
                        t.quickRequest(urls.file.delete + '/' + t.data.idOfFakeMovie,
                            'get', result, t.data.idOfFakeMovie);
                        function result(body) {
                            console.log('body', body);
                            t.data.idOfFakeMovie = body;

                            if (body.success == false) {
                                throw 'not logged in anymore';
                            }
                            ;
                            // t.assert(body.length>0, 'could not create new content item .... ');
                            t.cb();
                        }
                    }
                );


                t.add(function reqMovie() {
                        t.quickRequest(urls.getContent,
                            'get', result, {originalFilename: t.content.src, test: true});
                        /*t.quickRequest( urls.getContent+'/'+t.content.src,
                         'get', result );*/
                        function result(body) {
                            console.log('body', body)
                            t.assert(body == 'test ok', 'could not get that content');
                            t.cb();
                        }
                    }
                );

                sh.fs.resolve = function resolvePath(pathToResolve) {
                    var path = require('path')
                    return path.resolve(pathToResolve);
                }

                sh.convertArgs = sh.convertArgumentsToArray;

                /**
                 * Creates dir path
                 * Why: Don't have to write line breaks
                 * @returns {*|string}
                 */
                sh.fs.makePath = function () {
                    var args = sh.convertArgs(arguments)
                    var path = args.join('/');
                    return path;
                }

                //process.exit()
                t.add(function reqMovie2Download() {
                        //prework to find file
                        var fileTestVid = sh.fs.makePath(__dirname, 'test', 'Test Space (2015)/content.mp4');
                        fileTestVid = sh.fs.resolve(fileTestVid);
                        console.log('file test', fileTestVid)
                        var fs = require('fs')
                        console.log('can find movie to test viewing/downloading?', fs.existsSync(fileTestVid), fs.existsSync(sh.qq(fileTestVid)))


                        t.quickRequest(urls.getContent + '/media/' + fileTestVid,
                            'get', result, {originalFilename: fileTestVid, testFile: true});
                        /*t.quickRequest( urls.getContent+'/'+t.content.src,
                         'get', result );*/
                        function result(body) {
                            console.log('body', body);
                            t.assert(body == 'test- found file - ok', 'could not get that content');
                            t.cb();
                        }
                    }
                );

            }


            /* console.log = function () {
             //return;
             }*/
            var res = {}
            res.ok = function ok(o) {
                console.log('response was', o )
            }

            var req = {}
            req.ok = function ok(o) {
                console.log('response was', o )
            }

            req.query = {
                name:"game",
                season: 2,
                episode: 3
            }
            //self.content.searchItems(req, res)
            //self.find_content(req, res)

            req.method = 'GET'
            req.contentPath = self.settings.files.defaultContent;
            //req.contentPath = 'ritv_requests/a.mp4';
            req.headers = {}
            //contentProvider.sendContent(req, res)

        }


        testContentProviderAPIInterface();
    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return
        }
        sh.sLog(arguments)
    }


}


if (module.parent == null) {
    var f = new SearchServer2();
    f.init();
}


exports.SearchServer2 = SearchServer2;
exports.SSSD = SearchServer2;






