var express    = require('express'); 		// call express
var api_router = express.Router();


// ROUTES FOR OUR API
// =============================================================================

// all requests
api_router.use(function(req, res, next) {
	console.log('Something is happening.yo');
	next(); // make sure we go to the next routes and don't stop here
});


api_router.get('/', function(req, res) {
	res.json({ message: 'hooray! welcome to our api!' });	
});


module.exports = api_router;