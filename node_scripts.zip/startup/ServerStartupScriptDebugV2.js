/**
 * Startup script that uses forever to init all Servers
 * args filename debug_startup (daemon vs console)
 * Starts scripts in debug mode
 * @type {exports|module.exports}
 */
var forever   = require('forever');
var path		= require('path');

//https://github.com/foreverjs/forever-monitor


function ClusterStartupScript() {
	var p = ClusterStartupScript.prototype;
	p = this;
	var self = this;

	p.start = function startUpCluster() {
		self.loadConfigFile();
	}

	/**
	 * Loads startup arguments and config file
	 */
	p.loadConfigFile = function loadConfigFile() {
		var default_file_cluster_config = '../' + 'server_config.json'
		var fileClusterConfig = default_file_cluster_config;

		//arg1 = config_file
		var args = process.argv.splice(2);

		if ( args.length > 0) {
			var potentialConfig= args[0];
			//override default config file
			if ( potentialConfigFile != null && potentialConfigFile != "''"
				&&   potentialConfigFile !=  '') {
				fileClusterConfig = potentialConfigFile;
			}
		}

		self.fileClusterConfig = fileClusterConfig;

		//console.log('debug?',args[0], args[1],  args[2] , args);
		console.log('loading config file', fileClusterConfig)
		var cluster_settings   = require(fileClusterConfig );

		//2nd argument is to debug_startup
		if ( true == true || args[1] === true || args[1] == 'true' ) {
			//override debug setting
			cluster_settings.debug_startup = true
		}

		self.cluster_settings = cluster_settings;

		self.startAllScripts();
	}

	p.startAllScripts = function startAllScripts() {

		try {
			//forever.stopAll();
		} catch ( e ) {}

		//start all scripts
		var countScriptsStarted = 0;
		for ( var idx in self.cluster_settings.scripts ){

			var script_path = self.cluster_settings.scripts[idx];
			var path_script = script_path;

			//convert relative paths to absolute
			if( script_path.charAt(0) !== '/' ) {
				script_path = path.normalize(__dirname + '/../../' + script_path);
			}

			if ( script_path.indexOf('.js')== -1 ) {
				console.log('skipping non-js file', path_script);
				continue;
			}

			if ( path_script.indexOf('`')== 0 ) {
				console.log('skipping', path_script);
				continue;
			}

			console.log( 'starting: ', script_path, self.cluster_settings.debug_startup==true );

			var options = {};
			options.args=[self.fileClusterConfig];
			if ( self.cluster_settings.debug_startup || args[1] == 'debug') {
				options.silent = false;
				options.max = 1
				var child = forever.start( script_path, options );
				self.setupGlobalListener();
				child.on('exit', function (err, event) {
					console.log('your-filename.js has exited after 3 restarts', err.childData.file);
				});

			} else {
				options.silent = false;
				forever.startDaemon( script_path, options );
			}
			countScriptsStarted++
		};

		console.log( ' --- all scripts started' , countScriptsStarted);
	}

	p.setupGlobalListener = function setupGlobalListener() {
		if ( self.createdGlobalListener == null ) {
			self.createdGlobalListener = true;

			process.on('uncaughtException', function(err) {
				console.error('>>>>>>>>>>>', err)
				console.error( err.stack);
			});

		}
	}

	p.proc = function debugLogger() {
		if ( self.silent == true) {
			return
		}
		sh.sLog(arguments)
	}

}

exports.ClusterStartupScript = ClusterStartupScript;

if (module.parent == null) {
	var cluster = new ClusterStartupScript();
	cluster.start();
}








