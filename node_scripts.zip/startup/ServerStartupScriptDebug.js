/**
 * Startup script that uses forever to init all Servers
 * args filename debug_startup (daemon vs console)
 * Starts scripts in debug mode
 * @type {exports|module.exports}
 */
var forever   = require('forever');
var path		= require('path');

//https://github.com/foreverjs/forever-monitor

var ClusterStartupScript = require('./server_startup_script').ClusterStartupScript;

if (module.parent == null) {
	var cluster = new ClusterStartupScript();
	var config = {};
	config.debug = true;
	cluster.init(config);
}








