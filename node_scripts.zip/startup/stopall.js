var forever   = require('forever');
forever.stopAll();
console.log( ' --- all scripts stopped' );