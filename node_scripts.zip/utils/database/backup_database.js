/**
 * Script will export the current database to a file.
 * Does not work.
 *
 */

var rh = require('rhelpers')
var shelpers = require('shelpers');
var sh = shelpers.shelpers;

var sequelize = rh.getSequelize();

var cluster_settings = rh.loadRServerConfig();

var mysql      = require('mysql');
var connection = mysql.createConnection({
    host     : cluster_settings.general_mysql_ip,
    // database	: cluster_settings.general_mysql_databasename,
    user     : cluster_settings.general_mysql_user,
    password : cluster_settings.general_mysql_pass
});

connection.connect(function(err) {
    if (err) {
        console.error('error connecting: ' + err.stack);
        return;
    }
    console.log('connected as id ' + connection.threadId);
    var query = "TRUNCATE  "+
        cluster_settings.mysql.mysql_databasename+".file;"
    console.log('query ' + query);
    connection.query(query,
        function(err, rows) {
            console.log('emptied', err);

        }
    );
});