-- MySQL dump 10.13  Distrib 5.5.46, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: yetidb
-- ------------------------------------------------------
-- Server version	5.5.46-0ubuntu0.14.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Invite_Campaigns`
--

DROP TABLE IF EXISTS `Invite_Campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Invite_Campaigns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(65) DEFAULT NULL,
  `creatorip` varchar(15) DEFAULT NULL,
  `creator` varchar(65) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `dateupdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Invite_Campaigns`
--

LOCK TABLES `Invite_Campaigns` WRITE;
/*!40000 ALTER TABLE `Invite_Campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `Invite_Campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Invites`
--

DROP TABLE IF EXISTS `Invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Invites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invite_code` varchar(65) DEFAULT NULL,
  `level` enum('free user','invited','neophite','paid user','admin') DEFAULT NULL,
  `email` varchar(65) DEFAULT NULL,
  `forumname` varchar(65) DEFAULT NULL,
  `joindate` datetime DEFAULT NULL,
  `trialExpire` datetime DEFAULT NULL,
  `creatorip` varchar(15) DEFAULT NULL,
  `creator` varchar(65) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `dateupdated` datetime NOT NULL,
  `InviteCampaignId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `InviteCampaignId` (`InviteCampaignId`),
  CONSTRAINT `Invites_ibfk_1` FOREIGN KEY (`InviteCampaignId`) REFERENCES `Invite_Campaigns` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Invites`
--

LOCK TABLES `Invites` WRITE;
/*!40000 ALTER TABLE `Invites` DISABLE KEYS */;
/*!40000 ALTER TABLE `Invites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aTables`
--

DROP TABLE IF EXISTS `aTables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aTables` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `imdb_id` varchar(255) DEFAULT NULL,
  `content_id` varchar(255) DEFAULT NULL,
  `progress` varchar(255) DEFAULT NULL,
  `source_node` varchar(255) DEFAULT NULL,
  `id_timestamp` varchar(255) DEFAULT NULL,
  `updated_by_source` varchar(255) DEFAULT NULL,
  `global_updated_at` datetime NOT NULL,
  `version` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7310 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aTables`
--

LOCK TABLES `aTables` WRITE;
/*!40000 ALTER TABLE `aTables` DISABLE KEYS */;
INSERT INTO `aTables` VALUES (7309,'yyy2',NULL,NULL,NULL,NULL,NULL,'b','Sun Jan 24 2016 23:03:54 GMT-0500 (EST)_0.9098230248782784_0.33174589183181524',NULL,'2016-01-25 04:03:54',NULL,NULL,'2016-01-25 04:04:03','2016-01-25 04:04:03');
/*!40000 ALTER TABLE `aTables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bTables`
--

DROP TABLE IF EXISTS `bTables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bTables` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `imdb_id` varchar(255) DEFAULT NULL,
  `content_id` varchar(255) DEFAULT NULL,
  `progress` varchar(255) DEFAULT NULL,
  `source_node` varchar(255) DEFAULT NULL,
  `id_timestamp` varchar(255) DEFAULT NULL,
  `updated_by_source` varchar(255) DEFAULT NULL,
  `global_updated_at` datetime NOT NULL,
  `version` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13930 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bTables`
--

LOCK TABLES `bTables` WRITE;
/*!40000 ALTER TABLE `bTables` DISABLE KEYS */;
INSERT INTO `bTables` VALUES (13929,'yyy2',NULL,NULL,NULL,NULL,NULL,'b','Sun Jan 24 2016 23:03:54 GMT-0500 (EST)_0.9098230248782784_0.33174589183181524',NULL,'2016-01-25 04:03:54',NULL,NULL,'2016-01-25 04:04:03','2016-01-25 04:04:03');
/*!40000 ALTER TABLE `bTables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banned_ips`
--

DROP TABLE IF EXISTS `banned_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banned_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipAddress` varchar(30) NOT NULL,
  `dateBanned` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `banType` varchar(30) NOT NULL,
  `banNotes` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ipAddress` (`ipAddress`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banned_ips`
--

LOCK TABLES `banned_ips` WRITE;
/*!40000 ALTER TABLE `banned_ips` DISABLE KEYS */;
/*!40000 ALTER TABLE `banned_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `btc_payment_addresses`
--

DROP TABLE IF EXISTS `btc_payment_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `btc_payment_addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `btc_address` varchar(36) DEFAULT NULL,
  `private_key` varchar(64) DEFAULT NULL,
  `index` int(11) DEFAULT NULL,
  `status` enum('reserved','available','frozen','parked','error','sweepable') DEFAULT 'available',
  `sweepable` tinyint(1) DEFAULT '0',
  `gen_count` int(11) DEFAULT '0',
  `use_count` int(11) DEFAULT '0',
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `btc_address` (`btc_address`,`private_key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `btc_payment_addresses`
--

LOCK TABLES `btc_payment_addresses` WRITE;
/*!40000 ALTER TABLE `btc_payment_addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `btc_payment_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cTables`
--

DROP TABLE IF EXISTS `cTables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cTables` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `imdb_id` varchar(255) DEFAULT NULL,
  `content_id` varchar(255) DEFAULT NULL,
  `progress` varchar(255) DEFAULT NULL,
  `source_node` varchar(255) DEFAULT NULL,
  `id_timestamp` varchar(255) DEFAULT NULL,
  `updated_by_source` varchar(255) DEFAULT NULL,
  `global_updated_at` datetime NOT NULL,
  `version` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cTables`
--

LOCK TABLES `cTables` WRITE;
/*!40000 ALTER TABLE `cTables` DISABLE KEYS */;
/*!40000 ALTER TABLE `cTables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dTables`
--

DROP TABLE IF EXISTS `dTables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dTables` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `imdb_id` varchar(255) DEFAULT NULL,
  `content_id` varchar(255) DEFAULT NULL,
  `progress` varchar(255) DEFAULT NULL,
  `source_node` varchar(255) DEFAULT NULL,
  `id_timestamp` varchar(255) DEFAULT NULL,
  `updated_by_source` varchar(255) DEFAULT NULL,
  `global_updated_at` datetime NOT NULL,
  `version` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dTables`
--

LOCK TABLES `dTables` WRITE;
/*!40000 ALTER TABLE `dTables` DISABLE KEYS */;
/*!40000 ALTER TABLE `dTables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `download_tracker`
--

DROP TABLE IF EXISTS `download_tracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `download_tracker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_id` int(11) NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `download_username` varchar(65) DEFAULT NULL,
  `date_started` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_finished` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` enum('downloading','finished','error','cancelled') NOT NULL,
  `start_offset` bigint(20) NOT NULL,
  `seek_end` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ip_address` (`ip_address`),
  KEY `date_updated` (`date_updated`),
  KEY `status` (`status`),
  KEY `file_id` (`file_id`),
  KEY `download_username` (`download_username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `download_tracker`
--

LOCK TABLES `download_tracker` WRITE;
/*!40000 ALTER TABLE `download_tracker` DISABLE KEYS */;
/*!40000 ALTER TABLE `download_tracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eTables`
--

DROP TABLE IF EXISTS `eTables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eTables` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `imdb_id` varchar(255) DEFAULT NULL,
  `content_id` varchar(255) DEFAULT NULL,
  `progress` varchar(255) DEFAULT NULL,
  `source_node` varchar(255) DEFAULT NULL,
  `id_timestamp` varchar(255) DEFAULT NULL,
  `updated_by_source` varchar(255) DEFAULT NULL,
  `global_updated_at` datetime NOT NULL,
  `version` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eTables`
--

LOCK TABLES `eTables` WRITE;
/*!40000 ALTER TABLE `eTables` DISABLE KEYS */;
/*!40000 ALTER TABLE `eTables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `originalFilename` varchar(255) NOT NULL,
  `shortUrl` varchar(255) DEFAULT NULL,
  `fileType` varchar(50) DEFAULT NULL,
  `extension` varchar(10) DEFAULT NULL,
  `fileSize` bigint(15) DEFAULT NULL,
  `localFilePath` varchar(255) DEFAULT NULL,
  `ipAddress` varchar(30) DEFAULT NULL,
  `serverName` varchar(30) DEFAULT NULL,
  `machineName` varchar(30) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `totalDownload` int(11) DEFAULT NULL,
  `uploadedIP` varchar(50) DEFAULT NULL,
  `uploadedDate` date DEFAULT NULL,
  `statusId` int(2) DEFAULT NULL,
  `visits` int(11) DEFAULT '0',
  `lastAccessed` date DEFAULT NULL,
  `deleteHash` varchar(32) DEFAULT NULL,
  `folderId` int(11) DEFAULT NULL,
  `serverId` int(11) DEFAULT '1',
  `accessPassword` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shortUrl` (`shortUrl`),
  KEY `originalFilename` (`originalFilename`),
  KEY `fileSize` (`fileSize`),
  KEY `visits` (`visits`),
  KEY `lastAccessed` (`lastAccessed`),
  KEY `extension` (`extension`),
  KEY `userId` (`userId`),
  KEY `statusId` (`statusId`)
) ENGINE=MyISAM AUTO_INCREMENT=705 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file`
--

LOCK TABLES `file` WRITE;
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
INSERT INTO `file` VALUES (700,'Fighter.mpg','media//media/psf/Dropbox/projects/ritv2/videoproject/Code/code-yeti/data/demo_videos/Fighter.mpg','video/mp4','mpg',2187725,'/media/psf/Dropbox/projects/ritv2/videoproject/Code/code-yeti/data/demo_videos/Fighter.mpg','10.211.55.4:11111',NULL,NULL,999,0,'ip_address','2016-04-29',1,0,NULL,'~d?delete_hash',1,1,NULL),(701,'Jellyfish-3-Mbps.mkv','media//media/psf/Dropbox/projects/ritv2/videoproject/Code/code-yeti/data/demo_videos/Jellyfish-3-Mbps.mkv','video/mp4','mkv',22451663,'/media/psf/Dropbox/projects/ritv2/videoproject/Code/code-yeti/data/demo_videos/Jellyfish-3-Mbps.mkv','10.211.55.4:11111',NULL,NULL,999,0,'ip_address','2016-04-29',1,0,NULL,'~d?delete_hash',1,1,NULL),(702,'car-overhead-1.avi','media//media/psf/Dropbox/projects/ritv2/videoproject/Code/code-yeti/data/demo_videos/car-overhead-1.avi','video/mp4','avi',8145868,'/media/psf/Dropbox/projects/ritv2/videoproject/Code/code-yeti/data/demo_videos/car-overhead-1.avi','10.211.55.4:11111',NULL,NULL,999,0,'ip_address','2016-04-29',1,0,NULL,'~d?delete_hash',1,1,NULL),(703,'dock.mp4','media//media/psf/Dropbox/projects/ritv2/videoproject/Code/code-yeti/data/demo_videos/dock.mp4','video/mp4','mp4',1869151,'/media/psf/Dropbox/projects/ritv2/videoproject/Code/code-yeti/data/demo_videos/dock.mp4','10.211.55.4:11111',NULL,NULL,999,0,'ip_address','2016-04-29',1,0,NULL,'~d?delete_hash',1,1,NULL),(704,'oceans.mp4','media//media/psf/Dropbox/projects/ritv2/videoproject/Code/code-yeti/data/demo_videos/oceans.mp4','video/mp4','mp4',23014356,'/media/psf/Dropbox/projects/ritv2/videoproject/Code/code-yeti/data/demo_videos/oceans.mp4','10.211.55.4:11111',NULL,NULL,999,0,'ip_address','2016-04-29',1,0,NULL,'~d?delete_hash',1,1,NULL);
/*!40000 ALTER TABLE `file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_folder`
--

DROP TABLE IF EXISTS `file_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_folder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `folderName` varchar(255) NOT NULL,
  `isPublic` int(1) NOT NULL DEFAULT '0',
  `accessPassword` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_folder`
--

LOCK TABLES `file_folder` WRITE;
/*!40000 ALTER TABLE `file_folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_imdb_info`
--

DROP TABLE IF EXISTS `file_imdb_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_imdb_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  `series` varchar(255) DEFAULT NULL,
  `season` varchar(255) DEFAULT NULL,
  `episode` varchar(255) DEFAULT NULL,
  `imbd_id` int(32) DEFAULT NULL,
  `country` varchar(64) DEFAULT NULL,
  `rating` varchar(16) DEFAULT NULL,
  `genre` varchar(32) DEFAULT NULL,
  `desc` text,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_imdb_info`
--

LOCK TABLES `file_imdb_info` WRITE;
/*!40000 ALTER TABLE `file_imdb_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_imdb_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_server`
--

DROP TABLE IF EXISTS `file_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_server` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serverLabel` varchar(100) NOT NULL,
  `serverType` enum('remote','local','ftp','sftp','direct') DEFAULT NULL,
  `ipAddress` varchar(255) NOT NULL,
  `ftpPort` int(11) NOT NULL DEFAULT '21',
  `ftpUsername` varchar(50) NOT NULL,
  `ftpPassword` varchar(50) DEFAULT NULL,
  `sftpHost` varchar(255) NOT NULL,
  `sftpPort` int(11) NOT NULL DEFAULT '22',
  `sftpUsername` varchar(50) NOT NULL,
  `sftpPassword` varchar(50) NOT NULL,
  `statusId` int(11) NOT NULL DEFAULT '1',
  `storagePath` varchar(255) DEFAULT NULL,
  `fileServerDomainName` varchar(255) DEFAULT NULL,
  `scriptPath` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `statusId` (`statusId`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_server`
--

LOCK TABLES `file_server` WRITE;
/*!40000 ALTER TABLE `file_server` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_server_status`
--

DROP TABLE IF EXISTS `file_server_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_server_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_server_status`
--

LOCK TABLES `file_server_status` WRITE;
/*!40000 ALTER TABLE `file_server_status` DISABLE KEYS */;
INSERT INTO `file_server_status` VALUES (1,'disabled'),(2,'active'),(3,'read only');
/*!40000 ALTER TABLE `file_server_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_status`
--

DROP TABLE IF EXISTS `file_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_status`
--

LOCK TABLES `file_status` WRITE;
/*!40000 ALTER TABLE `file_status` DISABLE KEYS */;
INSERT INTO `file_status` VALUES (1,'active'),(2,'user removed'),(3,'admin removed'),(4,'copyright removed'),(5,'system expired');
/*!40000 ALTER TABLE `file_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `originalFilename` varchar(255) NOT NULL DEFAULT '',
  `shortUrl` varchar(255) DEFAULT NULL,
  `fileType` varchar(255) DEFAULT NULL,
  `extension` varchar(255) DEFAULT NULL,
  `fileSize` bigint(20) DEFAULT NULL,
  `localFilePath` varchar(255) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `totalDownload` int(11) DEFAULT NULL,
  `uploadedIP` varchar(255) DEFAULT NULL,
  `uploadedDate` datetime DEFAULT NULL,
  `statusId` int(2) DEFAULT NULL,
  `visits` int(11) DEFAULT '0',
  `lastAccessed` datetime DEFAULT NULL,
  `deleteHash` varchar(255) DEFAULT NULL,
  `folderId` int(11) DEFAULT NULL,
  `serverId` int(11) DEFAULT '1',
  `adminNotes` text NOT NULL,
  `accessPassword` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `languageName` varchar(255) NOT NULL,
  `isLocked` int(1) NOT NULL,
  `isActive` int(1) NOT NULL DEFAULT '1',
  `flag` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language`
--

LOCK TABLES `language` WRITE;
/*!40000 ALTER TABLE `language` DISABLE KEYS */;
INSERT INTO `language` VALUES (1,'English (en)',1,1,'us');
/*!40000 ALTER TABLE `language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language_content`
--

DROP TABLE IF EXISTS `language_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `languageKeyId` varchar(150) NOT NULL,
  `languageId` int(11) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1062 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language_content`
--

LOCK TABLES `language_content` WRITE;
/*!40000 ALTER TABLE `language_content` DISABLE KEYS */;
INSERT INTO `language_content` VALUES (581,'1',1,'home'),(582,'3',1,'banned words / urls'),(583,'4',1,'admin users'),(584,'5',1,'banned ips'),(585,'6',1,'site settings'),(586,'7',1,'languages'),(587,'8',1,'logout'),(588,'9',1,'Language Details'),(589,'10',1,'Are you sure you want to remove this IP ban?'),(590,'11',1,'Are you sure you want to update the status of this user?'),(591,'12',1,'view'),(592,'13',1,'disable'),(593,'14',1,'enable'),(594,'15',1,'Are you sure you want to remove this banned word?'),(595,'16',1,'IP address appears to be invalid, please try again.'),(596,'17',1,'IP address is already in the blocked list.'),(597,'18',1,'There was a problem inserting/updating the record, please try again later.'),(598,'19',1,'Banned word is already in the list.'),(599,'20',1,'Language already in the system.'),(600,'21',1,'Username must be between 6-16 characters long.'),(601,'22',1,'Password must be between 6-16 characters long.'),(602,'23',1,'Please enter the firstname.'),(603,'24',1,'Please enter the lastname.'),(604,'25',1,'Please enter the email address.'),(605,'26',1,'The email address you entered appears to be invalid.'),(606,'27',1,'Copyright'),(607,'28',1,'Support'),(608,'30',1,'Admin Panel'),(609,'31',1,'Logged in as'),(610,'32',1,'To ban an IP Address <a href=\"#\" onClick=\"displayBannedIpPopup(); return false;\">click here</a> or delete any existing ones below'),(611,'33',1,'Add banned IP address'),(612,'34',1,'remove'),(613,'35',1,'IP Address'),(614,'36',1,'Ban From'),(615,'37',1,'Notes'),(616,'38',1,'Add Banned IP'),(617,'39',1,'There was an error submitting the form, please try again later.'),(618,'40',1,'Enter IP Address details'),(619,'41',1,'To ban an word within the original url <a href=\"#\" onClick=\"displayBannedWordsPopup(); return false;\">click here</a> or delete any existing ones below'),(620,'42',1,'Add banned word'),(621,'43',1,'Banned Word'),(622,'44',1,'Date Banned'),(623,'45',1,'Ban Notes'),(624,'46',1,'Action'),(625,'47',1,'Enter Banned Word details'),(626,'48',1,'Use the main navigation above to manage this site. A quick overview of the site can be seen below'),(627,'49',1,'New Files (last 14 days)'),(628,'50',1,'New Files (last 12 months)'),(629,'51',1,'Urls'),(630,'52',1,'active'),(631,'53',1,'disabled'),(632,'54',1,'spam'),(633,'55',1,'expired'),(634,'56',1,'Total active files'),(635,'57',1,'Total disabled files'),(636,'58',1,'Total downloads to all files'),(637,'59',1,'Item Name'),(638,'60',1,'Value'),(639,'61',1,'Manage the available content for the selected language. Click on any of the \'Translated Content\' cells to edit the value.'),(640,'62',1,'Select a language to manage or <a href=\'#\' onClick=\'displayAddLanguagePopup(); return false;\'>add a new one here</a>. NOTE Once translated, to set the site default language go to the <a href=\'settings.php\'>site settings</a> area.'),(641,'63',1,'Language Key'),(642,'64',1,'Default Content'),(643,'65',1,'Translated Content'),(644,'66',1,'Error Changes to this section can not be made within demo mode.'),(645,'67',1,'Manage other languages'),(646,'68',1,'There is no available content.'),(647,'69',1,'select language'),(648,'70',1,'Add Language'),(649,'71',1,'Language Name'),(650,'72',1,'Click on any of the items within the \"Config Value\" column below to edit'),(651,'73',1,'Group'),(652,'74',1,'Config Description'),(653,'75',1,'Config Value'),(654,'76',1,'Filter results'),(655,'77',1,'Double click on any of the users below to edit the account information or <a href=\"#\" onClick=\"displayUserPopup(); return false;\">click here to add a new user</a>'),(656,'78',1,'Add new user'),(657,'79',1,'Username'),(658,'80',1,'Email Address'),(659,'81',1,'Account Type'),(660,'82',1,'Last Login'),(661,'83',1,'Account Status'),(662,'84',1,'Password'),(663,'85',1,'Title'),(664,'86',1,'Firstname'),(665,'87',1,'Lastname'),(666,'88',1,'Enter user details'),(667,'90',1,'Terms &amp; Conditions'),(668,'515',1,'Main Navigation'),(669,'92',1,'Created By'),(670,'94',1,'You are not permitted to upload files on this site.'),(671,'95',1,'There was an error with the url you supplied, please check and try again.'),(672,'96',1,'You can not upload files on this site.'),(673,'97',1,'The date you entered is incorrect.'),(674,'98',1,'That custom short url already exists, please try another.'),(675,'99',1,'There was a problem uploading the file, please try again later.'),(676,'100',1,'This url is access restricted, please enter the password below'),(677,'107',1,'Redirecting to'),(678,'108',1,'please wait'),(679,'109',1,'There was a general site error, please try again later.'),(680,'110',1,'Error'),(681,'153',1,'visits'),(682,'154',1,'created'),(683,'155',1,'Visitors'),(684,'156',1,'Countries'),(685,'157',1,'Top Referrers'),(686,'158',1,'Browsers'),(687,'159',1,'Operating Systems'),(688,'160',1,'last 24 hours'),(689,'161',1,'last 7 days'),(690,'162',1,'last 30 days'),(691,'163',1,'last 12 months'),(692,'164',1,'Hour'),(693,'165',1,'Visits'),(694,'166',1,'Date'),(695,'167',1,'Total visits'),(696,'168',1,'Percentage'),(697,'169',1,'Day'),(698,'170',1,'Month'),(699,'171',1,'Country'),(700,'172',1,'Site'),(701,'173',1,'Browser'),(702,'174',1,'Operating System'),(703,'175',1,'Andorra'),(704,'176',1,'United Arab Emirates'),(705,'177',1,'Afghanistan'),(706,'178',1,'Antigua And Barbuda'),(707,'179',1,'Anguilla'),(708,'180',1,'Albania'),(709,'181',1,'Armenia'),(710,'182',1,'Netherlands Antilles'),(711,'183',1,'Angola'),(712,'184',1,'Antarctica'),(713,'185',1,'Argentina'),(714,'186',1,'American Samoa'),(715,'187',1,'Austria'),(716,'188',1,'Australia'),(717,'189',1,'Aruba'),(718,'190',1,'Azerbaijan'),(719,'191',1,'Bosnia And Herzegovina'),(720,'192',1,'Barbados'),(721,'193',1,'Bangladesh'),(722,'194',1,'Belgium'),(723,'195',1,'Burkina Faso'),(724,'196',1,'Bulgaria'),(725,'197',1,'Bahrain'),(726,'198',1,'Burundi'),(727,'199',1,'Benin'),(728,'200',1,'Bermuda'),(729,'201',1,'Brunei Darussalam'),(730,'202',1,'Bolivia'),(731,'203',1,'Brazil'),(732,'204',1,'Bahamas'),(733,'205',1,'Bhutan'),(734,'206',1,'Botswana'),(735,'207',1,'Belarus'),(736,'208',1,'Belize'),(737,'209',1,'Canada'),(738,'210',1,'The Democratic Republic Of The Congo'),(739,'211',1,'Central African Republic'),(740,'212',1,'Congo'),(741,'213',1,'Switzerland'),(742,'214',1,'Cote Divoire'),(743,'215',1,'Cook Islands'),(744,'216',1,'Chile'),(745,'217',1,'Cameroon'),(746,'218',1,'China'),(747,'219',1,'Colombia'),(748,'220',1,'Costa Rica'),(749,'221',1,'Serbia And Montenegro'),(750,'222',1,'Cuba'),(751,'223',1,'Cape Verde'),(752,'224',1,'Cyprus'),(753,'225',1,'Czech Republic'),(754,'226',1,'Germany'),(755,'227',1,'Djibouti'),(756,'228',1,'Denmark'),(757,'229',1,'Dominica'),(758,'230',1,'Dominican Republic'),(759,'231',1,'Algeria'),(760,'232',1,'Ecuador'),(761,'233',1,'Estonia'),(762,'234',1,'Egypt'),(763,'235',1,'Eritrea'),(764,'236',1,'Spain'),(765,'237',1,'Ethiopia'),(766,'238',1,'European Union'),(767,'239',1,'Finland'),(768,'240',1,'Fiji'),(769,'241',1,'Falkland Islands (Malvinas)'),(770,'242',1,'Federated States Of Micronesia'),(771,'243',1,'Faroe Islands'),(772,'244',1,'France'),(773,'245',1,'Gabon'),(774,'246',1,'United Kingdom'),(775,'247',1,'Grenada'),(776,'248',1,'Georgia'),(777,'249',1,'French Guiana'),(778,'250',1,'Ghana'),(779,'251',1,'Gibraltar'),(780,'252',1,'Greenland'),(781,'253',1,'Gambia'),(782,'254',1,'Guinea'),(783,'255',1,'Guadeloupe'),(784,'256',1,'Equatorial Guinea'),(785,'257',1,'Greece'),(786,'258',1,'South Georgia And The South Sandwich Islands'),(787,'259',1,'Guatemala'),(788,'260',1,'Guam'),(789,'261',1,'Guinea-Bissau'),(790,'262',1,'Guyana'),(791,'263',1,'Hong Kong'),(792,'264',1,'Honduras'),(793,'265',1,'Croatia'),(794,'266',1,'Haiti'),(795,'267',1,'Hungary'),(796,'268',1,'Indonesia'),(797,'269',1,'Ireland'),(798,'270',1,'Israel'),(799,'271',1,'India'),(800,'272',1,'British Indian Ocean Territory'),(801,'273',1,'Iraq'),(802,'274',1,'Islamic Republic Of Iran'),(803,'275',1,'Iceland'),(804,'276',1,'Italy'),(805,'277',1,'Jamaica'),(806,'278',1,'Jordan'),(807,'279',1,'Japan'),(808,'280',1,'Kenya'),(809,'281',1,'Kyrgyzstan'),(810,'282',1,'Cambodia'),(811,'283',1,'Kiribati'),(812,'284',1,'Comoros'),(813,'285',1,'Saint Kitts And Nevis'),(814,'286',1,'Republic Of Korea'),(815,'287',1,'Kuwait'),(816,'288',1,'Cayman Islands'),(817,'289',1,'Kazakhstan'),(818,'290',1,'Lao Peoples Democratic Republic'),(819,'291',1,'Lebanon'),(820,'292',1,'Saint Lucia'),(821,'293',1,'Liechtenstein'),(822,'294',1,'Sri Lanka'),(823,'295',1,'Liberia'),(824,'296',1,'Lesotho'),(825,'297',1,'Lithuania'),(826,'298',1,'Luxembourg'),(827,'299',1,'Latvia'),(828,'300',1,'Libyan Arab Jamahiriya'),(829,'301',1,'Morocco'),(830,'302',1,'Monaco'),(831,'303',1,'Republic Of Moldova'),(832,'304',1,'Madagascar'),(833,'305',1,'Marshall Islands'),(834,'306',1,'The Former Yugoslav Republic Of Macedonia'),(835,'307',1,'Mali'),(836,'308',1,'Myanmar'),(837,'309',1,'Mongolia'),(838,'310',1,'Macao'),(839,'311',1,'Northern Mariana Islands'),(840,'312',1,'Martinique'),(841,'313',1,'Mauritania'),(842,'314',1,'Malta'),(843,'315',1,'Mauritius'),(844,'316',1,'Maldives'),(845,'317',1,'Malawi'),(846,'318',1,'Mexico'),(847,'319',1,'Malaysia'),(848,'320',1,'Mozambique'),(849,'321',1,'Namibia'),(850,'322',1,'New Caledonia'),(851,'323',1,'Niger'),(852,'324',1,'Norfolk Island'),(853,'325',1,'Nigeria'),(854,'326',1,'Nicaragua'),(855,'327',1,'Netherlands'),(856,'328',1,'Norway'),(857,'329',1,'Nepal'),(858,'330',1,'Nauru'),(859,'331',1,'Niue'),(860,'332',1,'New Zealand'),(861,'333',1,'Oman'),(862,'334',1,'Panama'),(863,'335',1,'Peru'),(864,'336',1,'French Polynesia'),(865,'337',1,'Papua New Guinea'),(866,'338',1,'Philippines'),(867,'339',1,'Pakistan'),(868,'340',1,'Poland'),(869,'341',1,'Puerto Rico'),(870,'342',1,'Palestinian Territory'),(871,'343',1,'Portugal'),(872,'344',1,'Palau'),(873,'345',1,'Paraguay'),(874,'346',1,'Qatar'),(875,'347',1,'Reunion'),(876,'348',1,'Romania'),(877,'349',1,'Russian Federation'),(878,'350',1,'Rwanda'),(879,'351',1,'Saudi Arabia'),(880,'352',1,'Solomon Islands'),(881,'353',1,'Seychelles'),(882,'354',1,'Sudan'),(883,'355',1,'Sweden'),(884,'356',1,'Singapore'),(885,'357',1,'Slovenia'),(886,'358',1,'Slovakia (Slovak Republic)'),(887,'359',1,'Sierra Leone'),(888,'360',1,'San Marino'),(889,'361',1,'Senegal'),(890,'362',1,'Somalia'),(891,'363',1,'Suriname'),(892,'364',1,'Sao Tome And Principe'),(893,'365',1,'El Salvador'),(894,'366',1,'Syrian Arab Republic'),(895,'367',1,'Swaziland'),(896,'368',1,'Chad'),(897,'369',1,'French Southern Territories'),(898,'370',1,'Togo'),(899,'371',1,'Thailand'),(900,'372',1,'Tajikistan'),(901,'373',1,'Tokelau'),(902,'374',1,'Timor-Leste'),(903,'375',1,'Turkmenistan'),(904,'376',1,'Tunisia'),(905,'377',1,'Tonga'),(906,'378',1,'Turkey'),(907,'379',1,'Trinidad And Tobago'),(908,'380',1,'Tuvalu'),(909,'381',1,'Taiwan Province Of China'),(910,'382',1,'United Republic Of Tanzania'),(911,'383',1,'Ukraine'),(912,'384',1,'Uganda'),(913,'385',1,'United States'),(914,'386',1,'Uruguay'),(915,'387',1,'Uzbekistan'),(916,'388',1,'Holy See (Vatican City State)'),(917,'389',1,'Saint Vincent And The Grenadines'),(918,'390',1,'Venezuela'),(919,'391',1,'Virgin Islands'),(920,'392',1,'Virgin Islands'),(921,'393',1,'Viet Nam'),(922,'394',1,'Vanuatu'),(923,'395',1,'Samoa'),(924,'396',1,'Yemen'),(925,'397',1,'Mayotte'),(926,'398',1,'Serbia And Montenegro (Formally Yugoslavia)'),(927,'399',1,'South Africa'),(928,'400',1,'Zambia'),(929,'401',1,'Zimbabwe'),(930,'402',1,'Unknown'),(931,'404',1,'Show disabled'),(932,'405',1,'register'),(933,'408',1,'Login'),(934,'409',1,'Account Home'),(935,'410',1,'Registration completed'),(936,'411',1,'Your registration has been completed.'),(937,'412',1,'registration, completed, file, hosting, site'),(938,'413',1,'Thank you for registering!'),(939,'414',1,'We\'ve sent an email to your registered email address with your access password. Please check your spam filters to ensure emails from this site get through. '),(940,'415',1,'Emails from this site are sent from '),(941,'416',1,'Login'),(942,'417',1,'Login to your account'),(943,'418',1,'login, register, short url'),(944,'419',1,'Your username and password are invalid'),(945,'420',1,'Account Login'),(946,'421',1,'Please enter your username and password below to login.'),(947,'422',1,'Your account username. 6 characters or more and alpha numeric.'),(948,'423',1,'Your account password. Min 6 characters, alpha numeric, no spaces.'),(949,'428',1,'Please enter your username'),(950,'429',1,'Account Home'),(951,'430',1,'Your Account Home'),(952,'431',1,'account, home, file, hosting, members, area'),(953,'433',1,'faq'),(954,'434',1,'FAQ'),(955,'435',1,'Frequently Asked Questions'),(956,'436',1,'faq, frequently, asked, questions, file, hosting, site'),(957,'437',1,'Please enter your password'),(958,'511',1,'Report Abuse'),(959,'441',1,'Register Account'),(960,'444',1,'email confirm'),(961,'445',1,'stats'),(962,'446',1,'info'),(963,'447',1,'Email Confirm'),(964,'449',1,'Created/Last Visited'),(965,'450',1,'Status'),(966,'451',1,'Options'),(967,'452',1,'upload file'),(968,'453',1,'Register'),(969,'454',1,'Register for an account'),(970,'455',1,'register, account, short, url, user'),(971,'456',1,'your files'),(972,'457',1,'File has been removed.'),(973,'458',1,'Uploaded'),(974,'459',1,'downloads'),(975,'460',1,'download now'),(976,'461',1,'loading file, please wait'),(977,'462',1,'Download File'),(978,'463',1,'Download file'),(979,'464',1,'download, file, upload, mp3, avi, zip'),(980,'465',1,'Your Files'),(981,'466',1,'Download Url'),(982,'467',1,'Uploaded/Last Visited'),(983,'468',1,'Download Url/Filename'),(984,'469',1,'Total Active Files'),(985,'470',1,'Total Inactive Files'),(986,'471',1,'Total Downloads'),(987,'472',1,'user removed'),(988,'473',1,'files'),(989,'474',1,'Manage Files'),(990,'475',1,'Filter Results'),(991,'476',1,'Show Disabled'),(992,'477',1,'Export File Data'),(993,'478',1,'File has been removed by the site administrator.'),(994,'479',1,'Show Removed'),(995,'480',1,'admin removed'),(996,'481',1,'Delete File'),(997,'482',1,'Delete File'),(998,'483',1,'delete, remove, file'),(999,'484',1,'Delete File'),(1000,'485',1,'Please confirm whether to delete the file below.'),(1001,'486',1,'Cancel'),(1002,'487',1,'report file'),(1003,'488',1,'upgrade account'),(1004,'489',1,'Terms and Conditions'),(1005,'490',1,'Terms and Conditions'),(1006,'491',1,'terms, and, conditions, file, hosting, site'),(1007,'492',1,'extend account'),(1008,'493',1,'Extend Account'),(1009,'494',1,'Extend Your Account'),(1010,'495',1,'extend, account, paid, membership, upload, download, site'),(1011,'496',1,'Payment Complete'),(1012,'497',1,'Payment Complete'),(1013,'498',1,'payment, complete, file, hosting, site'),(1014,'499',1,'premium account benefits'),(1015,'500',1,'account benefits'),(1016,'501',1,' Information'),(1017,'502',1,'Information about '),(1018,'503',1,', share, information, file, upload, download, site'),(1019,'504',1,'download urls'),(1020,'505',1,'statistics'),(1021,'506',1,'share'),(1022,'507',1,'other options'),(1023,'508',1,'Enter the details of the file (as above) you wish to report.'),(1024,'510',1,'Please enter the details of the reported file.'),(1025,'516',1,'Legal Bits'),(1026,'517',1,'Your Account'),(1027,'518',1,'days'),(1028,'519',1,'premium'),(1029,'520',1,'Pay via PayPal'),(1030,'521',1,'secure payment'),(1031,'522',1,'100% Safe & Anonymous'),(1032,'523',1,'Add files...'),(1033,'524',1,'Start upload'),(1034,'525',1,'Cancel upload'),(1035,'526',1,'Select files'),(1036,'527',1,'Drag &amp; drop files here or click to browse...'),(1037,'528',1,'Max file size'),(1038,'529',1,'add file'),(1039,'530',1,'copy all links'),(1040,'531',1,'File uploads completed.'),(1041,'532',1,'Delete Url'),(1042,'533',1,'Stats Url'),(1043,'534',1,'HTML Code'),(1044,'535',1,'Forum Code'),(1045,'536',1,'Full Info'),(1046,'537',1,'click here'),(1047,'538',1,'extend'),(1048,'539',1,'reverts to free account'),(1049,'540',1,'never'),(1050,'541',1,'filename'),(1051,'542',1,'download'),(1052,'543',1,'filesize'),(1053,'544',1,'url'),(1054,'545',1,'Download from'),(1055,'546',1,'share file'),(1056,'549',1,'upload, share, track, file, hosting, host'),(1057,'548',1,'Upload, share, track, manage your files in one simple to use file host.'),(1058,'547',1,'Upload Files'),(1059,'550',1,'Please enter your firstname'),(1060,'550',1,'Please enter your firstname'),(1061,'551',1,'Click here to browse your files...');
/*!40000 ALTER TABLE `language_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language_key`
--

DROP TABLE IF EXISTS `language_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language_key` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `languageKey` varchar(255) NOT NULL,
  `defaultContent` text NOT NULL,
  `isAdminArea` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `languageKey` (`languageKey`)
) ENGINE=MyISAM AUTO_INCREMENT=557 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language_key`
--

LOCK TABLES `language_key` WRITE;
/*!40000 ALTER TABLE `language_key` DISABLE KEYS */;
INSERT INTO `language_key` VALUES (1,'home','home',1),(3,'banned_words_urls','banned words / urls',1),(4,'admin_users','admin users',1),(5,'banned_ips','banned ips',1),(6,'site_settings','site settings',1),(7,'languages','languages',1),(8,'logout','logout',1),(9,'language_details','Language Details',1),(10,'are_you_sure_you_want_to_remove_this_ip_ban','Are you sure you want to remove this IP ban?',1),(11,'are_you_sure_update_user_status','Are you sure you want to update the status of this user?',1),(12,'view','view',1),(13,'disable','disable',1),(14,'enable','enable',1),(15,'are_you_sure_remove_banned_word','Are you sure you want to remove this banned word?',1),(16,'ip_address_invalid_try_again','IP address appears to be invalid, please try again.',1),(17,'ip_address_already_blocked','IP address is already in the blocked list.',1),(18,'error_problem_record','There was a problem inserting/updating the record, please try again later.',1),(19,'banned_word_already_in_list','Banned word is already in the list.',1),(20,'language_already_in_system','Language already in the system.',1),(21,'username_length_invalid','Username must be between 6-16 characters long.',1),(22,'password_length_invalid','Password must be between 6-16 characters long.',1),(23,'enter_first_name','Please enter the firstname.',1),(24,'enter_last_name','Please enter the lastname.',1),(25,'enter_email_address','Please enter the email address.',1),(26,'entered_email_address_invalid','The email address you entered appears to be invalid.',1),(27,'copyright','Copyright',1),(28,'support','Support',1),(30,'admin_panel','Admin Panel',1),(31,'logged_in_as','Logged in as',1),(32,'banned_ips_intro','To ban an IP Address <a href=\"#\" onClick=\"displayBannedIpPopup(); return false;\">click here</a> or delete any existing ones below',1),(33,'banned_ips_add_banned_ip','Add banned IP address',1),(34,'remove','remove',1),(35,'ip_address','IP Address',1),(36,'ban_from','Ban From',1),(37,'notes','Notes',1),(38,'add_banned_ip','Add Banned IP',1),(39,'error_submitting_form','There was an error submitting the form, please try again later.',1),(40,'enter_ip_address_details','Enter IP Address details',1),(41,'banned_terms_intro','To ban an word within the original url <a href=\"#\" onClick=\"displayBannedWordsPopup(); return false;\">click here</a> or delete any existing ones below',1),(42,'add_banned_term','Add banned word',1),(43,'banned_term','Banned Word',1),(44,'date_banned','Date Banned',1),(45,'ban_notes','Ban Notes',1),(46,'action','Action',1),(47,'enter_banned_term_details','Enter Banned Word details',1),(48,'dashboard_intro','Use the main navigation above to manage this site. A quick overview of the site can be seen below',1),(49,'dashboard_graph_last_14_days_title','New Files (last 14 days)',1),(50,'dashboard_graph_last_12_months_title','New Files (last 12 months)',1),(51,'urls','Urls',1),(52,'active','active',1),(53,'disabled','disabled',1),(54,'spam','spam',1),(55,'expired','expired',1),(56,'dashboard_total_active_urls','Total active files',1),(57,'dashboard_total_disabled_urls','Total disabled files',1),(58,'dashboard_total_visits_to_all_urls','Total downloads to all files',1),(59,'item_name','Item Name',1),(60,'value','Value',1),(61,'manage_languages_intro_2','Manage the available content for the selected language. Click on any of the \'Translated Content\' cells to edit the value.',1),(62,'manage_languages_intro_1','Select a language to manage or <a href=\'#\' onClick=\'displayAddLanguagePopup(); return false;\'>add a new one here</a>. NOTE Once translated, to set the site default language go to the <a href=\'settings.php\'>site settings</a> area.',1),(63,'language_key','Language Key',1),(64,'default_content','Default Content',1),(65,'translated_content','Translated Content',1),(66,'no_changes_in_demo_mode','Error Changes to this section can not be made within demo mode.',1),(67,'manage_other_languages','Manage other languages',1),(68,'no_available_content','There is no available content.',1),(69,'select_language','select language',1),(70,'add_language','Add Language',1),(71,'language_name','Language Name',1),(72,'settings_intro','Click on any of the items within the \"Config Value\" column below to edit',1),(73,'group','Group',1),(74,'config_description','Config Description',1),(75,'config_value','Config Value',1),(76,'shorturls_filter_results','Filter results',1),(77,'user_management_intro','Double click on any of the users below to edit the account information or <a href=\"#\" onClick=\"displayUserPopup(); return false;\">click here to add a new user</a>',1),(78,'add_new_user','Add new user',1),(79,'username','Username',1),(80,'email_address','Email Address',1),(81,'account_type','Account Type',1),(82,'last_login','Last Login',1),(83,'account_status','Account Status',1),(84,'password','Password',1),(85,'title','Title',1),(86,'firstname','Firstname',1),(87,'lastname','Lastname',1),(88,'enter_user_details','Enter user details',1),(90,'term_and_conditions','Terms &amp; Conditions',0),(515,'main_navigation','Main Navigation',0),(92,'created_by','Created By',0),(94,'not_permitted_to_create_urls_on_site','You are not permitted to upload files on this site.',0),(95,'error_with_url','There was an error with the url you supplied, please check and try again.',0),(96,'can_not_create_url_on_this_site','You can not upload files on this site.',0),(97,'date_entered_is_incorrect','The date you entered is incorrect.',0),(98,'custom_short_url_already_exits','That custom short url already exists, please try another.',0),(99,'problem_creating_short_url','There was a problem uploading the file, please try again later.',0),(100,'access_restricted_enter_password','This url is access restricted, please enter the password below',0),(107,'redirecting_to','Redirecting to',0),(108,'please_wait','please wait',0),(109,'general_site_error','There was a general site error, please try again later.',0),(110,'error','Error',0),(153,'visits_','visits',0),(154,'created_','created',0),(155,'visitors','Visitors',0),(156,'countries','Countries',0),(157,'top_referrers','Top Referrers',0),(158,'browsers','Browsers',0),(159,'operating_systems','Operating Systems',0),(160,'last_24_hours','last 24 hours',0),(161,'last_7_days','last 7 days',0),(162,'last_30_days','last 30 days',0),(163,'last_12_months','last 12 months',0),(164,'hour','Hour',0),(165,'visits','Visits',0),(166,'date','Date',0),(167,'total_visits','Total visits',0),(168,'percentage','Percentage',0),(169,'day','Day',0),(170,'month','Month',0),(171,'country','Country',0),(172,'site','Site',0),(173,'browser','Browser',0),(174,'operating_system','Operating System',0),(175,'AD','Andorra',0),(176,'AE','United Arab Emirates',0),(177,'AF','Afghanistan',0),(178,'AG','Antigua And Barbuda',0),(179,'AI','Anguilla',0),(180,'AL','Albania',0),(181,'AM','Armenia',0),(182,'AN','Netherlands Antilles',0),(183,'AO','Angola',0),(184,'AQ','Antarctica',0),(185,'AR','Argentina',0),(186,'AS','American Samoa',0),(187,'AT','Austria',0),(188,'AU','Australia',0),(189,'AW','Aruba',0),(190,'AZ','Azerbaijan',0),(191,'BA','Bosnia And Herzegovina',0),(192,'BB','Barbados',0),(193,'BD','Bangladesh',0),(194,'BE','Belgium',0),(195,'BF','Burkina Faso',0),(196,'BG','Bulgaria',0),(197,'BH','Bahrain',0),(198,'BI','Burundi',0),(199,'BJ','Benin',0),(200,'BM','Bermuda',0),(201,'BN','Brunei Darussalam',0),(202,'BO','Bolivia',0),(203,'BR','Brazil',0),(204,'BS','Bahamas',0),(205,'BT','Bhutan',0),(206,'BW','Botswana',0),(207,'BY','Belarus',0),(208,'BZ','Belize',0),(209,'CA','Canada',0),(210,'CD','The Democratic Republic Of The Congo',0),(211,'CF','Central African Republic',0),(212,'CG','Congo',0),(213,'CH','Switzerland',0),(214,'CI','Cote Divoire',0),(215,'CK','Cook Islands',0),(216,'CL','Chile',0),(217,'CM','Cameroon',0),(218,'CN','China',0),(219,'CO','Colombia',0),(220,'CR','Costa Rica',0),(221,'CS','Serbia And Montenegro',0),(222,'CU','Cuba',0),(223,'CV','Cape Verde',0),(224,'CY','Cyprus',0),(225,'CZ','Czech Republic',0),(226,'DE','Germany',0),(227,'DJ','Djibouti',0),(228,'DK','Denmark',0),(229,'DM','Dominica',0),(230,'DO','Dominican Republic',0),(231,'DZ','Algeria',0),(232,'EC','Ecuador',0),(233,'EE','Estonia',0),(234,'EG','Egypt',0),(235,'ER','Eritrea',0),(236,'ES','Spain',0),(237,'ET','Ethiopia',0),(238,'EU','European Union',0),(239,'FI','Finland',0),(240,'FJ','Fiji',0),(241,'FK','Falkland Islands (Malvinas)',0),(242,'FM','Federated States Of Micronesia',0),(243,'FO','Faroe Islands',0),(244,'FR','France',0),(245,'GA','Gabon',0),(246,'GB','United Kingdom',0),(247,'GD','Grenada',0),(248,'GE','Georgia',0),(249,'GF','French Guiana',0),(250,'GH','Ghana',0),(251,'GI','Gibraltar',0),(252,'GL','Greenland',0),(253,'GM','Gambia',0),(254,'GN','Guinea',0),(255,'GP','Guadeloupe',0),(256,'GQ','Equatorial Guinea',0),(257,'GR','Greece',0),(258,'GS','South Georgia And The South Sandwich Islands',0),(259,'GT','Guatemala',0),(260,'GU','Guam',0),(261,'GW','Guinea-Bissau',0),(262,'GY','Guyana',0),(263,'HK','Hong Kong',0),(264,'HN','Honduras',0),(265,'HR','Croatia',0),(266,'HT','Haiti',0),(267,'HU','Hungary',0),(268,'ID','Indonesia',0),(269,'IE','Ireland',0),(270,'IL','Israel',0),(271,'IN','India',0),(272,'IO','British Indian Ocean Territory',0),(273,'IQ','Iraq',0),(274,'IR','Islamic Republic Of Iran',0),(275,'IS','Iceland',0),(276,'IT','Italy',0),(277,'JM','Jamaica',0),(278,'JO','Jordan',0),(279,'JP','Japan',0),(280,'KE','Kenya',0),(281,'KG','Kyrgyzstan',0),(282,'KH','Cambodia',0),(283,'KI','Kiribati',0),(284,'KM','Comoros',0),(285,'KN','Saint Kitts And Nevis',0),(286,'KR','Republic Of Korea',0),(287,'KW','Kuwait',0),(288,'KY','Cayman Islands',0),(289,'KZ','Kazakhstan',0),(290,'LA','Lao Peoples Democratic Republic',0),(291,'LB','Lebanon',0),(292,'LC','Saint Lucia',0),(293,'LI','Liechtenstein',0),(294,'LK','Sri Lanka',0),(295,'LR','Liberia',0),(296,'LS','Lesotho',0),(297,'LT','Lithuania',0),(298,'LU','Luxembourg',0),(299,'LV','Latvia',0),(300,'LY','Libyan Arab Jamahiriya',0),(301,'MA','Morocco',0),(302,'MC','Monaco',0),(303,'MD','Republic Of Moldova',0),(304,'MG','Madagascar',0),(305,'MH','Marshall Islands',0),(306,'MK','The Former Yugoslav Republic Of Macedonia',0),(307,'ML','Mali',0),(308,'MM','Myanmar',0),(309,'MN','Mongolia',0),(310,'MO','Macao',0),(311,'MP','Northern Mariana Islands',0),(312,'MQ','Martinique',0),(313,'MR','Mauritania',0),(314,'MT','Malta',0),(315,'MU','Mauritius',0),(316,'MV','Maldives',0),(317,'MW','Malawi',0),(318,'MX','Mexico',0),(319,'MY','Malaysia',0),(320,'MZ','Mozambique',0),(321,'NA','Namibia',0),(322,'NC','New Caledonia',0),(323,'NE','Niger',0),(324,'NF','Norfolk Island',0),(325,'NG','Nigeria',0),(326,'NI','Nicaragua',0),(327,'NL','Netherlands',0),(328,'NO','Norway',0),(329,'NP','Nepal',0),(330,'NR','Nauru',0),(331,'NU','Niue',0),(332,'NZ','New Zealand',0),(333,'OM','Oman',0),(334,'PA','Panama',0),(335,'PE','Peru',0),(336,'PF','French Polynesia',0),(337,'PG','Papua New Guinea',0),(338,'PH','Philippines',0),(339,'PK','Pakistan',0),(340,'PL','Poland',0),(341,'PR','Puerto Rico',0),(342,'PS','Palestinian Territory',0),(343,'PT','Portugal',0),(344,'PW','Palau',0),(345,'PY','Paraguay',0),(346,'QA','Qatar',0),(347,'RE','Reunion',0),(348,'RO','Romania',0),(349,'RU','Russian Federation',0),(350,'RW','Rwanda',0),(351,'SA','Saudi Arabia',0),(352,'SB','Solomon Islands',0),(353,'SC','Seychelles',0),(354,'SD','Sudan',0),(355,'SE','Sweden',0),(356,'SG','Singapore',0),(357,'SI','Slovenia',0),(358,'SK','Slovakia (Slovak Republic)',0),(359,'SL','Sierra Leone',0),(360,'SM','San Marino',0),(361,'SN','Senegal',0),(362,'SO','Somalia',0),(363,'SR','Suriname',0),(364,'ST','Sao Tome And Principe',0),(365,'SV','El Salvador',0),(366,'SY','Syrian Arab Republic',0),(367,'SZ','Swaziland',0),(368,'TD','Chad',0),(369,'TF','French Southern Territories',0),(370,'TG','Togo',0),(371,'TH','Thailand',0),(372,'TJ','Tajikistan',0),(373,'TK','Tokelau',0),(374,'TL','Timor-Leste',0),(375,'TM','Turkmenistan',0),(376,'TN','Tunisia',0),(377,'TO','Tonga',0),(378,'TR','Turkey',0),(379,'TT','Trinidad And Tobago',0),(380,'TV','Tuvalu',0),(381,'TW','Taiwan Province Of China',0),(382,'TZ','United Republic Of Tanzania',0),(383,'UA','Ukraine',0),(384,'UG','Uganda',0),(385,'US','United States',0),(386,'UY','Uruguay',0),(387,'UZ','Uzbekistan',0),(388,'VA','Holy See (Vatican City State)',0),(389,'VC','Saint Vincent And The Grenadines',0),(390,'VE','Venezuela',0),(391,'VG','Virgin Islands',0),(392,'VI','Virgin Islands',0),(393,'VN','Viet Nam',0),(394,'VU','Vanuatu',0),(395,'WS','Samoa',0),(396,'YE','Yemen',0),(397,'YT','Mayotte',0),(398,'YU','Serbia And Montenegro (Formally Yugoslavia)',0),(399,'ZA','South Africa',0),(400,'ZM','Zambia',0),(401,'ZW','Zimbabwe',0),(402,'ZZ','Unknown',0),(404,'shorturl_filter_disabled','Show disabled',0),(405,'register','register',0),(408,'login','Login',0),(409,'account_home','Account Home',0),(410,'register_complete_page_name','Registration completed',0),(411,'register_complete_meta_description','Your registration has been completed.',0),(412,'register_complete_meta_keywords','registration, completed, file, hosting, site',0),(413,'register_complete_sub_title','Thank you for registering!',0),(414,'register_complete_main_text','We\'ve sent an email to your registered email address with your access password. Please check your spam filters to ensure emails from this site get through. ',0),(415,'register_complete_email_from','Emails from this site are sent from ',0),(416,'login_page_name','Login',0),(417,'login_meta_description','Login to your account',0),(418,'login_meta_keywords','login, register, short url',0),(419,'username_and_password_is_invalid','Your username and password are invalid',0),(420,'account_login','Account Login',0),(421,'login_intro_text','Please enter your username and password below to login.',0),(422,'username_requirements','Your account username. 6 characters or more and alpha numeric.',0),(423,'password_requirements','Your account password. Min 6 characters, alpha numeric, no spaces.',0),(551,'click_here_to_browse_your_files','Click here to browse your files...',0),(549,'index_meta_keywords','upload, share, track, file, hosting, host',0),(550,'please_enter_your_firstname','Please enter your firstname',0),(428,'please_enter_your_username','Please enter your username',0),(429,'account_home_page_name','Account Home',0),(430,'account_home_meta_description','Your Account Home',0),(431,'account_home_meta_keywords','account, home, file, hosting, members, area',0),(433,'faq','faq',0),(434,'faq_page_name','FAQ',0),(435,'faq_meta_description','Frequently Asked Questions',0),(436,'faq_meta_keywords','faq, frequently, asked, questions, file, hosting, site',0),(437,'please_enter_your_password','Please enter your password',0),(511,'report_abuse','Report Abuse',0),(441,'register_account','Register Account',0),(548,'index_meta_description','Upload, share, track, manage your files in one simple to use file host.',0),(444,'email_confirm','email confirm',0),(445,'stats','stats',0),(446,'info','info',0),(447,'email_address_confirm','Email Confirm',0),(547,'index_page_name','Upload Files',0),(449,'created_last_visited','Created/Last Visited',0),(450,'status','Status',0),(451,'options','Options',0),(452,'upload_file','upload file',0),(453,'register_page_name','Register',0),(454,'register_meta_description','Register for an account',0),(455,'register_meta_keywords','register, account, short, url, user',0),(456,'your_files','your files',0),(457,'error_file_has_been_removed_by_user','File has been removed.',0),(458,'uploaded','Uploaded',0),(459,'downloads','downloads',0),(460,'download_now','download now',0),(461,'loading_file_please_wait','loading file, please wait',0),(462,'file_download_title','Download File',0),(463,'file_download_description','Download file',0),(464,'file_download_keywords','download, file, upload, mp3, avi, zip',0),(465,'your_recent_files','Your Files',0),(466,'download_url','Download Url',0),(467,'uploaded_last_visited','Uploaded/Last Visited',0),(468,'download_url_filename','Download Url/Filename',0),(469,'dashboard_total_active_files','Total Active Files',0),(470,'dashboard_total_disabled_files','Total Inactive Files',0),(471,'dashboard_total_downloads_to_all','Total Downloads',0),(472,'user removed','user removed',0),(473,'files','files',0),(474,'manage_files','Manage Files',0),(475,'files_filter_results','Filter Results',0),(476,'files_filter_disabled','Show Disabled',0),(477,'export_files_as_csv','Export File Data',0),(478,'error_file_has_been_removed_by_admin','File has been removed by the site administrator.',0),(479,'files_filter_removed','Show Removed',0),(480,'admin removed','admin removed',0),(481,'delete_file_page_name','Delete File',0),(482,'delete_file_meta_description','Delete File',0),(483,'delete_file_meta_keywords','delete, remove, file',0),(484,'delete_file','Delete File',0),(485,'delete_file_intro','Please confirm whether to delete the file below.',0),(486,'cancel','Cancel',0),(487,'report_file','report file',0),(488,'uprade_account','upgrade account',0),(489,'terms_page_name','Terms and Conditions',0),(490,'terms_meta_description','Terms and Conditions',0),(491,'terms_meta_keywords','terms, and, conditions, file, hosting, site',0),(492,'extend_account','extend account',0),(493,'upgrade_page_name','Extend Account',0),(494,'upgrade_meta_description','Extend Your Account',0),(495,'upgrade_meta_keywords','extend, account, paid, membership, upload, download, site',0),(496,'payment_complete_page_name','Payment Complete',0),(497,'payment_complete_meta_description','Payment Complete',0),(498,'payment_complete_meta_keywords','payment, complete, file, hosting, site',0),(499,'premium_account_benefits','premium account benefits',0),(500,'account_benefits','account benefits',0),(501,'file_information_page_name',' Information',0),(502,'file_information_description','Information about ',0),(503,'file_information_meta_keywords',', share, information, file, upload, download, site',0),(504,'download_urls','download urls',0),(505,'statistics','statistics',0),(506,'share','share',0),(507,'other_options','other options',0),(508,'problem_file_requirements','Enter the details of the file (as above) you wish to report.',0),(510,'report_abuse_error_no_content','Please enter the details of the reported file.',0),(516,'legal_bits','Legal Bits',0),(517,'your_account','Your Account',0),(518,'days','days',0),(519,'premium','premium',0),(520,'pay_via_paypal','Pay via PayPal',0),(521,'secure_payment','secure payment',0),(522,'safe_and_anonymous','100% Safe & Anonymous',0),(523,'add_files','Add files...',0),(524,'start_upload','Start upload',0),(525,'cancel_upload','Cancel upload',0),(526,'select_files','Select files',0),(527,'drag_and_drop_files_here_or_click_to_browse','Drag &amp; drop files here or click to browse...',0),(528,'max_file_size','Max file size',0),(529,'add_file','add file',0),(530,'copy_all_links','copy all links',0),(531,'file_upload_completed','File uploads completed.',0),(532,'delete_url','Delete Url',0),(533,'stats_url','Stats Url',0),(534,'html_code','HTML Code',0),(535,'forum_code','Forum Code',0),(536,'full_info','Full Info',0),(537,'click_here','click here',0),(538,'extend','extend',0),(539,'reverts_to_free_account','reverts to free account',0),(540,'never','never',0),(541,'filename','filename',0),(542,'download','download',0),(543,'filesize','filesize',0),(544,'url','url',0),(545,'download_from','Download from',0),(546,'share_file','share file',0),(552,'optional_account_expiry','Paid Expiry Y-m-d (optional)',1),(553,'account_expiry_invalid','Account expiry date is invalid. It should be in the format YYYY-mm-dd',1),(554,'admin_file_servers','File Servers',1),(555,'ftp_host','FTP Ip Address',1),(556,'ftp_port','FTP Port',1);
/*!40000 ALTER TABLE `language_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_log`
--

DROP TABLE IF EXISTS `payment_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `payment_hash` varchar(64) NOT NULL,
  `status` enum('note','error','complete','waiting_confirmation','insufficient_amount','error:unknown_transaction','error:incorrect_secret','error:order_not_open','error:data_incongruent') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `amount_usd` float(9,2) DEFAULT NULL,
  `amount_btc` float(9,9) DEFAULT NULL,
  `currency_code` varchar(3) NOT NULL,
  `description` text NOT NULL,
  `request_log` text NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_log`
--

LOCK TABLES `payment_log` WRITE;
/*!40000 ALTER TABLE `payment_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugin`
--

DROP TABLE IF EXISTS `plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plugin_name` varchar(150) NOT NULL,
  `folder_name` varchar(100) NOT NULL,
  `plugin_description` varchar(255) NOT NULL,
  `is_installed` int(1) NOT NULL DEFAULT '0',
  `date_installed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `plugin_settings` text NOT NULL,
  `plugin_enabled` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugin`
--

LOCK TABLES `plugin` WRITE;
/*!40000 ALTER TABLE `plugin` DISABLE KEYS */;
INSERT INTO `plugin` VALUES (1,'PayPal Payment Integration','paypal','Accept payments using PayPal.',1,'2016-04-29 02:21:11','{\"paypal_email\":\"paypal@yoursite.com\"}',1);
/*!40000 ALTER TABLE `plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `premium_order`
--

DROP TABLE IF EXISTS `premium_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `premium_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT '1',
  `payment_sequence` int(11) NOT NULL,
  `payment_hash` varchar(64) NOT NULL,
  `days` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `amount_usd` float(9,2) NOT NULL,
  `amount_btc` float(9,9) NOT NULL DEFAULT '0.000000000',
  `amount_paid` int(11) DEFAULT '0',
  `order_status` enum('pending','cancelled','completed','forwarded','expired','verifying','paid','recording','recorded') NOT NULL,
  `bitcoin_address` varchar(36) NOT NULL,
  `secret` varchar(256) NOT NULL,
  `callback_url` varchar(256) NOT NULL,
  `expireAt` datetime NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `premium_order`
--

LOCK TABLES `premium_order` WRITE;
/*!40000 ALTER TABLE `premium_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `premium_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session_transfer`
--

DROP TABLE IF EXISTS `session_transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session_transfer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_key` varchar(32) NOT NULL,
  `session_id` varchar(32) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `date_added` (`date_added`),
  KEY `session_id` (`session_id`),
  KEY `transfer_key` (`transfer_key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_transfer`
--

LOCK TABLES `session_transfer` WRITE;
/*!40000 ALTER TABLE `session_transfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `session_transfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  `updated_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_config`
--

DROP TABLE IF EXISTS `site_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_key` varchar(100) NOT NULL,
  `config_value` text NOT NULL,
  `config_description` varchar(255) NOT NULL,
  `availableValues` varchar(255) NOT NULL,
  `config_type` varchar(30) NOT NULL,
  `config_group` varchar(100) NOT NULL DEFAULT 'Default',
  PRIMARY KEY (`id`),
  KEY `config_key` (`config_key`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_config`
--

LOCK TABLES `site_config` WRITE;
/*!40000 ALTER TABLE `site_config` DISABLE KEYS */;
INSERT INTO `site_config` VALUES (32,'cost_for_7_days_premium','4.99','The cost for 7 days premium access. Without any curency symbol. i.e. 4.99','','integer','Premium Pricing'),(2,'redirect_delay_seconds','60','How long to wait before redirecting if Meta Delay Redirect','','integer','Default'),(21,'language_show_key','translation','Show translation value or key. (use \'key\' to debug translations, \'translation\' to show actual translated value)','[\"key\",\"translation\"]','select','Language'),(4,'page_extension','html','Whether to use html or php front-end page extensions','[\"html\", \"php\"]','select','Page Options'),(5,'date_time_format','d/m/Y H:i:s','Date time format in php','','string','Local'),(6,'date_format','d/m/Y','Date format in php','','string','Local'),(7,'site_name','File Upload Script','Site name','','string','Page Options'),(9,'site_theme','blue_v2','Site template theme','[\"blue_v2\"]','select','Page Options'),(10,'max_files_per_day','50','Spam protect: Max files a user IP address can create per day. Leave blank for unlimited.','','integer','File Uploads'),(11,'date_time_format_js','%d-%m-%Y %H:%i','Date time format in javascript','','string','Local'),(33,'cost_for_30_days_premium','9.99','The cost for 30 days premium access. Without any curency symbol. i.e. 9.99','','integer','Premium Pricing'),(15,'advert_site_footer','<a target=\"_blank\" href=\"http://www.dreamhost.com/r.cgi?606181\"><img height=\"60\" width=\"468\" src=\"http://images.dreamhost.com/rewards/468x60-b.gif\" alt=\"468x60\"/></a>','Site footer ads across the site (html)','','textarea','Adverts'),(16,'advert_delayed_redirect_top','<a target=\"_blank\" href=\"http://www.dreamhost.com/r.cgi?606181\"><img height=\"60\" width=\"468\" src=\"http://images.dreamhost.com/rewards/468x60-d.gif\" alt=\"468x60\"/></a>','Delayed redirect top advert (html)','','textarea','Adverts'),(18,'advert_delayed_redirect_bottom','<a target=\"_blank\" href=\"http://www.dreamhost.com/r.cgi?606181\"><img height=\"60\" width=\"468\" src=\"http://images.dreamhost.com/rewards/468x60-c.gif\" alt=\"468x60\"/></a>','Delayed redirect bottom advert (html)','','textarea','Adverts'),(19,'report_abuse_email','abuse@yoursite.com','Email address for which all abuse reports are sent.','','string','Page Options'),(20,'site_language','English (en)','Site language for text conversions <a href=\"translation_manage.php\">(manage languages)</a>','SELECT languageName AS itemValue FROM language ORDER BY languageName','select','Language'),(31,'next_check_for_file_removals','1327013029','System value. The next time to delete any files which haven\'t recently been accessed. DATE. Do not edit.','','integer','System'),(23,'stats_only_count_unique','yes','Revisits in the same day, by the same IP address will not be counted on stats.','[\"yes\", \"no\"]','select','Default'),(24,'default_email_address_from','email@yoursite.com','The default email address to send emails from.','','string','Page Options'),(25,'default_email_address_from','email@yoursite.com','The email address new account registrations will be sent from.','','string','Default'),(26,'free_user_max_upload_filesize','104857600','The max upload filesize for free users (in bytes)','','integer','Free User Settings'),(27,'premium_user_max_upload_filesize','1073741824','The max upload filesize for premium users (in bytes)','','integer','Premium User Settings'),(28,'accepted_upload_file_types','','The file extensions which are permitted. Leave blank for all. Separate by semi-colon. i.e. .jpg;.gif;.doc;','','string','File Uploads'),(29,'free_user_upload_removal_days','60','The amount of days after non-active files are removed for free users. Leave blank for unlimited.','','integer','Free User Settings'),(30,'premium_user_upload_removal_days','','The amount of days after non-active files are removed for paid users. Leave blank for unlimited.','','integer','Premium User Settings'),(34,'cost_for_90_days_premium','19.99','The cost for 90 days premium access. Without any curency symbol. i.e. 19.99','','integer','Premium Pricing'),(35,'cost_for_180_days_premium','34.99','The cost for 180 days premium access. Without any curency symbol. i.e. 34.99','','integer','Premium Pricing'),(36,'cost_for_365_days_premium','59.99','The cost for 365 days premium access. Without any curency symbol. i.e. 59.99','','integer','Premium Pricing'),(37,'cost_currency_symbol','$','The symbol to use for currency. i.e. $','[\"$\", \"£\", \"€\"]','string','Premium Pricing'),(38,'cost_currency_code','USD','The currency code for the current currency. i.e. USD','[\"USD\", \"GBP\", \"EUR\"]','select','Premium Pricing'),(56,'downloads_track_current_downloads','yes','Whether to track current downloads/connections in the admin area. Note: This should be enabled if you also want to limit concurrent download connections.','[\"yes\",\"no\"]','select','File Downloads'),(40,'free_user_max_download_speed','50000','Maximum download speed for free/non-users, in bytes per second. i.e. 50000. Use 0 for unlimited. ','','integer','Free User Settings'),(41,'premium_user_max_download_speed','0','Maximum download speed for premium users, in bytes per second. i.e. 50000. Use 0 for unlimited. ','','integer','Premium User Settings'),(42,'email_method','php','The method for sending emails via the script.','[\"php\",\"smtp\"]','select','Email Settings'),(43,'email_smtp_host','mail.yoursite.com','Your SMTP host if you\'ve selected SMTP email method. (leave blank is email_method = php)','','string','Email Settings'),(44,'email_smtp_port','25','Your SMTP port if you\'ve selected SMTP email method. (Normally 25)','','integer','Email Settings'),(45,'email_smtp_requires_auth','no','Whether your SMTP server requires authentication.','[\"yes\",\"no\"]','select','Email Settings'),(46,'email_smtp_auth_username','','Your SMTP username if SMTP auth is required.','','string','Email Settings'),(47,'email_smtp_auth_password','','Your SMTP password if SMTP auth is required.','','string','Email Settings'),(48,'file_url_show_filename','no','Show the original filename on the end of the generated url.','[\"yes\",\"no\"]','select','File Uploads'),(49,'reserved_usernames','admin|administrator|localhost|support|billing|sales|payments','Any usernames listed here will be blocked from the main registration. Pipe separated list.','','string','Default'),(50,'show_multi_language_selector','hide','Whether to show or hide the multi language selector on the site.','[\"hide\",\"show\"]','select','Language'),(51,'free_user_max_remote_urls','5','The maximum remote urls a non/free user can specify at once.','','integer','Free User Settings'),(52,'premium_user_max_remote_urls','50','The maximum remote urls a paid user can specify at once.','','integer','Free User Settings'),(53,'free_user_max_concurrent_uploads','50','The maximum amount of files that can be uploaded at the same time for free users.','','integer','Free User Settings'),(54,'premium_user_max_concurrent_uploads','100','The maximum amount of files that can be uploaded at the same time for paid users.','','integer','Premium User Settings'),(55,'register_form_show_captcha','no','Whether to display the captcha on the site registration form.','[\"yes\",\"no\"]','select','Captcha'),(57,'paid_user_max_download_threads','0','The maximum concurrent downloads a paid user can do at once. Set to 0 (zero) for no limit. Note: Ensure the \'downloads_track_current_downloads\' is also set to \'yes\' to enable this.','','integer','Premium User Settings'),(58,'free_user_wait_between_downloads','0','How long a free user must wait between downloads, in seconds. Set to 0 (zero) to disable. Note: Ensure the \'downloads_track_current_downloads\' is also set to \'yes\' to enable this.','','integer','Free User Settings');
/*!40000 ALTER TABLE `site_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stats`
--

DROP TABLE IF EXISTS `stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `referer` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `referer_is_local` tinyint(4) NOT NULL DEFAULT '0',
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `page_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `img_search` tinyint(4) NOT NULL DEFAULT '0',
  `browser_family` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `browser_version` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `os` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `os_version` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ip` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `base_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dt` (`dt`),
  KEY `page_title` (`page_title`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stats`
--

LOCK TABLES `stats` WRITE;
/*!40000 ALTER TABLE `stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(65) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(65) COLLATE utf8_unicode_ci NOT NULL,
  `level` enum('free user','invited','neophite','paid user','admin','test') COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(65) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastlogindate` datetime DEFAULT NULL,
  `lastloginip` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('active','pending','disabled','suspended') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `title` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `createdip` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastPaymentSequence` int(11) DEFAULT '0',
  `lastPayment` datetime DEFAULT NULL,
  `paidExpiryDate` datetime DEFAULT NULL,
  `paymentTracker` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passwordResetHash` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `identifier` varchar(32) COLLATE utf8_unicode_ci DEFAULT '',
  `apikey` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `username_2` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','5f4dcc3b5aa765d61d8327deb882cf99','admin','email@yoursite.com',NULL,'192.168.2.100','active','Mr','Admin','User','2011-12-27 13:45:22','2016-04-28 22:21:11','local',0,NULL,NULL,'no_payment_tracker','no_password_reset_hash','i_admin','no_api_key'),(2,'test','5f4dcc3b5aa765d61d8327deb882cf99','test','email@yoursite.com',NULL,'192.168.2.100','active','Mr','test','user','2011-12-27 13:45:22','2016-04-28 22:21:11','local',0,NULL,'2016-04-28 22:21:11','no_payment_tracker','no_password_reset_hash','i_test','no_api_key');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-28 22:25:12
