CREATE TABLE banned_ips
(
    id INT(11) PRIMARY KEY NOT NULL,
    ipAddress VARCHAR(30) NOT NULL,
    dateBanned TIMESTAMP DEFAULT 'CURRENT_TIMESTAMP' NOT NULL,
    banType VARCHAR(30) NOT NULL,
    banNotes TEXT NOT NULL
);
CREATE INDEX ipAddress ON banned_ips (ipAddress);
CREATE TABLE file
(
    id INT(11) PRIMARY KEY NOT NULL,
    originalFilename VARCHAR(255) NOT NULL,
    shortUrl VARCHAR(255),
    fileType VARCHAR(50),
    extension VARCHAR(10),
    fileSize BIGINT(15),
    localFilePath VARCHAR(255),
    userId INT(11),
    totalDownload INT(11),
    uploadedIP VARCHAR(50),
    uploadedDate DATE,
    statusId INT(2),
    visits INT(11) DEFAULT '0',
    lastAccessed DATE,
    deleteHash VARCHAR(32),
    folderId INT(11),
    serverId INT(11) DEFAULT '1',
    adminNotes TEXT NOT NULL,
    accessPassword VARCHAR(32)
);
CREATE INDEX extension ON file (extension);
CREATE INDEX fileSize ON file (fileSize);
CREATE INDEX lastAccessed ON file (lastAccessed);
CREATE INDEX originalFilename ON file (originalFilename);
CREATE INDEX shortUrl ON file (shortUrl);
CREATE INDEX statusId ON file (statusId);
CREATE INDEX userId ON file (userId);
CREATE INDEX visits ON file (visits);

CREATE TABLE payment_log
(
    id INT(11) PRIMARY KEY NOT NULL,
    user_id INT(11) NOT NULL,
    order_id INT(11) NOT NULL,
    username VARCHAR(255) NOT NULL,
    payment_hash VARCHAR(64) NOT NULL,
    status ENUM('NOTE', 'ERROR', 'COMPLETE', 'WAITING_CONFIRMATION') DEFAULT 'note' NOT NULL,
    amount INT(11) DEFAULT '0' NOT NULL,
    amount_usd FLOAT(9,2) DEFAULT '0.00' NOT NULL,
    amount_btc FLOAT(9,9) DEFAULT '0.000000000' NOT NULL,
    currency_code VARCHAR(3) NOT NULL,
    description TEXT NOT NULL,
    request_log TEXT NOT NULL,
    createdAt DATETIME,
    updatedAt DATETIME
);
CREATE TABLE premium_order
(
    id INT(11) PRIMARY KEY NOT NULL,
    user_id INT(11) NOT NULL,
    payment_hash VARCHAR(64) NOT NULL,
    days INT(11) NOT NULL,
    amount INT(11) NOT NULL,
    amount_usd FLOAT(9,2) NOT NULL,
    amount_btc FLOAT(9,9) DEFAULT '0.000000000' NOT NULL,
    order_status ENUM('PENDING', 'CANCELLED', 'COMPLETED', 'FORWARDED', 'EXPIRED') NOT NULL,
    date_created TIMESTAMP DEFAULT 'CURRENT_TIMESTAMP' NOT NULL,
    bitcoin_address VARCHAR(36) NOT NULL,
    secret VARCHAR(256) NOT NULL,
    callback_url VARCHAR(256) NOT NULL,
    expireAt DATETIME NOT NULL,
    createdAt DATETIME,
    updatedAt DATETIME
);
CREATE TABLE sessions
(
    id VARCHAR(255) PRIMARY KEY NOT NULL,
    data TEXT NOT NULL,
    updated_on INT(10) NOT NULL
);


CREATE TABLE file_imdb_info
(
    id INT(11) PRIMARY KEY NOT NULL,
    file_id INT(11),
    name VARCHAR(255),
    year VARCHAR(255),
    series VARCHAR(255),
    season VARCHAR(255),
    episode VARCHAR(255),
    imbd_id INT(32),
    country VARCHAR(64),
    rating VARCHAR(16),
    genre VARCHAR(32),
    `desc` TEXT,
    image VARCHAR(255)
);

CREATE TABLE users
(
    id INT(11) PRIMARY KEY NOT NULL,
    username VARCHAR(65) NOT NULL,
    password VARCHAR(65) NOT NULL,
    level ENUM('FREE USER', 'INVITED', 'NEOPHITE', 'PAID USER', 'ADMIN') NOT NULL,
    email VARCHAR(65),
    lastlogindate DATETIME,
    lastloginip VARCHAR(32),
    status ENUM('ACTIVE', 'PENDING', 'DISABLED', 'SUSPENDED') DEFAULT 'active' NOT NULL,
    title VARCHAR(10) NOT NULL,
    firstname VARCHAR(150) NOT NULL,
    lastname VARCHAR(150) NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    createdip VARCHAR(15),
    lastPayment DATETIME,
    paidExpiryDate DATETIME,
    paymentTracker VARCHAR(32),
    passwordResetHash VARCHAR(64) DEFAULT '' NOT NULL,
    identifier VARCHAR(32) DEFAULT '' NOT NULL,
    apikey VARCHAR(32) DEFAULT '' NOT NULL
);
CREATE UNIQUE INDEX username ON users (username);
-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO users VALUES ('1', 'admin', '5f4dcc3b5aa765d61d8327deb882cf99', 'admin', 'email@yoursite.com', '2012-01-19 21:44:07', '192.168.2.100', 'active', 'Mr', 'Admin', 'User', '2011-12-27 13:45:22' ,'2011-12-27 13:45:22', 'local', '2011-12-27 13:45:22', '2011-12-27 13:45:22', 'no_payment_tracker', 'no_password_reset_hash', 'i_admin', 'no_api_key');
