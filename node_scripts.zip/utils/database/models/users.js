"use strict";

var _ = require('underscore');

module.exports = function(sequelize, DataTypes) {
    return sequelize.define('users', {
        username: {
            type: DataTypes.STRING,
            allowNull: false
        },
        password: {
            type: DataTypes.STRING
        },
        level: {
            type: DataTypes.ENUM('FREE USER','INVITED','NEOPHITE','PAID USER','ADMIN','TEST')
        },
        email: {
            type: DataTypes.STRING
        },
        lastlogindate: {
            type: DataTypes.DATE
        },
        lastloginip: {
            type: DataTypes.STRING,
            allowNull: true
        },
        status: {
            type: DataTypes.ENUM('ACTIVE','PENDING','DISABLED','SUSPENDED'),
            allowNull: false,
            defaultValue: 'active'
        },
        title: {
            type: DataTypes.STRING
        },
        firstname: {
            type: DataTypes.STRING,
            allowNull: true,
            defaultValue:''
        },
        lastname: {
            type: DataTypes.STRING,
            allowNull: true,
            defaultValue:''
        },
        createdip: {
            type: DataTypes.STRING,
            allowNull: true
        },
        lastPaymentSequence:{
            type: DataTypes.INTEGER(11),
            allowNull: true,
            defaultValue: 0
        },
        lastPayment: {
            type: DataTypes.DATE,
            allowNull: true,
            defaultValue: null
        },
        paidExpiryDate: {
            type: DataTypes.DATE,
            allowNull: true,
            defaultValue: null
        },
        paymentTracker: {
            type: DataTypes.STRING,
            allowNull: true,
            defaultValue: ''
        },
        passwordResetHash: {
            type: DataTypes.STRING,
            allowNull: true,
            defaultValue: ''
        },
        identifier: {
            type: DataTypes.STRING,
            allowNull: true,
            defaultValue: ''
        },
        apikey: {
            type: DataTypes.STRING,
            allowNull: true,
            defaultValue: ''
        }
    },
    {
        updatedAt: false,

        createdAt: false,

        classMethods:{

            getUserWhere: function( clause ){
                return this.findOne({where: clause});
            },

            incrementPaySequenceWhere: function( clause ){
                return this.update({
                    lastPaymentSequence:sequelize.literal('lastPaymentSequence +1')},
                {where:clause,returning: true});
            }

        },

        instanceMethods: {

            updateUserID: function ( options ) {
                return this.update(
                    { attributes:options },
                    { where: {id:options.userid}
                });
            },
            //used for testing
            ensureUserForTesting: function( options ) {
                var options = options || {};
                var o = _(options).defaults(utils.ensureForTesting.default);
                return user.findOrCreate( { where: o.where })
            }
        }
    });
};

var utils = {
    ensureForTesting: {
        default: {
            attr:{
                username: 'test_user',
                password: 'qwer1234',
                email : 'test@test.com',
                paidExpiryDate : new Date(  new Date().getTime()+ 3*24*60*60*1000 ),
                status: 'ACTIVE',
                level: 'test'
            },
            where: {username:'test_user'}
        },

        isValid: function( options ){ //unused because we do not return a promise on error
            var requiredKeys = ['username']
            var keysInBoth = _.intersection( _(options).keys(), requiredKeys )
            return (keysInBoth === requiredKeys)
        }
    }
};