/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('file', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true
    },
    originalFilename: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: ''
    },
    shortUrl: {
      type: DataTypes.STRING,
      allowNull: true
    },
    fileType: {
      type: DataTypes.STRING,
      allowNull: true
    },
    extension: {
      type: DataTypes.STRING,
      allowNull: true
    },
    fileSize: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    localFilePath: {
      type: DataTypes.STRING,
      allowNull: true
    },
    ipAddress: {
      type: DataTypes.STRING,
      allowNull: true
    },
    serverName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    machineName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    userId: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    totalDownload: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    uploadedIP: {
      type: DataTypes.STRING,
      allowNull: true
    },
    uploadedDate: {
      type: DataTypes.DATE,
      allowNull: true
    },
    statusId: {
      type: DataTypes.INTEGER(2),
      allowNull: true
    },
    visits: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      defaultValue: '0'
    },
    lastAccessed: {
      type: DataTypes.DATE,
      allowNull: true
    },
    deleteHash: {
      type: DataTypes.STRING,
      allowNull: true
    },
    folderId: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    serverId: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      defaultValue: '1'
    },
    accessPassword: {
      type: DataTypes.STRING,
      allowNull: true
    }
  });
};
