module.exports = function (sequelize, DataTypes) {

	return sequelize.define('premium_order', {
		user_id: {
			type: DataTypes.INTEGER(11),
			allowNull: false
		},
		product_id: {
			type: DataTypes.INTEGER(11),
			allowNull: true,
			default: 1
		},
		payment_sequence: {
			type: DataTypes.INTEGER(11),
			allowNull: false
		},
		payment_hash: {
			type: DataTypes.STRING,
			allowNull: false
		},
		days: {
			type: DataTypes.INTEGER(11),
			allowNull: false
		},
		amount: {
			type: DataTypes.INTEGER(13),
			allowNull: false
		},
		amount_usd: {
			type: DataTypes.FLOAT,
			allowNull: false
		},
		amount_btc: {
			type: DataTypes.FLOAT,
			allowNull: false
		},
		amount_paid: {
			type: DataTypes.INTEGER(13),
			default: 0
		},
		order_status: {
			type: DataTypes.ENUM('PENDING', 'CANCELLED', 'COMPLETED', 'FORWARDED', 'EXPIRED', 'VERIFYING', 'PAID','RECORDING','RECORDED'),
			allowNull: false
		},
		bitcoin_address: {
			type: DataTypes.STRING,
			allowNull: false
		},
		secret: {
			type: DataTypes.STRING,
			allowNull: false
		},
		callback_url: {
			type: DataTypes.STRING,
			allowNull: false
		},
		expireAt: {
			type: DataTypes.DATE,
			allowNull: false
		}
	},
	{
		tableName: 'premium_order',

		classMethods: {
			getAllOrdersWithStatus: function(status_array) {
				return this.findAll({
					where: { order_status: status_array }
				})
			},
			getPendingAndValidatingOrders: function() {
				return this.findAll({
					where: {
						order_status: ['PENDING', 'VERIFYING']
					}
				})
			},

			getAllPaidOrders: function() {
				return this.findAll({
					where: {
						order_status: ['PAID']
					}
				})
			},

			getAllRecordingAndStale: function() {
				return this.findAll({
					where: {
						order_status: ['RECORDING'],
						updatedAt: {$gt: new Date() - (10 * 60 * 1000)}
					}
				})
			},
			getAllRecordedAndStale: function() {
				return this.findAll({
					where: {
						order_status: ['RECORDED'],
						updatedAt: {$gt: new Date() - (10 * 60 * 1000)}
					}
				})
			},

			getAllTimedOutOrders: function() {
				return this.findAll({
					where: {
						order_status: ['PENDING', 'VERIFYING'],
						expireAt: {$lt: new Date()}
					}
				})
			},

			markIDPaid: function(ids) {
					return this.update({order_status: 'PAID'},{
						where: {id:ids}
					})
			},

			markOrdersExpired: function (ids) {
				return this.update({order_status: 'EXPIRED'},{
						where: {id:ids}
				})
			},

			expireOldOrders: function () {//todo: this should take into account the amount sent to order and when
				return this.update({order_status: 'EXPIRED'},{
					where: {
						order_status: ['PENDING', 'VERIFYING'],
						expireAt: {$lt: new Date()}
					}
				})
			},

			updatePendingOrdersStatusToValidating: function() {
				return this.update( {order_status:'VERIFYING'}, {
					where:{ order_status: 'PENDING' }
				});
			},

			markRecordingByID: function( ids ) {
				return this.update({order_status : 'RECORDING'},
					{where:{id: ids}});
			},
			markRecordedByID: function( ids ) {
				return this.update({order_status : 'RECORDED'},
					{where:{id: ids}});
			},
			markCompleteByID: function( id ) {
				return this.update({order_status : 'COMPLETED'},
					{where:{id: id}});
			}
		},

		instanceMethods: {
			markExpired: function() {
				return this.update({order_status: 'expired'});
			}
		}
	});

};
