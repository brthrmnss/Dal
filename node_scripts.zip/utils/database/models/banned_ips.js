/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('banned_ips', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true
    },
    ipAddress: {
      type: DataTypes.STRING,
      allowNull: false
    },
    dateBanned: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: 'CURRENT_TIMESTAMP'
    },
    banType: {
      type: DataTypes.STRING,
      allowNull: false
    },
    banNotes: {
      type: DataTypes.TEXT,
      allowNull: false
    }
  });
};
