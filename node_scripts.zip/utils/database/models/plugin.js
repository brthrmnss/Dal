/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('plugin', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true
    },
    plugin_name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    folder_name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    plugin_description: {
      type: DataTypes.STRING,
      allowNull: false
    },
    is_installed: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      defaultValue: '0'
    },
    date_installed: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: 'CURRENT_TIMESTAMP'
    },
    plugin_settings: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    plugin_enabled: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      defaultValue: '1'
    }
  });
};
