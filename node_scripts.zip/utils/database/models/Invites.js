/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('Invites', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true
    },
    invite_code: {
      type: DataTypes.STRING,
      allowNull: true
    },
    level: {
      type: DataTypes.ENUM('FREE USER','INVITED','NEOPHITE','PAID USER','ADMIN'),
      allowNull: true
    },
    email: {
      type: DataTypes.STRING,
      allowNull: true
    },
    forumname: {
      type: DataTypes.STRING,
      allowNull: true
    },
    joindate: {
      type: DataTypes.DATE,
      allowNull: true
    },
    trialExpire: {
      type: DataTypes.DATE,
      allowNull: true
    },
    creatorip: {
      type: DataTypes.STRING,
      allowNull: true
    },
    creator: {
      type: DataTypes.STRING,
      allowNull: true
    },
    datecreated: {
      type: DataTypes.DATE,
      allowNull: false
    },
    dateupdated: {
      type: DataTypes.DATE,
      allowNull: false
    },
    InviteCampaignId: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      references: {
        model: 'Invite_Campaigns',
        key: 'id'
      }
    }
  });
};
