/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('Invite_Campaigns', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING,
      allowNull: true
    },
    creatorip: {
      type: DataTypes.STRING,
      allowNull: true
    },
    creator: {
      type: DataTypes.STRING,
      allowNull: true
    },
    datecreated: {
      type: DataTypes.DATE,
      allowNull: false
    },
    dateupdated: {
      type: DataTypes.DATE,
      allowNull: false
    }
  });
};
