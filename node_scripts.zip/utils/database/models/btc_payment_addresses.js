/* jshint indent: 4 */
var _ = require('underscore');

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('btc_payment_addresses',
		{
			btc_address: {
				type: DataTypes.STRING,
				unique: 'compositeAddress'
			},
			private_key: {
				type: DataTypes.STRING,
				unique: 'compositeAddress'
			},
			index: {
				type: DataTypes.INTEGER(11)
			},
			status: {
				type: DataTypes.ENUM('reserved','available','frozen','parked','error','sweepable'),
				default:'available'
			},
			sweepable: {
				type: DataTypes.BOOLEAN,
				default:false
			},
			gen_count: {
				type: DataTypes.INTEGER(11),
				default:0

			},
			use_count: {
				type: DataTypes.INTEGER(11),
				default:0
			},
		},
		{
			tableName: 'btc_payment_addresses',

			classMethods: {

				findNextAvailable: function() {

					return this.findOne({
						where:{status:'available'},
						order:[['gen_count','ASC']]
					});

				},
				clearFrozen: function() {

					return this.update({status:'available'},{where:{ status:'frozen' }});

				},

				markAddressForReuse: function(addresses) {

						return this.update(
							{status:'parked', sweepable: true},
							{where:{btc_address:addresses}})
				}

			},

			instanceMethods: {

				markInUse:function() {

					return this.update({
						status:"reserved",
						gen_count: sequelize.literal('gen_count +1')
					});

				}
			}

		});
};
