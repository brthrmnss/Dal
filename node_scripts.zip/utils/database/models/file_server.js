/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('file_server', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true
    },
    serverLabel: {
      type: DataTypes.STRING,
      allowNull: false
    },
    serverType: {
      type: DataTypes.ENUM('REMOTE','LOCAL','FTP','SFTP','DIRECT'),
      allowNull: true
    },
    ipAddress: {
      type: DataTypes.STRING,
      allowNull: false
    },
    ftpPort: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '21'
    },
    ftpUsername: {
      type: DataTypes.STRING,
      allowNull: false
    },
    ftpPassword: {
      type: DataTypes.STRING,
      allowNull: true
    },
    sftpHost: {
      type: DataTypes.STRING,
      allowNull: false
    },
    sftpPort: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '22'
    },
    sftpUsername: {
      type: DataTypes.STRING,
      allowNull: false
    },
    sftpPassword: {
      type: DataTypes.STRING,
      allowNull: false
    },
    statusId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '1'
    },
    storagePath: {
      type: DataTypes.STRING,
      allowNull: true
    },
    fileServerDomainName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    scriptPath: {
      type: DataTypes.STRING,
      allowNull: true
    }
  });
};
