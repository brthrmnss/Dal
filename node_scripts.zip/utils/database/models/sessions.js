/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('sessions', {
    id: {
      type: DataTypes.STRING,
      allowNull: false,
      primaryKey: true
    },
    data: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    updated_on: {
      type: DataTypes.DATE,
      allowNull: true
    }
  },{
    updatedAt: 'updated_on',
    createdAt: false
  });
};
