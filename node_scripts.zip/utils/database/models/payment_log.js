/* jshint indent: 4 */

module.exports = function(sequelize, DataTypes) {
    return sequelize.define('payment_log', {
        user_id: {
            type: DataTypes.INTEGER(11),
            allowNull: true
        },
        order_id: {
            type: DataTypes.INTEGER(11),
            allowNull: true
        },
        payment_hash: {
          type: DataTypes.STRING,
          allowNull: false
        },
        status: {
            type: DataTypes.ENUM('note','error','complete','waiting_confirmation','insufficient_amount','error:unknown_transaction','error:incorrect_secret','error:order_not_open','error:data_incongruent'),
            allowNull: false
        },
        amount_usd: {
            type: DataTypes.FLOAT,
            allowNull: true,
            defaultValue: null
        },
        amount_btc: {
          type: DataTypes.FLOAT,
          allowNull: true,
          defaultValue: null
        },
        amount: {
            type: DataTypes.INTEGER(11),
            allowNull: true,
            defaultValue: null
        },
        currency_code: {
            type: DataTypes.STRING,
            allowNull: false
        },
        username: {
            type: DataTypes.STRING,
            allowNull: true,
            defaultValue: null

        },
        description: {
            type: DataTypes.TEXT,
            allowNull: false
        },
        request_log: {
            type: DataTypes.TEXT,
            allowNull: false
        }
    },{
        tableName: 'payment_log'
    });
};
