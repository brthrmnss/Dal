/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('language_key', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true
    },
    languageKey: {
      type: DataTypes.STRING,
      allowNull: false
    },
    defaultContent: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    isAdminArea: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      defaultValue: '0'
    }
  });
};
