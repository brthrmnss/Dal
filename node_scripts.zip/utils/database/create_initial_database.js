/**
 * Created by user on 7/4/15.
 */
/**
 * This script imports initial database file
 * why: when testing on unprovisioned machine
 * alt: use deployment scripts ... they will create user as well.
 * @type {exports|module.exports}
 */
var rh = require('rhelpers')
var shelpers = require('shelpers');
var sh = shelpers.shelpers;


//Example Commands:
/*
 mysql -u root -p
 password
 grant all privileges on yetidb.* to 'yetidbuser'@'localhost' identified by 'aSDDD545y^';
 */
/*
 sequelize.query('SELECT * FROM projects WHERE status = ?',
 { replacements: ['active'], type: sequelize.QueryTypes.SELECT }
 ).then(function(projects) {
 console.log(projects)
 })
 */






//mysql -u root -p <  /src/videoproject/Code/node_scripts/node_modules/rhelpers/sql/yetidb.sql

var cluster_settings = rh.loadRServerConfig();

var mysql      = require('mysql');
var configDB = {
    host     : cluster_settings.mysql.ip,
    port     : cluster_settings.mysql.port,
    // database	: cluster_settings.general_mysql_databasename,
    user     : cluster_settings.mysql.user,
    password : cluster_settings.mysql.pass
}
var connection = mysql.createConnection(configDB);
console.error('are you sure you want to override a remote database???',
'cluster_settings.mysql.ip' , cluster_settings.mysql.ip)
//connect to database
connection.connect(function(err) {
    if (err) {
        console.log('db config', configDB)
        console.error('error connecting: ' + err.stack);
        return;
    }
    console.log('connected as id ' + connection.threadId);
    step1_backupDb();

    function step1_backupDb() {
        var file_sql_export = __dirname+'/database_export.sql'
        file_sql_export = sh.fs.resolve(file_sql_export);

        //run mysql to import database file
        var child_process = require('child_process');
        var cmd = "mysqldump -u "+cluster_settings.mysql.user +
            " --password="+cluster_settings.mysql.pass +" " +
            cluster_settings.mysql.databasename + " > " + file_sql_export
        console.log('runnning file_sql_export...');
        child_process.exec(cmd, function (err, stdout, stderr) {
            console.error(err);
            console.error(stderr);
            console.log(stdout);
            step2_createDatabase();
        });
    }

    function step2_createDatabase() {
        var query = "CREATE DATABASE  IF NOT EXISTS "+
            cluster_settings.mysql.databasename+";"
        console.log('query ' + query);
        connection.query(query,step3_loadDatabase );
    }


    function  step3_loadDatabase(err, rows) {
        console.log('CREATE DATABASE', err);
        //read initial database file
        var file_sql = __dirname+'/database.sql'
        file_sql = sh.fs.resolve(file_sql);
        var contents = sh.readFile(file_sql); //verify file can be read

        //run mysql to import database file
        var child_process = require('child_process');
        var cmd = "mysql -u "+cluster_settings.mysql.user +
            " --password="+cluster_settings.mysql.pass +" " +
            cluster_settings.mysql.databasename + " < " + file_sql
        console.log('runnning cmd...');
        child_process.exec(cmd, function (err, stdout, stderr) {
            console.error(err);
            console.error(stderr);
            console.log(stdout);
            process.exit(0);
        });


    }
});


//cannot create user after connection made ...
var username = "'"+cluster_settings.mysql.mysql_user+
    "'@'localhost'";
function createUser() {

    var sql = ''
    sql += " CREATE USER "+username+" IDENTIFIED BY '"+cluster_settings.mysql.mysql_pass+"';"
    // sql +=sh.n + " GRANT ALL PRIVILEGES ON *.* TO "+username+";"
    // sql +=sh.n +  " FLUSH PRIVILEGES;"

    console.log(sql)
    connection.query(sql, function(err, rows) {
        // connected! (unless `err` is set)
        console.log('Added user  to  DATABASE');
        if ( err != null ) {
            console.error(err)
        }
        assignPriv();
    });

}


function assignPriv() {
    var username = "'"+cluster_settings.mysql.mysql_user+
        "'@'localhost'";
    var sql = ''
    // sql += " CREATE USER "+username+" IDENTIFIED BY '"+cluster_settings.mysql.mysql_pass+"';"
    sql +=  " GRANT ALL PRIVILEGES ON *.* TO "+username+";"

    console.log(sql)
    connection.query(sql, function(err, rows) {
        // connected! (unless `err` is set)
        console.log('assignPriv OK');
        if ( err != null ) {
            console.error(err)
        }
        flushPR();
    });
}


function flushPR() {
    var sql = ''
    sql +=sh.n +  " FLUSH PRIVILEGES;"
    console.log(sql);
    connection.query(sql, function(err, rows) {
        console.log('FLUSH PRIVILEGES  to  DATABASE');
        if ( err != null ) {
            console.error(err)
        }
        process.exit();
    });

}