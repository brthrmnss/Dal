//File.js

// /models/file.js

module.exports = function (sequelize, DataTypes) {

    //define model ==================
    return sequelize.define('File', {
            originalFilename: DataTypes.STRING(256),
            shortUrl: DataTypes.STRING(256),
            fileType: DataTypes.STRING(256),
            extension: DataTypes.STRING(256),
            fileSize: DataTypes.INTEGER(15),
            localFilePath: DataTypes.STRING(256),
            userId: DataTypes.INTEGER,
            totalDownload: DataTypes.INTEGER,
            uploadedIP: DataTypes.STRING(15),
            uploadedDate: {
                type: DataTypes.DATE,
                allowNull: true,
                defaultValue: null
            },
            statusId: DataTypes.INTEGER,
            visits: DataTypes.INTEGER,
            lastAccessed: {
                type: DataTypes.DATE,
                allowNull: true,
                defaultValue: null
            },
            deleteHash: DataTypes.STRING(256),
            folderId: DataTypes.INTEGER,
            serverId: DataTypes.INTEGER,
            accessPassword: DataTypes.STRING(256),
            ipAddress: DataTypes.STRING(256)
        },
        {	//options
            tableName: 'file',
            timestamps: false
        });

}
