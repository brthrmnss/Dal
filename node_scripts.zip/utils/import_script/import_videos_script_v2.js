//script that gets 2 folders and records media


var argv = require('minimist')(process.argv.slice(2)),
    fs = require("fs-extra"),
    Sequelize = require('sequelize'),
    path = require("path"),
    walk = require("walk"),
    async = require("async"),
    md5 = require("MD5"),
    sanitize = require("sanitize-filename"),
    os = require("os"),
    options = {},
    walker = {},
    filesToImport = [];


var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');

function ImportVideosScriptV2() {
    var p = ImportVideosScriptV2.prototype;
    p = this;
    var self = this;
    p.init = function init(config) {
        config = sh.dv(config, {});
        var rh = require('rhelpers');

        function getConfig() {
            var cluster_settings = rh.loadRServerConfig(true);
            var sequelize = rh.getSequelize(true, false, false)

            var output = {}
            output.sequelize = sequelize;
            output.settings = cluster_settings;
            return output;
        }

        self.sequelize = getConfig().sequelize;
        var server_settings = rh.loadRServerConfig(true);

        // ----- gather and set import / export folder
        var importFolder = path.normalize('/home/media/incoming'),
            destFolder = path.normalize('/home/media/incoming');

        //import default contents in ritv
        var importFolder = path.resolve(__dirname + '/' + '../../../code-yeti/data/demo_videos'),
            destFolder = path.resolve(__dirname + '/' + '../../../code-yeti/data/demo_videos');

        if (typeof(argv.i) !== 'undefined')
            importFolder = path.normalize(argv.i)
        if (typeof(argv.o) !== 'undefined')
            destFolder = path.normalize(argv.o)
        if (typeof(argv.v) !== 'undefined')
            config.verbose = argv.o

        if (config.importFolder) {
            self.importFolder = importFolder;
        }
        if (config.destFolder) {
            self.destFolder = destFolder;
        }
        self.importFolder = importFolder;
        self.destFolder = destFolder;

        self.server_ip =  server_settings.ip;
        if (config.port) {
            self.server_ip += ':'+config.port;
        }

        self.settings = config;
        self.importVidoes();
    }

    p.importVidoes = function importVidoes() {
        //var FileModel	= sequelize.import("./../../utils/database/models/file.js");
        var FileModel = self.sequelize.import("./models/file.js");

        options = {
            followLinks: false,
            // directories with these keys will be skipped
            filters: ["Temp", "_Temp"]
        };

        self.data = {};

        self.data.counts  = {};
        self.data.counts.alreadyInDb = 0;
        self.data.counts.added = 0;

        // ----- walk directory
        console.log('searching: ', self.importFolder, ' for new files -> importing to :', self.destFolder);
        walker = walk.walk(self.importFolder, options);


        walker.on("names", function (root, nodeNamesArray) {
            //console.log( "in names handeler ",nodeNamesArray );
            nodeNamesArray.sort(function (a, b) {
                if (a > b) return 1;
                if (a < b) return -1;
                return 0;
            });
        });
        walker.on("directories", function (root, dirStatsArray, next) {
            // dirStatsArray is an array of `stat` objects with the additional attributes
            // * type,  * error,  * name
            //console.log( "in directory handeler ",dirStatsArray );
            next();
        });
        walker.on("file", function (root, fileStat, next) {
            //console.log( "- in file handeler, found: ",fileStat.name );

            var query = {
                where: {
                    originalFilename: fileStat.name,
                    ipAddress: self.server_ip
                }
            };

            //check to see if this is a new file
            FileModel.findAndCountAll(query)
                .then(function foundMatchingFile (result) {
                    if (result.count > 0) {
                        self.data.counts.alreadyInDb++
                        if ( self.settings.verbose == true )
                            console.log(fileStat.name, '   already in db skipping...');
                        next();
                    }
                    else {
                        if (isMediaFile(fileStat.name)) {
                            if ( self.settings.verbose == true )
                                console.log('   pushing ', fileStat.name, ' as a valid file');
                            fileStat.root = path.normalize(root);
                            filesToImport.push(fileStat);
                            next();
                        }
                        else {
                            //console.log('   ', fileStat.name , ' not valid media, next file');
                            next();
                        }

                    }

                });

        });
        walker.on("errors", function (root, nodeStatsArray, next) {
            console.log('error orccured');
            next();
        });
        walker.on("end", function () {
            console.log("end handeler:");
            console.log('--- ', self.data.counts.alreadyInDb, 'old files found')
            console.log('--- ', filesToImport.length, 'new files found')
            //go over all these damn files
            if (filesToImport.length > 0) {

                console.log(':: moving and syncing ', filesToImport.length, 'files')

                async.eachSeries(filesToImport, addToDBAndMoveOnSuccess, function () {

                    console.log('all done moving files');

                    self.sequelize.sync({'force': false}).then(function (err) {
                        console.log('connected and sync\'d');
                    });

                    return;
                });
            }
            else {
                return;
            }

        });


        function addToDBAndMoveOnSuccess(fileStat, next) {
            //console.log( fileStat );
            setTimeout(function () {
                var filePath = path.join(fileStat.root, fileStat.name);
                if (saveFileToDatabase(filePath)) {
                    //moveFileToOutputFolder(  filePath );
                    next();
                }
                else {
                    if ( self.settings.verbose == true )
                        console.log('error adding to database');
                    next();
                }

            }, 0);
        }

        function isMediaFile(filename) {
            var ext = path.extname(filename);
            if (ext == '.mp4' || ext == '.mpg' || ext == '.mov' || ext == '.avi' || ext == '.m4v' || ext == '.mkv')
                return true;
            else
                return false;
        }

        function isNewFile(filename) {


        }

        function saveFileToDatabase(filename) {
            if ( self.settings.verbose == true )
                console.log('saving:', filename);
            //console.log( importFolder, path.dirname(filename) );
            var filename = filename,
                _stats = fs.stat(filename),
                timestamp_now = Date.now(),
                localFilePath = path.dirname(filename);
            var fileupload = {
                destFolder: encodeURIComponent(filename),
                file_size: fs.lstatSync(filename).size,
                delete_url: '~d?' + 'delete_hash',
                info_url: '~i?' + 'delete_hash',
                originalFilename: path.basename(filename),
                delete_type: 'DELETE',
                delete_hash: 'delete_hash', // $deleteHash = md5($fileUpload->name . microtime());
                shortCode: md5(filename + timestamp_now),
                user_id: 999,
                totalDownload: 0,
                uploadedID: 'ip_address',
                uploadedDate: timestamp_now,
                statusId: 1,
                folderId: null,
                severId: 1,
                extension: path.extname(filename).replace('.', ''),
                mediaRelativeFilePath: localFilePath,//file path relative to our media folder
                fileType: 'video/mp4'
            };

            if ( self.settings.verbose == true )
                console.log('filesize=', fileupload.file_size);

            var len = fileupload.mediaRelativeFilePath.length;

            if (fileupload.mediaRelativeFilePath[len - 1] != '/' && len > 0) fileupload.mediaRelativeFilePath += "/";

            fileupload.mediaRelativeFilePath = fileupload.mediaRelativeFilePath.replace(self.destFolder, "");

            if ( self.settings.verbose == true )
                console.log('saving to database:=', fileupload.mediaRelativeFilePath, ' :: ', localFilePath, ' :: ', self.destFolder, ' :: ');


            var file = {  // set the exam name (comes from the request)

                originalFilename: fileupload.originalFilename,
                shortUrl: 'media/' + fileupload.mediaRelativeFilePath + fileupload.originalFilename,//fileupload.shortCode,
                fileType: fileupload.fileType,
                extension: fileupload.extension,
                fileSize: parseInt(fileupload.file_size),
                localFilePath: path.join('incoming/' + fileupload.mediaRelativeFilePath + '/' + fileupload.originalFilename),//fileupload.localFilePath,
                userId: fileupload.user_id,
                totalDownload: fileupload.totalDownload,
                uploadedIP: fileupload.uploadedID,
                uploadedDate: fileupload.uploadedDate,
                statusId: fileupload.statusId,
                visits: fileupload.totalDownload,
                deleteHash: fileupload.delete_url,
                folderId: fileupload.severId,
                serverId: fileupload.severId,
                ipAddress: self.server_ip,
                machineName: os.hostname()
            }


            //rajesh: Override this settings.
            //if input and output dirs are the same, store teh exact file location
            if (self.importFolder == self.destFolder) {
                file.shortUrl = 'media/' + filename
                file.localFilePath = filename
            }
            ;


            FileModel.create(file)
                .then(function (file, created) {
                    if ( self.settings.verbose == true )
                        console.log('adding')
                    return true;

                })
                .error(function (error) {
                    if ( self.settings.verbose == true )
                        console.error('error', error);
                    return false;
                });

            /*console.log( fileupload );
             FileModel.findAll().complete(function(err,files){
             if( err ) {console.log(err);}
             console.log( 'from database' );
             console.log( files );
             });*/

        }

        function moveFileToOutputFolder(filename) {
            fs.move(filename, path.join(destFolder, path.basename(filename)), function (err) {
                if ( self.settings.verbose == true )
                    console.log("done moving", filename);
            })
        }
    }

    p.proc = function debugLogger() {
        if (self.silent == true) {
            return
        }
        sh.sLog(arguments)
    }

}

exports.ImportVideosScriptV2 = ImportVideosScriptV2;

if (module.parent == null) {
    var i = new ImportVideosScriptV2();
    //i.init();
    i.init({port:11111});
    return;
}




