//script that gets 2 folders and records media


var argv 			= require('minimist')(process.argv.slice(2)),
	fs 				= require("fs-extra"),
	Sequelize		= require('sequelize'),
	path 			= require("path"),
	walk 			= require("walk"),
	async			= require("async"),
	md5				= require("MD5"),
	sanitize 		= require("sanitize-filename"),
	os				= require("os"),
	options			= {},
	walker			= {},
	filesToImport 	= [];


// ----- gather and set import / export folder
var importFolder 	= path.normalize( '/home/media/incoming' ),
	destFolder		= path.normalize( '/home/media/incoming' );

//import default contents in ritv
var importFolder 	= path.resolve( '../../../code-yeti/data/demo_videos' ),
	destFolder		= path.resolve( '../../../code-yeti/data/demo_videos' );

if( typeof(argv.i) !== 'undefined' )
	importFolder = path.normalize( argv.i )
if( typeof(argv.o) !== 'undefined' )
	destFolder = path.normalize( argv.o )

var rh = require('rhelpers');
function getConfig() {

	var cluster_settings   = rh.loadRServerConfig(true);
	var sequelize = rh.getSequelize(true, false, false)


	var output = {}
	output.sequelize = sequelize;
	output.settings = cluster_settings;
	return output;
}

var sequelize = getConfig().sequelize;
var server_settings   = rh.loadRServerConfig(true);

//var FileModel	= sequelize.import("./../../utils/database/models/file.js");
var FileModel	= sequelize.import("./models/file.js");

options = {
	followLinks: false,
	// directories with these keys will be skipped
	filters: ["Temp", "_Temp"]
};



// ----- walk directory
console.log( 'searching: ',importFolder,' for new files -> importing to :', destFolder );
walker = walk.walk( importFolder , options);


walker.on("names", function (root, nodeNamesArray) {
	//console.log( "in names handeler ",nodeNamesArray );
	nodeNamesArray.sort(function (a, b) {
		if (a > b) return 1;
		if (a < b) return -1;
		return 0;
	});
});
walker.on("directories", function (root, dirStatsArray, next) {
	// dirStatsArray is an array of `stat` objects with the additional attributes
	// * type,  * error,  * name
	//console.log( "in directory handeler ",dirStatsArray );
	next();
});
walker.on("file", function (root, fileStat, next) {
	//console.log( "- in file handeler, found: ",fileStat.name );


	//check to see if this is a new file
	FileModel.findAndCountAll({where: { originalFilename : fileStat.name  } })
		.then( function(result) {
			if( result.count > 0 ){
				console.log(fileStat.name, '   already in db skipping...');
				next();
			}
			else{
				if( isMediaFile(fileStat.name) ){
					console.log( '   pushing ',fileStat.name,' as a valid file' );
					fileStat.root = path.normalize( root );
					filesToImport.push( fileStat );
					next();
				}
				else{
					//console.log('   ', fileStat.name , ' not valid media, next file');
					next();
				}

			}

		});

});
walker.on("errors", function (root, nodeStatsArray, next) {
	console.log('error orccured');
	next();
});
walker.on("end", function () {
	console.log("end handeler:");
	console.log('--- ', filesToImport.length, 'new files found')
	//go over all these damn files
	if(filesToImport.length > 0){

		console.log(':: moving and syncing ', filesToImport.length, 'files')

		async.eachSeries( filesToImport, addToDBAndMoveOnSuccess ,function(){

			console.log('all done moving files');

			sequelize.sync({'force':false}).then(function(err){
				console.log('connected and sync\'d');
			});

			return;
		} );
	}
	else{
		return;
	}

});




function addToDBAndMoveOnSuccess(fileStat, next){
	//console.log( fileStat );
	setTimeout(function(){
		var filePath = path.join( fileStat.root , fileStat.name );
		if(saveFileToDatabase( filePath )){
			//moveFileToOutputFolder(  filePath );
			next();
		}
		else{
			console.log('error adding to database');
			next();
		}

	}, 0);
}

function isMediaFile( filename ){
	var ext = path.extname( filename );
	if( ext == '.mp4' || ext == '.mpg' || ext == '.mov' || ext == '.avi' || ext == '.m4v' || ext == '.mkv')
		return true;
	else
		return false;
}

function isNewFile( filename ){


}
function saveFileToDatabase(filename){
	console.log('saving:', filename);
	//console.log( importFolder, path.dirname(filename) );
	var filename = filename,
		_stats			= fs.stat( filename ),
		timestamp_now 	= Date.now(),
		localFilePath 	= path.dirname( filename );
	var fileupload = {
			destFolder 	: encodeURIComponent(filename),
			file_size 	: fs.lstatSync(filename).size,
			delete_url	: '~d?' + 'delete_hash',
			info_url	: '~i?' + 'delete_hash',
			originalFilename : path.basename( filename ),
			delete_type	: 'DELETE',
			delete_hash	: 'delete_hash', // $deleteHash = md5($fileUpload->name . microtime());
			shortCode	: md5(filename + timestamp_now),
			user_id		: 999,
			totalDownload: 0,
			uploadedID	: 'ip_address',
			uploadedDate: timestamp_now,
			statusId	: 1,
			folderId 	: null,
			severId 	: 1,
			extension	: path.extname(filename).replace('.',''),
			mediaRelativeFilePath : localFilePath,//file path relative to our media folder
			fileType	: 'video/mp4'
		};

	console.log( 'filesize=',fileupload.file_size );

	var len = fileupload.mediaRelativeFilePath.length;

	if( fileupload.mediaRelativeFilePath[ len -1 ] != '/' && len > 0 ) fileupload.mediaRelativeFilePath += "/";

	fileupload.mediaRelativeFilePath = fileupload.mediaRelativeFilePath.replace(destFolder,"");
	console.log( 'saving to database:=',fileupload.mediaRelativeFilePath, ' :: ' , localFilePath , ' :: ' , destFolder, ' :: ' );



	var file = {  // set the exam name (comes from the request)

		originalFilename	: fileupload.originalFilename,
		shortUrl			: 'media/' + fileupload.mediaRelativeFilePath + fileupload.originalFilename,//fileupload.shortCode,
		fileType			: fileupload.fileType,
		extension			: fileupload.extension,
		fileSize			: parseInt( fileupload.file_size ),
		localFilePath		: path.join( 'incoming/' + fileupload.mediaRelativeFilePath + '/' + fileupload.originalFilename ),//fileupload.localFilePath,
		userId				: fileupload.user_id,
		totalDownload		: fileupload.totalDownload,
		uploadedIP			: fileupload.uploadedID,
		uploadedDate		: fileupload.uploadedDate,
		statusId			: fileupload.statusId,
		visits				: fileupload.totalDownload,
		deleteHash			: fileupload.delete_url,
		folderId			: fileupload.severId,
		serverId			: fileupload.severId,
		ipAddress			: server_settings.ip,
		machineName			: os.hostname()
	}


	//rajesh: Override this settings.
	//if input and output dirs are the same, store teh exact file location
	if ( importFolder == destFolder ) {
		file.shortUrl = 'media/' + filename
		file.localFilePath = filename
	};


	FileModel.create(file)
		.then(function(file, created){
			console.log('adding')
			return true;

		})
		.error(function(error){
			console.error('error', error);
			return false;
		});

	/*console.log( fileupload );
	 FileModel.findAll().complete(function(err,files){
	 if( err ) {console.log(err);}
	 console.log( 'from database' );
	 console.log( files );
	 });*/

}

function moveFileToOutputFolder(filename){
	fs.move(  filename, path.join(destFolder, path.basename( filename ) ) , function(err){
		console.log("done moving", filename );
	} )
}