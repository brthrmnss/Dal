node script.js  -i /src/videoproject/Code/code-yeti/data/demo_videos  -o /rvids

#/src/videoproject/Code/code-overlord/importscript/
# node script.js -i /home/media/incoming  -o /home/media/incoming