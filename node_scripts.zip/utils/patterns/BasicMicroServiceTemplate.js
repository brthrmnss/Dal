var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');
var rh = require('rhelpers');
var express    = require('express');

//create faux class
function BasicMicroServiceTemplate() {
    var p = BasicMicroServiceTemplate.prototype;
    p = this;
    var self = this;
    p.init = function init(config) {
        self.settings = {};     //store settings and values
        self.settings.port = 3001;

        self.server_config = rh.loadRServerConfig(true);  //load server config

        self.app = express();   //create express server
        self.createRoutes();    //decorate express server

        self.app.listen(self.settings.port);
        self.proc('started server on', self.settings.port);
    }

    p.createRoutes = function createRoutes() {
        self.app.post('/upload', function (req, res) {});
    }

    p.test = function test() {
        require()
    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return
        }
        sh.sLog(arguments)
    }
}

exports.BasicMicroServiceTemplate = BasicMicroServiceTemplate;

if (module.parent == null) {
    var service = new BasicMicroServiceTemplate();
    service.init();
}



