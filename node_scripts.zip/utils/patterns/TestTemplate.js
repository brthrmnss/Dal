var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');
var EasyRemoteTester = shelpers.EasyRemoteTester;

//create faux class
function TestTemplate() {
    var p = TestTemplate.prototype;
    p = this;
    var self = this;
    p.init = function init(config) {
        self.settings = {};     //store settings and values

        self.server_config = rh.loadRServerConfig(true);  //load server config

        self.app = express();   //create express server
        self.createRoutes();    //decorate express server
    }

    p.createRoutes = function createRoutes() {
        self.app.post('/upload', function (req, res) {});
    }

    p.test = function test() {
        //create helper
        var c = sh.clone(self.settings.files)
        //c.baseUrl = 'localhost:'+self.settings.files.port;
        c.fxDone = fxDone;
        var t = EasyRemoteTester.create('test Real Content Provider API', c);

        //define urls
        var urls = {}
        urls.search = t.utils.createTestingUrl('api/find_content')
        urls.getContent = t.utils.createTestingUrl('api/get_content')
        urls.file = {};
        //TODO: store on rest helper cpy from props in rest helper .
        urls.file.create = t.utils.createTestingUrl('api/file/create');
        urls.file.delete = t.utils.createTestingUrl('api/file/delete');



        urls.verifyConsumer = t.utils.createTestingUrl('api/verify');
        t.settings.portOverride = self.settings.loginAPI.port;
        urls.login = t.utils.createTestingUrl('api/login');
        t.settings.portOverride = null;


        if ( self.login != false ) {

            t.add(function doSearchWithNoLogin() {
                    t.quickRequest( urls.search,
                        'get', result, {originalFilename: "randomTask"})
                    function result(body) {
                        console.log(body);
                        t.assert(body.success==false, 'no ok');
                        t.cb();
                    }
                }
            );

            self.cQS.testUtils.loginFail(t, urls.login, 'mark', 'randomTask')
            self.cQS.testUtils.login(t, urls.login, 'mark', 'randomTask2')
            self.cQS.testUtils.verifyKey(t, urls.verifyConsumer, t.key)
        }
        t.add(function doSearchAfterLogin() {
                t.quickRequest( urls.search,
                    'get', result, {originalFilename: "randomTask"})
                function result(body) {
                    t.assert(body.length>=0, 'post-verify did not let me do a search');
                    t.cb();
                }
            }
        );

        //don't have imdb in the searches yet
        t.xadd(function doSearchWithIMDBId() {
                t.quickRequest( urls.search,
                    'get', result, {imdb_id: "tt101"})
                function result(body) {
                    t.assert(body.length>0, 'post-verify did not let me do a search');
                    t.cb();
                }
            }
        );


        t.add(function createMovie_to_search() {
                t.quickRequest( urls.file.create,
                    'get', result, {originalFilename: 'jack.mp4'});
                function result(body) {
                    console.log('body', body);
                    t.data.idOfFakeMovie = body;

                    // t.content = body[0];
                    // asdf.g
                    if ( body.success==false){
                        throw 'not logged in anymore';
                    };
                    t.assert(parseInt(body) > 0, 'could not create new content item .... ');
                    t.cb();
                }
            }
        );


        t.add(function doSearchWithLikeInName_VerifySearchWorks() {
                t.quickRequest( urls.search,
                    'get', result, {originalFilename: {like:"%mp4%"}});
                function result(body) {
                    console.log('body', body);
                    t.content = body[0];
                    if ( body.success==false){
                        throw 'not logged in anymore';
                    };
                    t.assert(body.length>0, 'post-verify did not let me do a search. Searched for mp4 got back 0 results .... ');
                    t.cb();
                }
            }
        );

    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return
        }
        sh.sLog(arguments)
    }
}

exports.TestTemplate = TestTemplate;

if (module.parent == null) {
    var test = new TestTemplate();
    test.init();
}





p.test = function test() {
    var baseUrl = 'http://127.0.0.1:'+self.settings.port;
    var t = EasyRemoteTester.create('Test Channel Server basics',{showBody:false});
    var data = {};
    t.settings.baseUrl = baseUrl;
    var urls = {};
    urls.notes = {};
    urls.upload = t.utils.createTestingUrl('upload');
    urls.getRecent = t.utils.createTestingUrl('getRecent');
    urls.deleteChannel = t.utils.createTestingUrl('deleteChanZ');
    urls.streamI = t.utils.createTestingUrl('index.html');

    var localDir = __dirname + '/';
    var fileTestVidUpload =  'test_vid.mp4';


    var dirChannel =  localDir + 'channels/cnn/'
    //sh.copyFile2(fileTestVidUpload, dirChannel+ 'video4.flv')
    //sh.copyFile2(fileTestVidUpload, dirChannel + 'video1.flv')

    var t2 = t.clone('test a few voices notes');
    t2.getR(urls.upload).with({channel:'cnn'}).upload(localDir+fileTestVidUpload)
        .bodyHas('status').notEmpty()
        .fxDone(function deleteFileafterTest() {
            sh.deleteFile(localDir + 'channels/cnn/'+fileTestVidUpload)
        })
    //t2.getR(urls.say)n.upload('config.json').bodyHas('status').notEmpty()
    var nextSet = t2.getR(urls.getRecent).with({channel:'cnn'}).bodyHas('status').notEmpty()
    function testUploadingFiles_Simple() {

        if (self.settings.testResizingChannelDir == true ) {
            //copy files over ... or use temp dir and move temp dir back
            //we forced max files to be 2, so the 4h video should appear
            nextSet.bodyHas('files').includesAsString('video4.flv')
                //we forced max files to be 2 so the first video should not appear in the recent files
                .bodyHas('files').doesNotHaveAsString('video1.flv')
            //remove files afterwards
        }
    }


    t2.getR(urls.streamI).with(); //isValidFile

    //commented out ot prevent deleting automatically
    //t2.getR(urls.deleteChannel+'?channel'+'='+'cnn').bodyHas('status').notEmpty()
    //place 10 uploads in dir

    var timeOfFileCreation = new Date();
    function test_UploadAndDeletingUploadedFiles() {
        //place uploads in dirs
        //goal: does sorting work as expected?
        function uploadANewFile () {
            console.log('new file')
            var t2 = t.clone('test a file upload');
            //timeOfFileCreation.setTime(new Date().getTime() - Math.random() * 24 * 60 * 60 * 1000)
            timeOfFileCreation.setTime(new Date().getTime() + 1.5 * 60 * 60 * 1000)
            var newName = sh.getTimeStamp(timeOfFileCreation) + '.flv'
            t2.getR(urls.upload).with({channel: 'cnn', renameUploadedFileTo: newName})
                .upload(localDir + fileTestVidUpload)
                .bodyHas('status').notEmpty()
                .fxDone(function deleteFileafterTest() {
                    console.log('uploaded ...')
                    //sh.deleteFile(localDir + 'channels/cnn/'+newName)
                })
            var nextSet = t2.getR(urls.getRecent).with({channel: 'cnn'}).bodyHas('status').notEmpty()

        }
        uploadANewFile()
        setInterval( uploadANewFile,  1000)
    }

    //test_UploadAndDeletingUploadedFiles();

    // t2.getR(urls.fileChannel).with(); //isValidFile
    return;

}


