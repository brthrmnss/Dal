var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');
var EasyRemoteTester = shelpers.EasyRemoteTester;

//create faux class
function TestTemplateChainingAPI() {
    var p = TestTemplateChainingAPI.prototype;
    p = this;
    var self = this;
    p.init = function init(config) {
    }

    p.test = function test() {

        var baseUrl = 'http://127.0.0.1:'+self.settings.port;
        var t = EasyRemoteTester.create('Test Channel Server basics',{showBody:false});
        var data = {};
        t.settings.baseUrl = baseUrl;
        var urls = {};
        urls.notes = {};
        urls.upload = t.utils.createTestingUrl('upload');
        urls.getRecent = t.utils.createTestingUrl('getRecent');
        urls.deleteChannel = t.utils.createTestingUrl('deleteChanZ');
        urls.streamI = t.utils.createTestingUrl('index.html');

        var localDir = __dirname + '/';
        var fileTestVidUpload =  'test_vid.mp4';


        var dirChannel =  localDir + 'channels/cnn/'
        //sh.copyFile2(fileTestVidUpload, dirChannel+ 'video4.flv')
        //sh.copyFile2(fileTestVidUpload, dirChannel + 'video1.flv')

        var t2 = t.clone('test a few voices notes');
        t2.getR(urls.upload).with({channel:'cnn'}).upload(localDir+fileTestVidUpload)
            .bodyHas('status').notEmpty()
            .fxDone(function deleteFileafterTest() {
                sh.deleteFile(localDir + 'channels/cnn/'+fileTestVidUpload)
            })
        //t2.getR(urls.say)n.upload('config.json').bodyHas('status').notEmpty()
        var nextSet = t2.getR(urls.getRecent).with({channel:'cnn'}).bodyHas('status').notEmpty()
        function testUploadingFiles_Simple() {

            if (self.settings.testResizingChannelDir == true ) {
                //copy files over ... or use temp dir and move temp dir back
                //we forced max files to be 2, so the 4h video should appear
                nextSet.bodyHas('files').includesAsString('video4.flv')
                    //we forced max files to be 2 so the first video should not appear in the recent files
                    .bodyHas('files').doesNotHaveAsString('video1.flv')
                //remove files afterwards
            }
        }


        t2.getR(urls.streamI).with(); //isValidFile

        //commented out ot prevent deleting automatically
        //t2.getR(urls.deleteChannel+'?channel'+'='+'cnn').bodyHas('status').notEmpty()
        //place 10 uploads in dir

        var timeOfFileCreation = new Date();
        function test_UploadAndDeletingUploadedFiles() {
            //place uploads in dirs
            //goal: does sorting work as expected?
            function uploadANewFile () {
                console.log('new file')
                var t2 = t.clone('test a file upload');
                //timeOfFileCreation.setTime(new Date().getTime() - Math.random() * 24 * 60 * 60 * 1000)
                timeOfFileCreation.setTime(new Date().getTime() + 1.5 * 60 * 60 * 1000)
                var newName = sh.getTimeStamp(timeOfFileCreation) + '.flv'
                t2.getR(urls.upload).with({channel: 'cnn', renameUploadedFileTo: newName})
                    .upload(localDir + fileTestVidUpload)
                    .bodyHas('status').notEmpty()
                    .fxDone(function deleteFileafterTest() {
                        console.log('uploaded ...')
                        //sh.deleteFile(localDir + 'channels/cnn/'+newName)
                    })
                var nextSet = t2.getR(urls.getRecent).with({channel: 'cnn'}).bodyHas('status').notEmpty()

            }
            uploadANewFile()
            setInterval( uploadANewFile,  1000)
        }

        //test_UploadAndDeletingUploadedFiles();
        // t2.getR(urls.fileChannel).with(); //isValidFile
        return;
    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return
        }
        sh.sLog(arguments)
    }
}

exports.TestTemplateChainingAPI = TestTemplateChainingAPI;

if (module.parent == null) {
    var test = new TestTemplateChainingAPI();
    test.init();
}
