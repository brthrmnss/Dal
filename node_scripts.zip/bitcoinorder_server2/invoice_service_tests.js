/**
 * Created by user on 1/13/16.
 */
/**
 * Created by user on 1/3/16.
 */
"use strict";
var _ = require('underscore');

var rh = require('rhelpers');
var shelpers = require('shelpers');
var EasyRemoteTester = shelpers.EasyRemoteTester;



var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');

function invoice_service_tests() {
    var p = invoice_service_tests.prototype;
    p = this;
    var self = this;
    p.start = function method1(url, appCode) {
        console.log('starting invoice_service test token9999');


        var config = rh.loadRServerConfig(true);

        //make chain
        var t = EasyRemoteTester.create('Test Bitcoin Integration',{showBody:true});

        //create urls
        var baseUrl = 'http://127.0.0.1:'+ config.bitcoinAPI.api_port;
        t.settings.baseUrl = baseUrl;
        var urls = {};
        urls.paymentCreate = t.utils.createTestingUrl('paymentCreate');
        urls.orderGet = t.utils.createTestingUrl('orderGet');

        t.settings.baseUrl = 'http://127.0.0.1:'+ + config.bitcoinAPI.html_port;
        urls.paymentView = t.utils.createTestingUrl('paymentView');

        //setup some test-wide data
        var username = 'admin';


        //define tests
        t.getR(urls.paymentCreate).with({username: 'markyY', product: 1})
            .why('try to create payment with bad username')
            // .bodyHas('status').notEmpty()
            .fxDone(function syncComplete(result) {
                t.assert(result.payment.error == 'cannot find user')
            });

        t.getR(urls.paymentCreate).with({username:username})
            // .bodyHas('status').notEmpty()
            .fxDone(function syncComplete(result) {
                t.assert(result.payment.error=='input is invalid', 'make a bad product did not produce correct error')
            });

        t.getR(urls.paymentCreate).with({username: username, product: 2})
            .why('test with bad product')
            .fxDone(function syncComplete(result) {
                t.assert(result.payment.error == 'product not found', 'make a bad product')
            });


        var reqData = {username: username, product: self.app.data.products.AutoPay };
        t.getR(urls.paymentCreate).with(reqData)
            .why('make new payment')
            // .storeHere('invoice_id', )
            .fxDone(function syncComplete(result) {
                console.log('user payment', result);
                t.assert(result.payment.invoice_id!=null, 'valid product not created')
                var invoice_id = result.payment.invoice_id;
                t.invoice_id = invoice_id;
                t.data.invoice_id = invoice_id;
                t.data.order_id = result.order_id;
            });


        var reqData = {username: username, product: self.app.data.products.MonthlyRenewal };
        t.getR(urls.paymentCreate).with(reqData)
            .why('make new payment')
            // .storeHere('invoice_id', )
            .fxDone(function syncComplete(result) {
                console.log(result);
                t.assert(result.payment.invoice_id!=null, 'valid product not created')
                var invoice_id = result.payment.invoice_id;
                t.invoice_id = invoice_id;
                t.data.invoice_id = invoice_id;
            });



        t.add(function fakePayingInvoices() {
            console.error('fakePayingInvoices', 'id', t.data.order_id)
            self.app.utils.payInvoice(t.data.order_id,
             function onCmdRun(address, data) {
                    //chain.data.address = address;
                 t.cb();
                });
        });

        t.wait(3)
        t.getR(urls.orderGet).before(function(){
            var req = {};
            req.id =  t.data.order_id;
            return req;
        })
            .why('verify order has been paid')
            // .storeHere('invoice_id', )
            .fxDone(function syncComplete(result) {

               // console.error('what is payment status', )
               /* self.app.data.status.successStates = [
                    self.app.data.status.paid,
                    self.app.data.status.completed;
                ]*/
                var compY = result.order.order_status == 'paid';
                if ( compY == false) {
                    compY = result.order.order_status == 'completed'
                }
                if ( compY == false) {
                    compY = result.order.order_status == 'recording'
                }
                if ( compY == false) {
                    compY = result.order.order_status == 'recorded'
                }
                if ( compY == false ) {
                    console.error(compY, result.order.order_status )
                }
                t.assert(compY, 'payment not paid ' + result.order.order_status);
            });
    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return
        }
        sh.sLog(arguments)
    }
}

exports.invoice_service_tests = invoice_service_tests;

if (module.parent == null) {

}


/*
improvements :
1. if username found, remove user
2. create user and see if applies payment
3. put html in subfolder, as in redeem server
4. allow user to make multiple payments
5. enable user with user_id ot make payments
6. why delete payments


deployment, nodejs implementation, download implenetation, clustering implementation
bitcoin server
credentail server -- i had to rewrite

 */
    //return;

