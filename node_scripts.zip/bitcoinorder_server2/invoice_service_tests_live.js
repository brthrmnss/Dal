/**
 * Created by user on 1/13/16.
 */
/**
 * Created by user on 1/3/16.
 */
"use strict";
var _ = require('underscore');

var rh = require('rhelpers');
var shelpers = require('shelpers');
var EasyRemoteTester = shelpers.EasyRemoteTester;



var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');

function invoice_service_tests_2() {
    var p = invoice_service_tests_2.prototype;
    p = this;
    var self = this;
    p.start = function method1(url, appCode) {
        console.log('starting invoice_service test token9999');


        var config = rh.loadRServerConfig(true);

        //make chain
        var t = EasyRemoteTester.create('Test Bitcoin Integration', {showBody: true});

        //create urls
        var baseUrl = 'http://127.0.0.1:' + config.bitcoinAPI.api_port;
        t.settings.baseUrl = baseUrl;
        var urls = {};
        urls.paymentCreate = t.utils.createTestingUrl('paymentCreate');
        urls.orderGet = t.utils.createTestingUrl('orderGet');

        t.settings.baseUrl = 'http://127.0.0.1:' + +config.bitcoinAPI.html_port;
        urls.paymentView = t.utils.createTestingUrl('paymentView');

        //setup some test-wide data
        var username = 'admin';


        //define tests


        var reqData = {username: username, product: self.app.data.products.MonthlyRenewal};
        t.getR(urls.paymentCreate).with(reqData)
            .why('make new payment')
            // .storeHere('invoice_id', )
            .fxDone(function syncComplete(result) {
                console.log('user payment', result);
                t.assert(result.payment.invoice_id != null, 'valid product not created')
                var invoice_id = result.payment.invoice_id;
                t.invoice_id = invoice_id;
                t.data.invoice_id = invoice_id;
                t.data.order_id = result.order_id;
            });

        t.getR(urls.orderGet).before(function (req) {
            req.id = t.data.order_id;
            return req;
        })
            .why('verify order has been paid')
            .fxDone(function syncComplete(result) {
                console.log('user order', result.order);
                t.data.order = result.order;
                //t.assert(result.order.order_status == 'paid', 'payment not paid ');
            });


        t.add(function realPayingInvoices() {
            // console.error('fakePayingInvoices', 'id', t.data.order_id)
            var order = t.data.order;
            self.app.electrum_wallet.sendMoney(order.bitcoin_address, order.amount_btc,
                function onCmdRun(address, data) {
                    t.cb();
                });
        });


        t.data.convergeCheck = 0;
        t.data.maxCheckCount = 20;

        t.add(function testInvoicePaid() {
            console.error('testing invoice paid', 'id', t.data.order_id)
            t.quickRequest(urls.orderGet,
                'get', onGotPayment, {id: t.data.order_id});
            function onGotPayment(result) {
                console.log('result', result);

                var okStatus = self.app.utils.isOrderPaid(result.order);
                if (okStatus) {
                    console.error('what is this?...', 'what is paid')
                    t.cb();
                    return;
                }
                if (t.data.convergeCheck > t.data.maxCheckCount) {
                    t.assert(okStatus, 'payment not paid ')
                }


                t.data.convergeCheck++
                // t.addNext(t.wait(3));
                t.addNext(function delayed2_wait3() {
                    console.error('delayed3...');
                    setTimeout(function wait3() {
                        t.cb();
                    }, 30000);
                }, 0)

                t.addNext(testInvoicePaid, 1);
                t.cb();
            }

            return;
        });

        t.wait(3)
    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return
        }
        sh.sLog(arguments)
    }
}

exports.invoice_service_tests_2 = invoice_service_tests_2;

if (module.parent == null) {

}

