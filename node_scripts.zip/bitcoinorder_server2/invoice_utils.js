//"use strict";

var _ = require('lodash');
var async = require("async");
var MD5 = require('MD5');
var request = require('request');
var rh = require('rhelpers');

var shelpers = require('shelpers');
var sh = shelpers.shelpers;
var PromiseHelperV3 = shelpers.PromiseHelperV3;



var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');

function invoice_utils() {
    var p = invoice_utils.prototype;
    p = this;
    var self = this;
    p.init = function init(url, appCode) {
        var config = rh.loadRServerConfig(false);
        self.config = config;
        self.settings = config.bitcoinAPI;
        var renewal_price = self.settings.renewal_price;
        if ( renewal_price == null || isNaN(parseInt(renewal_price) )) {
            throw new Error('broken price ' + renewal_price)
        }
        self.db = rh.getSequelize(false, false, null,["btc_payment_addresses.js"]);
    }

    p.createNewPayment =  function createNewPayment( payment, callback, electrum_wallet ){
        var self = this;
        var user_id = payment.user_id;
        var count_query = { user_id:user_id }


        self.db.models.premium_order.count({where: count_query}).then( gatherExternalData );

        function gatherExternalData(count) {

            var paymentIndex = String(user_id).concat( _.padStart(count,4,'0') );//todo: insert this into database

            var token = {};
            var chain = new PromiseHelperV3();
            token.silentToken = true
            chain.wait = token.simulate == false;
            chain.startChain(token)
            chain.add(function findBTCPrice() {
                self.findBTCPrice( payment, function onGotPrice(e, paymentResult) {
                        //console.log('...', e, paymenti )
                        console.log('...', e, paymentResult )
                        payment.invoice_amtbtc = paymentResult.btc
                        payment.invoice_amt  = paymentResult.btc
                        payment.amount_btc = paymentResult.btc
                        payment.usd = paymentResult.usd
                        //asdf.g
                        chain.next()
                    }
                );
            });
            chain.add(function getNewPaymentAddress() {
                var date = new Date(payment.expireAt);
                date = null // TODO: How to add date?
                electrum_wallet.createInvoice(payment.amount_btc,'', onNewAddress2, date );
                function onNewAddress2(address, data){
                    if( address == false || address == null ){
                        callback(true,'error generating address');
                        self.proc('error getting new address');
                        return;
                    }

                    var result = {};
                    result.bitcoin_address = address;
                   // payment.bitcoin_address = address;
                    payment.bitcoin_address = address;
                    chain.results = result;
                    chain.err = null ;
                    chain.next();
                    //callback(null,result);
                }

            });
            chain.add(function sendResults() {
                var err = chain.err;
                var results = chain.results;
                if( !_.isNull(err) ) {
                    callback(false, err);
                    return;
                }
                //combine results and call callback
                var combinedResults = _.extend(payment, results.getNewPaymentAddress, results.findBTCPrice);
                callback( combinedResults );

            });

        }

    }

    p.findBTCPrice = function findBTCPrice(payment, callback, fxFaaaault) {

        var url = 'http://preev.com/pulse/units:btc+usd/sources:bitfinex+bitstamp+btce'
        request.get(url, function (error, response, body) {
            if (!error && response.statusCode == 200) {
                var json = JSON.parse(body);
                var price = json.btc.usd.bitstamp.last;
                price = self.settings.renewal_price/price;
                var result = {};
                result.btc =  price
                result.usd = self.settings.renewal_price;
                callback(null,result);
            }
            else {
                if ( fxFaaaault != null ) {
                    fxFaaaault(error)
                    return;
                }
                callback(error)
            }

        });


        return
        var url = 'https://blockchain.info/tobtc?currency=USD&value='+payment.invoice_amtusd;

        request.get(url, function (error, response, body) {
            if (!error && response.statusCode == 200) {
                var price_info = {};
                price_info.invoice_amt = Math.ceil( body / Math.pow(10,-8) );
                price_info.invoice_amtbtc = body;
                price_info.invoice_amtusd = 10 ;
                callback(null,price_info);
            }
            else
                callback(error)

        });
    }


    p.createPaymentPassword =  function createPaymentPassword(username) {
        return MD5( username + new Date() ).substr(-5);
    }

    p.createPaymentID = function createPaymentID(username) {
        var date = new Date();
        return date.getMonth() + date.getYear() + MD5( username + date );
    }

    p.findUsersPaymentWhere = function findUsersPaymentWhere(where, username, callback){
        //get user_id associated with username
        self.db.models.users.find({ where: { username: username } })
            .then(onUserSearchResult);
        function onUserSearchResult(user, err) {
            if( _.isNull(user) || err != null ) return null;

            var where_clause = _.extend(where, {user_id: user.id})

            //find payments matching where=where_clause
            self.db.models.premium_order.findAll({ where: where_clause})
                .then(function( payment, err){
                    callback( payment, user.id, username, err);
                })

        }

        return true;
    }

    p.findPaymentByPaymentHash = function findPaymentByPaymentHash(payment_hash , callback) {
        //find payment
        self.db.models.premium_order.find({
            where: {
                payment_hash: payment_hash
            }
        }).then(function( payment ){
            var self = this;
            if( _.isNull(payment) ){
                callback(null);
                return
            }
            self.payment = payment.dataValues;
            self.db.models.users.find({
                where: {
                    id: payment.user_id
                }
            }).then( function(user){
                self.payment.username = user.username;
                callback(payment);
            } )
        })


    }

    p.insertOrderIntoDatabase =  function insertOrderIntoDatabase(payment, callback) {
        self.proc('insert', payment)
        self.db.models.premium_order.create({
            user_id: payment.user_id,
            product_id: payment.product_id,
            payment_hash: payment.invoice_id,
            payment_sequence: payment.payment_sequence,
            days: 30,
            amount: payment.invoice_amt,
            amount_usd: payment.invoice_amtusd,
            amount_btc: payment.invoice_amtbtc,
            bitcoin_address: payment.bitcoin_address,
            secret: payment.secret,
            order_status: 'PENDING',
            callback_url: payment.callback_url,
            expireAt: payment.expireAt

        }).then(function(order,err){
            callback( { order: order, err: err } );
        })
    }

    p.MarkPaymentCancelled = function MarkPaymentCancelled( callback ) {
        self.db.models.premium_order.updateAttributes({
            order_status:'cancelled'
        }).then(callback);
    }



    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return
        }
        sh.sLog(arguments)
    }
}

exports.invoice_utils = invoice_utils;

if (module.parent == null) {

}



