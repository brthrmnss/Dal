"use strict";
//node_modules
var _ = require('underscore');
var rh = require('rhelpers');

var server_settings = rh.loadRServerConfig(true);
var db = rh.getSequelize(false, false, null, ["btc_payment_addresses.js"]);
var sequelize = rh.getSequelize(false, false, null, ['payment_log.js']);

var order_mdl = sequelize.models.premium_order;
var paylog_mdl = sequelize.models.payment_log;
var user_mdl = sequelize.models.users;


var account_extender = {
	exec: function( cmd ) {

		_(cmd).defaults({ action: 'no_op', callback: _.noop });
		console.log('called exec - got: ', cmd.action, ' as action');

		if( cmd.action.indexOf('order_complete') > -1 ) {

			if( _(cmd.order).isUndefined() ) return;
			console.log('**CHILD::will upgrade this payment:', _.propertyOf(cmd.order)('id'));
			onOrderFoundTobeComplete(cmd.order, cmd.callback);

		}
	}
};

module.exports = { execute: account_extender.exec };

//ops

function onOrderFoundTobeComplete(order, callback){
	recordPaymentAndExtendUserAccount(order, function(isSuccess) {

		if (!isSuccess) {
			console.log('ERROR: Failed recording payment to user account');
			return false//todo:send error to process??
		}

		onUpgradedSuccesfully(order);
		callback({ action: 'payment_recorded', bitcoin_address: order.bitcoin_address, order_id: order.id });

	});

}

function onUpgradedSuccesfully(order){

	console.log('user expanded');
	order_mdl.markRecordedByID( order.id )
	recordEvent(
		{ action : 'COMPLETE: account updated',  status: 'complete' },
		{ transaction_hash: order.payment_hash, order_info: order },
		function(logline){ console.log('recorded successfully'); });

}

function recordPaymentAndExtendUserAccount (order, callback){
	// extend/upgrade user
	var userid = order.user_id;
	var paymentSequence = order.payment_sequence;
	var expirationExtensionDays = ( server_settings && server_settings.bitcoinAPI.renewal_length_days ) || 30;
	var newUserType = 'paid user';
	var currTime = new Date();

	// update user account to premium
	user_mdl.getUserWhere( {id:userid} )
		.then(function(user){

			//todo:error checking
			if(!user){
				console.log('error finding user');
				//todo: log this
				return false;
			}

			var usrLastPaySequence = user.lastPaymentSequence;

			if( usrLastPaySequence >= paymentSequence ) {
				console.log('payment already recorded',paymentSequence);
				callback(true);
				return true;
			} else if( usrLastPaySequence + 1 !== paymentSequence ) {
				console.log('payment sequence is off',paymentSequence);
				callback(false);
				return false;
			}

			var currExpiryDate = user.paidExpiryDate;
			if (currExpiryDate < currTime) currExpiryDate = currTime;// add onto existing period if less than today

			var newExpiryDate = new Date( currExpiryDate.getTime() + ( expirationExtensionDays * 24 * 60 * 60 * 1000 ) );

			user.level = (user.level == 'admin')? user.level : newUserType;
			user.paidExpiryDate = newExpiryDate;
			user.lastPayment = currTime;
			user.lastPaymentSequence = paymentSequence;

			// update user account to premium
			user.save();
			callback(true);

		});
}


function recordEvent( action, details, callback) {
	//insert into payment_log
	var details = (details || {});
	if( !action || !action.action || !action.status || !details || !_.isObject(details) ){
		throw "insufficent data given to recordEvent function";
		callback(false);
	}
	details.status          = action.status;
	details.payment_hash    = details.transaction_hash || '---';
	details.request_log     = JSON.stringify(details.request) || 'unsaved';
	details.currency_code   = 'btc';

	var extra_details   = _.omit( details,'request', 'request_log','payment_hash' );//remove anything we have already recorded
	details.description     = details.description || action.action + ':: -details::' + JSON.stringify( extra_details );

	//remaining details will get added to database if they are valid fields
	//(user_id, order_id, username, amount, amount_usd, amount_btc, currency_code )
	_.extend(details, extra_details);

	paylog_mdl.create(details).then(callback);
	return true
}