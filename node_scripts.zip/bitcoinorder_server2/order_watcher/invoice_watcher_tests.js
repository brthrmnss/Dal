"use strict";
var rh 			= require('rhelpers');
var shelpers 	= require('shelpers');
var EasyRemoteTester = shelpers.EasyRemoteTester;

/*
 improvements :
 1. if a payment is set to pending

 */



function invoice_watcher_tests() {
	var p = invoice_watcher_tests.prototype;
	p = this;
	var self = this;
	p.init = function init( ) {
		self.testIntegrationBitcoinAPIAndCallback();
	}



	p.testIntegrationBitcoinAPIAndCallback =  function testIntegrationBitcoinAPIAndCallback() {

		//make chain
		self.setupTestSuite('Test Invoice Watcher service');

		//setup some test-wide data
		var username = 'test';

	}

	p.setupTestSuite =  function setupTestSuite( name ) {

		self.db = rh.getSequelize(false, false, null, ["btc_payment_addresses.js"]);
		self.user_mdl = self.db.models.user;

		var testSuite = EasyRemoteTester.create( name, {showBody:true} );

		//create urls

		var baseUrl = 'http://127.0.0.1:'+ '8888';
		testSuite.settings.baseUrl = baseUrl;
		var testRoutes = {};
		testRoutes.paymentCreate = testSuite.utils.createTestingUrl('paymentCreate');

		testSuite.settings.baseUrl = 'http://127.0.0.1:'+ '9031';
		testRoutes.paymentView = testSuite.utils.createTestingUrl('paymentView');

		testSuite.settings.baseUrl = baseUrl;
		baseUrl = 'http://127.0.0.1:'+ 8889;

		testSuite.settings.baseUrl = baseUrl;
		testRoutes.blockchainPaymentCallback = testSuite.utils.createTestingUrl('blockchainPaymentCallback');

	}


	p.proc = function debugLogger() {
		if ( self.silent == true) {
			return
		}
		sh.sLog(arguments)
	}


}

exports.invoice_watcher_tests = invoice_watcher_tests;

if (module.parent == null) {
	var t = new invoice_watcher_tests();
	t.init();
}


