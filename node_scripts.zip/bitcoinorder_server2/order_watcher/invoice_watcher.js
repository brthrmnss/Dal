"use strict";
//node_modules
var _ = require('underscore');
//var queryString = require('query-string');
var request = require('request');
var rh = require('rhelpers');
var queryString = require('query-string');

//application modules
//var electrum_ = require('../electrum_wallet/ElectrumAutomator');
//var electrum_wallet = new electrum_.ElectrumAutomator();
var account_extender = require('./account_extension.js');
var invoice_watcher_tests = require('./invoice_watcher_tests.js').invoice_watcher_tests;

//var testing = true;


var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');

function InvoiceWatcher() {
	var p = InvoiceWatcher.prototype;
	p = this;
	var self = this;

	p.initInvoiceWatcher = function initInvoiceWatcher(url, appCode) {
		//setup db
		self.db = rh.getSequelize(false, false, null, ["btc_payment_addresses.js"]);

		var tester = new invoice_watcher_tests();
		tester.init()

		var config = rh.loadRServerConfig(true);
		self.settings = config.bitcoinAPI;

		//start analyzing payments and repeat every x seconds
		self.analyzeOrders(); //todo: move this out to main script
	};

	p.analyzeOrders = function analyzeOrders() {

		//self.analyzeInterval = setInterval(self.analyzePayments, 30000);
		var refreshTime = sh.dv(self.settings.check_payment_time, 30000)

		self.proc('\n---\nanalyzing payments');

		self.utils.ops.handleNewOrders_markNewPendingOrdersToValidating();
		self.utils.ops.validateNewAndPendingOrders();
		self.utils.ops.handlePaidOrders();
		self.utils.ops.handleNewlyExpiredOrders();
		self.utils.ops.handleStaleRecordedOrders();

		setTimeout(self.analyzeOrders, refreshTime);
	};





//predicates

	function onePerUser(order) {
		return order.get('user_id')
	}


	function handleErrors(process,error) {
		console.error('error in', process, '\n', error);
	}

//ops

	function closeOutOrder(options){
		_.defaults(options, {bitcoin_address: null, order_id: null});

		console.log('closeOutOrder',options);

		self.db.models.premium_order.markCompleteByID( options.order_id );

	}

	function sendPaidSignal(paid_orders) {

		if( paid_orders.length == 0 ) return;

		//mark database and send command to account_extender
		self.db.models.premium_order.markRecordingByID( _(paid_orders).pluck('id') )
			.then( function sendToListeningServer(){

				_(paid_orders).each(function(order,i, paid_orders ){
					//todo - take out .each and send all paid orders in bulk?

					var command = { order: order, callback: closeOutOrder };

					//if( !testing ){
						console.log('order paid_in_full -> blockchain_callback');
						command.action = 'order_complete';
					/*} else {
						console.log('some amount received -> blockchain_callback');
						command.action ='order_complete_test';
					}*/

					account_extender.execute(command);

				});
			});

		//notify electrum_wallet to collect coins

		self.electrum_wallet.sendMoney(self.settings.send_to_address,
			true, function onSent(){
				console.log('money sent');
			})


	}



	function defineUtils() {

		self.utils = {};
		var ops = {}
		self.utils.ops = ops;
		ops.handleNewOrders_markNewPendingOrdersToValidating = function markNewPendingOrdersToValidating () {
			self.db.models.premium_order.updatePendingOrdersStatusToValidating()
				.error(_.partial(handleErrors,'updating_pending_orders'));

		};

		ops.validateNewAndPendingOrders = function validateNewAndPendingOrders() {
			/*function isFullyPaid(order) {
				self.proc('checking order#',order.id,' with pid',order.product_id,' for payments.amount_paid= ',order.amount_paid);
				if( order.product_id == self.app.data.products.AutoPay )
					return true;
				/!*else if( testing )
					return order.amount_paid > 0;*!/
				else //	return order.amount_paid >= order.get('amount'); //TODO: this is serious bug rakesh
					return order.amount_paid >= order.get('amount'); //TODO: this is serious bug rakesh
			}*/
			//self.proc('pending orders length', orders.length)
			self.db.models.premium_order.getPendingAndValidatingOrders()
				.then(function onGetPendingAndValidatingOrders(orders, err){
					//self.proc('pending orders length', orders.length)
					if(orders.length === 0) return;

					var idsPaid = [];
					sh.async(orders,
						function checkIfOrderPaid(order, fxDoneSync) {
							//	self.proc('syninc order', order );
							self.electrum_wallet.getInvoice(order.dataValues.bitcoin_address,
								function onCheckIfPaid(isPaid){
									//console.log('money sent', isPaid);

									isPaid = isPaid.isPaid;
									//store ammount ... check balance
									if ( isPaid) {
										idsPaid.push(order.dataValues.id);
									}
									if( order.product_id == self.app.data.products.AutoPay ) {
										idsPaid.push(order.dataValues.id);
										isPaid = true;
									}
									self.proc('checking order#',order.id, isPaid, ' prod_id ',order.product_id,' amount= ',order.amount_paid);
									xD();
								}, function notFound(e) {
									_.partial(handleErrors,'check order did not work')
								})

							function xD() {
								/*if ( isFullyPaid(order) ) {
									idsPaid.push(order.dataValues.id)
								}*/
								fxDoneSync()
							}

						},
						function allDone() {
							//	self.proc('all orders synced');
							self.db.models.premium_order.markIDPaid(idsPaid)
							sh.callIfDefined()
						})

				})
				.error(_.partial(handleErrors,'getting_pending_orders'));

		};

		ops.handlePaidOrders = function handlePaidOrders() {
			self.db.models.premium_order.getAllPaidOrders()
				.then(function(orders,err){
					if( _.isEmpty(orders) ) return;

					_(orders).chain()
						.uniq(onePerUser)
						.tap(sendPaidSignal)
				})
				.error(_.partial(handleErrors,'getting_pending_orders'));

		};

		ops.handleNewlyExpiredOrders = function handleNewlyExpiredOrders() {
			self.db.models.premium_order.getAllTimedOutOrders()
				.then(function(orders){
					self.db.models.premium_order.markOrdersExpired( _(orders).pluck('id') );
					//mdl_addresses.markAddressForReuse( _(orders).pluck('bitcoin_address') );
				})
				.error(_.partial(handleErrors,'updating_newly_expired_orders'));

		};

		ops.handleStaleRecordedOrders = function handleStaleRecordedOrders() {
			//ensure no recording orders get left behind - resend stale to callback
			self.db.models.premium_order.getAllRecordingAndStale()
				.then(function(rec_orders){
					if( _(rec_orders).isEmpty() ) return;
					sendPaidSignal(rec_orders);
				});

			//ensure no recorded orders get left behind - close out old recorded orders.
			self.db.models.premium_order.getAllRecordedAndStale()
				.then(function(rec_orders){
					_(rec_orders).each( function(order,i){
						var data = _(order).pick(['bitcoin_address','id']);
						data.order_id = data.id;
						closeOutOrder( data );
					});

					//var _rec_orders = _(rec_orders)
					// .each( _(element).pick(['bitcoin_address','id']) );
					// closeOutOrder( _rec_orders );

				});

		};

	}
	defineUtils();

	p.proc = function debugLogger() {
		if ( self.silent == true) {
			return
		}
		sh.sLog(arguments)
	}


}

exports.InvoiceWatcher = InvoiceWatcher;

if (module.parent == null) {

	var iw = new InvoiceWatcher();
	iw.initInvoiceWatcher();
}



