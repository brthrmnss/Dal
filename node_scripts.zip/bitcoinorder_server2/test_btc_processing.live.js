/**
 * Created by user on 4/6/16.
 */
/*
 why: tests btc processing
 */


var rh = require('rhelpers');
var shelpers = require('shelpers');
var sh = require('shelpers').shelpers;
var EasyRemoteTester = shelpers.EasyRemoteTester;

var invoice_service = require('./invoice_service.js').invoice_service;


function TestBTCLive() {
    //why: runs btc live
    var p = TestBTCLive.prototype;
    p = this;
    var self = this;
    p.init = function method1(url, appCode) {

        var testOverrides = {
            "bitcoinAPI": {
                "api_port": "8900",
                "test_mode": false,
                /*"test_mode_overrides": {
                 "check_payment_time": "3000",
                 "_test_run_real_payment_test": true,
                 "test_run_payment_test": true,
                 "renewal_price": 0.1
                 },*/
                "test_mode_overrides_why": "simplify testing scenarios. defualt json ",
                "check_payment_time": "3000",
                "test_run_real_payment_test": true,
                "test_run_payment_test": true,
                "renewal_price": 0.1
            }
        }
        rh.addConfigOverride(testOverrides);
        var config = rh.loadRServerConfig(true);
        self.config = config;

        self.proc('starting BTC live Test', config.bitcoinAPI.api_port);


        self.invoice_service = new invoice_service();
        self.invoice_service.init();


        self.checkIfEnoughMoney();

    }
    p.createAddress = function createAddress() {
        var amount  =  self.config.bitcoinAPI.renewal_price*4;
        self.invoice_service.electrum_wallet.createInvoice(amount, 'to setup wallet', function onCmdRun(address, data) {
            self.proc('send btc to this address', address)
        });
    }
    p.checkIfEnoughMoney = function () {
        //get balance
        //if more than renewal_price
        self.invoice_service.electrum_wallet.getBalance(
            function onBalance(balance, data) {
                // t.cb();
                self.proc('current balance', balance)
                balance = sh.dv(balance, -1)
                //process.exit()
                sh.exitIn1Sec = function exitIn1Sec() {
                    setTimeout(function () {
                        process.exit()
                    }, 1000)
                }
                sh.exitIn1Sec()

                if (sh.isNumber(balance) == false ) {
                    balance = -2; //wtf
                }
                self.proc('current balance', balance)
                //process.exit()
                if ( balance < self.config.bitcoinAPI.renewal_price) {
                    self.proc('need more money', balance , '<', self.config.bitcoinAPI.renewal_price)
                    self.proc('create address')
                    self.createAddress();
                    process.exit()
                }
            },
            function onFailedToGetBalance(info, data) {
                // t.cb();
                throw new Error('coudl not load balance '+ info)
            }
        );

    }

    p.a = function () {
        //make chain
        var t = EasyRemoteTester.create('Test Bitcoin Integration',{showBody:true});




        //create urls
        var baseUrl = 'http://127.0.0.1:'+ '8888';
        t.settings.baseUrl = baseUrl;
        var urls = {};
        urls.paymentCreate = t.utils.createTestingUrl('paymentCreate');
        urls.orderGet = t.utils.createTestingUrl('orderGet');

        t.settings.baseUrl = 'http://127.0.0.1:'+ '9031';
        urls.paymentView = t.utils.createTestingUrl('paymentView');
        t.settings.baseUrl = baseUrl;
        baseUrl = 'http://127.0.0.1:'+ 8889;
        t.settings.baseUrl = baseUrl;
        urls.blockchainPaymentCallback = t.utils.createTestingUrl('blockchainPaymentCallback');

        //setup some test-wide data
        var username = 'admin';


        //define tests
        t.getR(urls.paymentCreate).with({username: 'markyY', product: 1})
            .why('try to create payment with bad username')
            // .bodyHas('status').notEmpty()
            .fxDone(function syncComplete(result) {
                t.assert(result.payment.error == 'cannot find user')
            });

        t.getR(urls.paymentCreate).with({username:username})
            // .bodyHas('status').notEmpty()
            .fxDone(function syncComplete(result) {
                t.assert(result.payment.error=='input is invalid', 'make a bad product did not produce correct error')
            });

        t.getR(urls.paymentCreate).with({username: username, product: 2})
            .why('test with bad product')
            .fxDone(function syncComplete(result) {
                t.assert(result.payment.error == 'product not found', 'make a bad product')
            });


        var reqData = {username: username, product: self.app.data.products.AutoPay };
        t.getR(urls.paymentCreate).with(reqData)
            .why('make new payment')
            // .storeHere('invoice_id', )
            .fxDone(function syncComplete(result) {
                console.log('user payment', result);
                t.assert(result.payment.invoice_id!=null, 'valid product not created')
                var invoice_id = result.payment.invoice_id;
                t.invoice_id = invoice_id;
                t.data.invoice_id = invoice_id;
                t.data.order_id = result.order_id;
            });


        var reqData = {username: username, product: self.app.data.products.MonthlyRenewal };
        t.getR(urls.paymentCreate).with(reqData)
            .why('make new payment')
            // .storeHere('invoice_id', )
            .fxDone(function syncComplete(result) {
                console.log(result);
                t.assert(result.payment.invoice_id!=null, 'valid product not created')
                var invoice_id = result.payment.invoice_id;
                t.invoice_id = invoice_id;
                t.data.invoice_id = invoice_id;
            });



        t.add(function fakePayingInvoices() {
            console.error('fakePayingInvoices', 'id', t.data.order_id)
            self.app.utils.payInvoice(t.data.order_id,
                function onCmdRun(address, data) {
                    //chain.data.address = address;
                    t.cb();
                });
        });

        t.wait(3)
        t.getR(urls.orderGet).before(function(){
            var req = {};
            req.id =  t.data.order_id;
            return req;
        })
            .why('verify order has been paid')
            // .storeHere('invoice_id', )
            .fxDone(function syncComplete(result) {

                // console.error('what is payment status', )
                /* self.app.data.status.successStates = [
                 self.app.data.status.paid,
                 self.app.data.status.completed;
                 ]*/
                var compY = result.order.order_status == 'paid';
                if ( compY == false) {
                    compY = result.order.order_status == 'completed'
                }
                if ( compY == false) {
                    compY = result.order.order_status == 'recording'
                }
                if ( compY == false) {
                    compY = result.order.order_status == 'recorded'
                }
                if ( compY == false ) {
                    console.error(compY, result.order.order_status )
                }
                t.assert(compY, 'payment not paid ' + result.order.order_status);
            });
    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return
        }
        sh.sLog(arguments)
    }
}

exports.TestBTCLive = TestBTCLive;

if (module.parent == null) {

    var i = new TestBTCLive();
    i.init();
}

