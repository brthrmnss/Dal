/**
 * creates interface for users to create bitcoin orders
 * Created by ad on 1/3/14.
 */
var _ = require('underscore');
var express     = require('express');
var request     = require('request');
var fs          = require('fs');
var rh = require('rhelpers');


var invoice_service_tests = require('./invoice_service_tests.js').invoice_service_tests;
var invoice_service_tests_live = require('./invoice_service_tests_live.js').invoice_service_tests_2;

var InvoiceWatcher = require('./order_watcher/invoice_watcher').InvoiceWatcher;
var invoice_utils = require('./invoice_utils.js').invoice_utils;
var bitcoin = new invoice_utils();
bitcoin.init();

var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');

function invoice_service() {
    var p = invoice_service.prototype;
    p = this;
    var self = this;

    self.data = {};
    self.data.statuses = ['PENDING', 'VERIFYING', 'PAID', 'RECORDING', 'RECORDED'];

    var products = {};
    products.MonthlyRenewal = 1;
    products.AutoPay = 9999;
    self.data.products = products;

    p.init = function init(config) {
        var settings = rh.loadRServerConfig(true);
        self.settings = settings.bitcoinAPI;
        self.server_config = settings;

        self.handleTestingOverrides();
        self.defineElectrum();

        var invoice_watcher = new InvoiceWatcher();
        invoice_watcher.initInvoiceWatcher();
        self.invoice_watcher = invoice_watcher;
        self.invoice_watcher.app = self;
        self.invoice_watcher.electrum_wallet  = self.electrum_wallet;

        self.initSequelize();

        self.app_html = express();
        self.initHTMLServer(self.app_html);
        self.app_html.listen(self.server_config.bitcoinAPI.html_port);


        var tests = new invoice_service_tests();
        tests.app = self;

        self.app_api = express();
        self.decorateAPIRoutes(self.app_api);
        self.defineStatusMethods()
        self.app_api.listen(self.server_config.bitcoinAPI.api_port, function onServerStart(){

            if ( self.settings.test_run_payment_test != false ) {
                tests.start();
            }


            if ( self.settings.test_run_real_payment_test == true ) {
                var tests2 = new invoice_service_tests_live();
                tests2.app = self;
                tests2.start();
            }

            var is_prc_send_avail = (process.send);
            if (is_prc_send_avail)
                process.send({ action: 'setup_complete' });

            console.log( 'api listening on port: ', self.server_config.bitcoinAPI.api_port );
        });


    }

    p.initHTMLServer = function(express_server){
        var view_template_src = 'public/paymentView.html';

        self.settings.htmlTemplate = null;
        //todo: load and compile template up here

        express_server.use(express.static('public'));
        self.decorateHTMLRoutes(express_server);
    }

    p.initSequelize = function initSequelize() {

        self.db = rh.getSequelize(false, false, null)

        return;
        //db.sequelize.sync({force:false});

    }

    p.defineElectrum = function defineElectrum() {
        var fileWallet = null;
        var electrum_ = require('./electrum_wallet/ElectrumAutomator');

        var electrum_wallet = new electrum_.ElectrumAutomator();
        self.electrum_wallet = electrum_wallet;
        self.electrum_wallet.init();
        self.electrum_wallet.getWalletFromConfig();
        if ( sh.isMac() ) {
            self.electrum_wallet.startTestModeDefaults();
        }

    }

    p.handleTestingOverrides = function handleTestingOverrides() {
        //why: quicky go into generic testing mode with modifying json files
    }

    p.decorateHTMLRoutes = function(htmlapp){
        htmlapp.get('/paymentView', function renderPaymentView(req, res){

            var payment_hash = findPaymentHash(req);
            if(payment_hash == false ){
                res.send('error: no payment hash sent');
                return false;
            }

            bitcoin.findPaymentByPaymentHash(payment_hash,
                function( payment ){
                    if(_.isNull(payment) ){
                        res.send('error: payment not found!');
                        return false;
                    }
                    var payment_data = payment;
                    var view_template_src = 'public/paymentView.html';

                    //get Username of userID

                    fs.readFile(view_template_src, function(err, data){
                        if(err) {
                            console.log('error occuried reading template', err);
                        }
                        else {
                            self.settings.htmlTemplate = data.toString();
                            var template = _.template(self.settings.htmlTemplate, {variable: 'data'});

                            res.send( template(payment_data) );

                            return true;
                        }
                    });

                });

        });

        function findPaymentHash(req){
            var body_payment =  req.payment;
            var query_payment = req.query.payment;
            return (!_.isUndefined(body_payment) )? body_payment : (!_.isUndefined(query_payment))? query_payment: false;

        }
    }

    p.decorateAPIRoutes = function decorateRoute(app) {

        app.use(function topMiddleware_AllowCrossDomain_forTesting(req, res, next) {
            // if ( req.isLoggedIn == true ) {
            //if is in testing mode allow any origin ... for testing ...
            //console.error('block block block', req.originalUrl)
            rh.validateOrigins(req, res, true);
            // }
            next();
        });

        app.oldFxGet = app.get;
        app.get = function appGetForwarder() {
            var args = sh.convertArgumentsToArray(arguments);
            var fxGet = args[1];
            var error = sh.errors.storeError(4).slice(0,1)[0];

            //  console.error('Errdor: asdf', '\n',
            //  '   at Function.appGetForwarder (/Users/user2/Dropbox/projects/ritv2/videoproject/Code/node_scripts/bitcoinorder_server2/invoice_service.js:173:21)')
            var e = new Error('asdf')
            //throw(e);
            //console.error('   ', /*args[0].slice(1),*/ error)
            //process.exit();
            args[1] = function getReplacement() {
                //console.error('booo')
                //sh.sLog2('in get method', 0,1,true)
                console.error('   ', /*args[0].slice(1),*/ error)
                //sh.sLog(['thing']);

                var argsGetMethod = sh.convertArgumentsToArray(arguments);
                fxGet.apply(this, argsGetMethod);
            }
            app.oldFxGet.apply(app, args)
        };

        app.get('/getPriceOfRenewal', function getPriceOfRenewal(req, res) {

            bitcoin.findBTCPrice( {}, function onGotPrice(e, paytmentResult) {
                    var btc = paytmentResult.btc
                    var usd_price = paytmentResult.usd;
                    res.json({value_btc: btc, value_usd: usd_price});
                }
            ), function onError(e) {
                res.json({error:'could not get price', e:e});
            };
        });

        app.get('/paymentFindComplete', function (req, res) {
            //todo: combine this into a find payment - with passed in status
            var username = findReqVariable(req, 'username');

            self.db.models.users.find({
                where: {username: username}
            }).then(function (user) {
                if (_.isNull(user)) {
                    res.send({err: 'user not found'});
                    return false
                }

                var user_id = user.id;

                //find existing payments
                self.db.models.premium_order.findAll({
                    where: {
                        user_id: user_id,
                        order_status: 'COMPLETED'
                    }
                }).then(function (completed_payments) {
                    if (_.isUndefined(completed_payments) || _.isNull(completed_payments)) {
                        res.json({payments: null});
                        return
                    }

                    var sanitizedPayments = _.map(completed_payments, sanitizePayment);
                    res.json({payments: sanitizedPayments});

                    function sanitizePayment(payment) {
                        return _.pick(payment, 'payment_hash', 'amount', 'amount_usd', 'updatedAt');
                    }
                })


            })
        });

        app.get('/paymentFindVerifying', function (req, res) {
            var options = {};
            options.username = self.utils.findReqVariable(req, 'username');

            if (_.isNull(options.username)) {
                res.json({success: false, msg: 'err: send username'});
                return false
            }

            bitcoin.findUsersPaymentWhere({order_status: self.data.statuses}, options.username, onPaymentQueryResults);

            function onPaymentQueryResults(existingInvoice, user_id, username, err) {

                if (_.isNull(existingInvoice)) {
                    res.json({success: true, payments: null});
                    return false;
                }
                else if (existingInvoice === false) {
                    res.json({success: false, msg: 'error finding payment'});//todo: handle errors with checking existing payments
                }

                //we found a valid payment

                var payments = _(existingInvoice).map(function (val) {
                    return _(val.get()).chain()
                        .extend({user_id: user_id})
                        .pick(['payment_hash', 'amount', 'amount_usd', 'bitcoin_address', 'updatedAt', 'user_id'])
                        .value();
                });

                res.json({success: true, payments: payments});

            }

        });

        app.get('/orderGet', function orderGet(req, res) {
            var query = {};
            var id = req.query.id;
            console.log('id', 'console', id,req.params)
            //process.exit();
            query.where={id:id};
            self.db.models.premium_order.findAll(query).then(function(orders,err){
                var result = {};
                if ( orders.length == 0 ) {
                    res.json(result)
                    return;
                }
                result.order = orders[0].dataValues;
                res.json(result)

            });
        })

        app.get('/paymentCreate', function paymentCreate(req, res) {

            var payment = {            //todo: use error as error indicator
                blockchain_return: null,
                bitcoin_address: null,
                invoice_id: null,
                payment_sequence: 0,
                invoice_amt: null,
                invoice_amtsat: null,
                invoice_productname: "1 month extension",
                invoice_amtusd: null,
                product_id: 1,
                user_id: null,
                callback_url: null,
                expireAt: null,
                error: null
            };

            var options = {};

            options.username = self.utils.findReqVariable(req, 'username');
            options.productIDOfPayment = self.utils.findReqVariable(req, 'product');
            options.productIDOfPayment = parseInt(options.productIDOfPayment);
            options.doRedirect = false;

            console.log('username:', options.username, ' productID:', options.productIDOfPayment, ' doRedirect:', options.doRedirect);

            if (self.utils.sanitizeInputsAndVerifyServerData(options) !== true) {
                res.json({payment: {error: 'input is invalid'}});
                return false
            }

            //todo: break this out into a function that looksup products on database
            if (!self.utils.isProductIDValid(options.productIDOfPayment)) {
                res.json({payment: {error: 'product not found'}});
                return false
            }

            //todo: make this a function in bitcoinOps to return new payment
            //create new invoiceID and then request new payment from blockchain.info
            payment.invoice_amtusd = self.server_config.bitcoinAPI.renewal_price;
            payment.invoice_id = bitcoin.createPaymentID(options.username);
            payment.expireAt = new Date(new Date().getTime() + parseInt(self.server_config.bitcoinAPI.paymentExpirationTimeout) * 60000);
            payment.product_id = options.productIDOfPayment;

            payment.secret = bitcoin.createPaymentPassword();

            var callback_url = self.server_config.bitcoinAPI.blockchain_callback_url;

            payment.callback_url = callback_url + '?invoice_id=' + payment.invoice_id + '&secret=' + payment.secret;

            self.db.models.user.getUserWhere({username: options.username})
                .error(self.utils.handleMySQLError, 'gettingUserWhere', true)
                .then(function onGotUserData(user) {
                    if (_(user).isNull()) { //TODO: why does this not catch null?
                        res.json({payment: {error: 'cannot find user'}});
                        return;
                    }
                    if (user == null ) {
                        res.json({payment: {error: 'cannot find user'}});
                        return;
                    }
                    payment.user_id = user.id;
                    payment.payment_sequence = user.lastPaymentSequence + 1;             //set payment_sequence for payment

                    bitcoin.createNewPayment(payment, function (new_payment, error) {
                        if (new_payment == false || !_.isUndefined(error)) {
                            //todo: handle errors better
                            console.error('error', error)
                            res.json({payment: 'cannot create payment'});
                            return;
                        }

                        bitcoin.insertOrderIntoDatabase(new_payment, respondWithResult);
                        function respondWithResult(result) {
                            if (!_.isUndefined(result.err)) {
                                res.json({payment: {error: 'err'}}); //todo: handle errors better
                                return false;
                            }
                            delete new_payment.secret;
                            res.json({payment: new_payment, order_id:result.order.id});
                        }
                    }, self.electrum_wallet );
                });

        });





    }

    self.defineStatusMethods = function  defineStatusMethods() {
        var EasyRemoteTester = shelpers.EasyRemoteTester;
        self.app_api.get('/runTest', function getBalance_(req, res) {
            //when get balance of wallet remotely
            res.end('no way');
        });

        self.app_api.get('/statusOK_', function statusOk(req, res) {
            //return true if everything good
            //can get btc
            //can get price

            var response ={}

            var c = {};
            var t = EasyRemoteTester.create('test Real Content Provider API', c);
            t.add(function getPrice() {
                    bitcoin.findBTCPrice( {}, function onGotPrice(e, paytmentResult) {
                            var btc = paytmentResult.btc
                            var usd_price = paytmentResult.usd;
                            response.value_btc = btc
                            response.value_usd =  usd_price;
                            t.cb()
                        }
                    ), function onError(e) {
                        response.status = false;
                        response.price = 'cannot get price'
                        t.cb()
                    };
                }
            );
            t.add(function getBalance() {
                    self.electrum_wallet.getBalance(
                        function onBalance(balance, data) {
                            self.proc('current balance', balance)
                            response.balance = balance;
                            t.cb()
                        },
                        function onFailedToGetBalance(info, data) {
                            // t.cb();
                            response.balance = 'cannot get balance'
                            t.cb()
                        }
                    );
                }
            );

            t.add(function doSearchWithNoLogin() {
                    res.json(response)
                }
            );


        });

        self.app_api.get('/createAddress_', function createAddress_(req, res) {
            //why: create address to send money to wallet to verify test
            self.electrum_wallet.createInvoice(amount, 'to setup wallet', function onCmdRun(address, data) {
                self.proc('send btc to this address', address)
                res.json({x:'could not get price', address:address});
            });
        });

    }

    function defineUtils() {
        self.utils = {};
        self.utils.findReqVariable = function findReqVariable( req, property ){
            return req && ( req[property] || req.params[property]  || req.query[property] || false ) || null
        }

        self.utils.sanitizeInputsAndVerifyServerData = function sanitizeInputsAndVerifyServerData(options){
            if(_.isNull( self.server_config.bitcoinAPI.address ) || _.isUndefined( self.server_config.bitcoinAPI.address ) ||  self.server_config.bitcoinAPI.address.length < 10 ) {
                console.log('no bitcoin address, halting');
                return {error:'server error'};
            }

            if( !options.username || options.username === "" ){
                return {error:'no username'};
            }

            if( !options.productIDOfPayment || options.productIDOfPayment === "" ){
                return {error:'no product'};
            }

            return true;
        }

        self.utils.isProductIDValid = function isProductIDValid(id) {

            var foundProduct = null
            sh.each(self.data.products, function checkIfValidProduct(name,productId){
                if ( productId == id) {
                    foundProduct = name;
                    return false;
                }
            })
            if ( foundProduct ) {
                return true;
            }

            return false;
        }

        self.utils.handleMySQLError = function handleMySQLError( desc, fatal ) {
            console.log('**mysql_error**:', desc);
        }

        self.utils.payInvoice = function payInvoice(id, fxCallback) {
            var query = {};
            query.where={id:id};
            self.db.models.premium_order.findAll(query).then(function(orders,err){
                console.error('length of orders',id, orders.length)
                self.proc('what were the orders?', orders)
                /* setTimeout(function end(){
                 process.exit()
                 }, 200)*/
                if( _.isEmpty(orders) ) return;

                function updateOrder(order) {
                    var invoice_amt= order.get('invoice_amt');
                    var p = {amount_paid:10000000};
                    console.error('is updated', p)
                    setTimeout(function end(){
                        return;
                        process.exit()
                    }, 1000)
                    order.updateAttributes(p).then(
                        function (dd) {
                            //console.log('...', dd)
                            sh.callIfDefined(fxCallback)
                        }

                    ).error(function(c) {
                            console.log('c', c)
                        })
                }
                updateOrder(orders[0])

                return ;
            })
                .error(function x( ) {
                    console.log('....what is this ...')
                });
        }


        self.utils.isOrderPaid = function isOrderPaid(order) {
            var status = order.order_status;
            var isPaid = status == 'paid';
            if ( isPaid == false) {
                isPaid = status == 'completed'
            }
            if ( isPaid == false) {
                isPaid = status == 'recording'
            }
            if ( isPaid == false) {
                isPaid = status == 'recorded'
            }
            if ( isPaid == false ) {
                console.error(isPaid, status )
            }
            return isPaid;
        }
    }
    defineUtils();

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return
        }
        sh.sLog(arguments)
    }
}

if (module.parent == null) {
    var service = new invoice_service();
    service.init();
}

exports.BitcoinAPI = invoice_service;
exports.invoice_service = invoice_service;
exports.SSSD = invoice_service;