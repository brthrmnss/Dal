/**
 * Created by user on 4/6/16.
 */





var BitcoinAPI = require('./invoice_service').BitcoinAPI;

if (module.parent == null) {
    var service = new BitcoinAPI();
    service.init();
}

exports.BitcoinAPI = BitcoinAPI;