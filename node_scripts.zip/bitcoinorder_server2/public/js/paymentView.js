$(document).ready(function() {
    $('.js-payment_loading').hide();
    $('.js-payment_step1').show();

    //setup timer stuff
    setupCountdownClock();

});


function setupCountdownClock(){
    var elem = '.js-expireTimer .progress';

    var expireTime = $(elem).data('expiretime');
    var now = new Date();
    expireTime = new Date(expireTime);

    var timeleftInMS = expireTime.getTime() - now.getTime();


    var percentLeft = timeleftInMS / ( 15 * 60 * 1000 );

    var timerCircle = new ProgressBar.Circle(elem, {
        duration: 200,
        color: "#FCB03C",
        trailColor: "#ddd"
    });

    window.timer = setInterval(function () {
        var timeleftInMS = Math.max(0, expireTime.getTime() - new Date().getTime());
        var ms = timeleftInMS,
            min = (timeleftInMS / 1000 / 60) << 0,
            sec = (timeleftInMS / 1000) % 60 << 0;

        var percentLeft = 1 - timeleftInMS / ( 15 * 60 * 1000 );
        var timeleft = min + ' : ' + ('0' + sec).slice(-2);

        timerCircle.animate(percentLeft, function () {
            timerCircle.setText(timeleft);
        });

        if (timeleftInMS <= 0) {
            window.clearInterval(window.timer)
        }
    }, 1000);
    if (timeleftInMS <= 0) {
        //show expired shit
        showExpired(timerCircle);
    }

}

function showExpired(timerCircle){
    $('.js-expireMessage').show();
    $('.js-btcpay-instructions, .js-btc-qr, .js-expireTimer').fadeTo(400,0.3);
    timerCircle.setText('expired');
}