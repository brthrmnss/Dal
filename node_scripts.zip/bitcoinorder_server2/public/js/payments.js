"use strict";

//globals
window.user_username = null;

$(document).ready(function() {
	$(document).on('click','.js-createBtcPayment', onCreateBTCPayment );
	$(document).on( 'click', '.js-restartBtcPayment', onPaymentRestartClick );

	$.when(
		$.ajax({
			url: "/getUserInfo",
			dataType: "json"
		}),
		$.ajax({
			url: "//localhost:8888/getPriceOfRenewal",
			dataType: "json"
		})
	).then( ///todo: handle errors better especially if getUserInfo passes, this page should still load
		setupAccountInterfaceValues,
		function(error) { console.log( 'fail', error ) }
	);
});

function setupAccountInterfaceValues( accountData , priceOfRenewal) {
	var dataOfExpiration = new Date( accountData[0].paidExpiryDate);
	var dataOfLastPayment = new Date( accountData[0].paidExpiryDate );
	var btcPrice = priceOfRenewal[0].value_btc;
	var usdPrice = priceOfRenewal[0].value_usd;
	var username = accountData[0].username;
	window.user_username = username;


	/**/

	function convertDateToDate(date) {
		var d = new Date();
		var curr_date = d.getDate();
		var curr_month = d.getMonth() + 1; //Months are zero based
		var curr_year = d.getFullYear();
		return (curr_date + "-" + curr_month + "-" + curr_year);
	}

	$('.js-renewaltime').text( dataOfExpiration.toDateString() );
	$('.js-lastpaidtime').text( convertDateToDate(dataOfLastPayment.toDateString()) );
	$('.js-renewalprice').text( btcPrice );
	$('.js-accountname').text( username );

	var $paymentStage 	= $('.js-paymentwindow');
	$paymentStage.find('.js-btcpay_amountdisp').text('$'+ usdPrice + 'usd');

	checkForExistingPayment();

}

function onCreateBTCPayment(){
	resetPaymentStage();
	$.when(
		$.ajax({
			url: "http://localhost:8888/paymentCreate",
			dataType: "json",
			data:{username: window.user_username, product: 1}
		})
	)
	.then(
		onNewPaymentDataRecieved,
		function(error) { console.log( 'fail', error ) }
	);
}

function onPaymentRestartClick(){
	resetPaymentStage();
	$.when(
		$.ajax({
			url: "http://localhost:8888/paymentCancel",
			dataType: "json",
			data:{username: window.user_username}
		})
	)
	.then(
		function(){
			$.ajax({
				url: "http://localhost:8888/paymentCreate",
				dataType: "json",
				data:{username: window.user_username, product: 1},
				success: onNewPaymentDataRecieved

			})
		},
		function(error) { console.log( 'fail', error ) }
	);
}

function onNewPaymentDataRecieved( paymentCreationData ){
	var root 			= "https://blockchain.info/",
		extAmt 			= $('.js-btcAmountSel.selected').data('extendamnt'),
		$paymentStage 	= $('.js-paymentwindow');

	//check for errors in paymentCreationData;
	if( !_.isObject(paymentCreationData.payment) || paymentCreationData.payment.error != undefined ) {
		console.log('error occurried');
		return
	}

	var btcPaymentAddress = paymentCreationData.payment.bitcoin_address,
		btcPaymentExpireAt= new Date( paymentCreationData.payment.expireAt );

	$paymentStage.css({'height':'auto'}).show();

	$paymentStage.find('.js-payment_step1').trigger('show').show();
	$paymentStage.find('.js-btcpay-address_display').html( btcPaymentAddress );

	$paymentStage.find('.js-btc-qr').html('<img style="margin:5px" src="'+'https://blockchain.info/'+'qr?data=' + btcPaymentAddress + '&size=125">');

	$('#btc-paybtn').hide();

	//setTimer
	$(".js-expireTimer").data( 'date', btcPaymentExpireAt.toISOString() );
	$(".js-expireTimer").TimeCircles({
		count_past_zero:true,
		use_background: true,
		time: {
			Days: {show: false},
			Hours: {show: false}
		}
	}).addListener(function(unit, value, total){
		if(total <= 1){
			//set expired
			onPaymentExpire();
		}
	});

}

function onPaymentExpire(){

	//$(".js-expireTimer").hide();
	$(".js-expireMessage").show();

	$('.js-btcpay-instructions, .js-btc-qr, .js-expireTimer').fadeTo(400,0.1);
}

function resetPaymentStage(){
	$(".js-expireMessage").hide();
	$('.js-btcpay-instructions, .js-btc-qr, .js-expireTimer').fadeTo(0,1);
	$(".js-expireTimer").TimeCircles().destroy();

};

function checkForExistingPayment(){

	$.ajax({
		url: "http://localhost:8888/paymentFindCurrent",
		dataType: "json",
		data:{username: window.user_username},
		success: onNewPaymentDataRecieved
	})
};
