/**
 * Created by user on 2/25/16.
 */
/*
 why: b/c I want to ..automate eltrum wallet
 create payments

 */

var shelpers = require('shelpers');
var sh = shelpers.shelpers;


testBTC();

function testBTC() {
    var self = {};
    function createUtils() {
        utils = {};
        utils.createCmd = function createCmd(x) {
            x = sh.dv(x, 'history')
            var wallet = "~/.electrum/wallets/default_wallet"
            var cmdWallet = ' ' + '-w ' + (wallet) + ' '
            var cmd = "electrum " + cmdWallet

            //cmd += ' -o ' + x //what was o?
            cmd += ' ' + x
            return cmd
        }

        utils.runCmd = function run(cmd, fx) {
            var exec = require('child_process').exec;
            var child = exec(cmd,
                function (error, stdout, stderr) {
                    console.log(cmd, "\n", stdout, '\n');
                    console.log(stderr);
                    sh.callIfDefined(fx, stdout);
                    if (error !== null) {
                        // console.error( error );
                    }
                });
        }
        return utils;
    }

    self.utils = createUtils();



//cmd = createCmd('history')
//console.log(cmd)

//var output = sh.run(cmd)
//console.log(output.toString())




    var cmd = '';
    cmd = self.utils.createCmd('history')
//run(cmd)

    cmd = self.utils.createCmd('getbalance')
//run(cmd)


    /*
     "1PzmumerdLFW9e9Tn5xxRkVU2zno96rLMF",
     "1HWz7VoSuY2niwkUVzewQ6ZQFKC5YzfaMp",
     "1EdMM86fsLYwDVHUTTjKG7iRWdsrYeofpo",
     "1QB9Q9xi94wyzmT6Y7ziS6cWDc4JzZtFJb",
     "15BKP6mK8ZKadGKN6WUFTwyAR6rpPPQNnD",
     "17gZQbzTdTwggrVUsoTQk6S1hHfDnFvNrt",
     "1JvwgixrEonoajzTGJvBYr9vzSLThZLJFA",
     "1BDkvhLKLW3TRuYtgqifsk4AUinrHjz7Pr",
     "1AEVXAWGJpYUyXb1AtUv7dVXS9k1iGqsRd",
     "1Bf7SjoR75wKERPhinCaeN5E9K8En1N8FB",
     "1HSHDSUXm6D3eaAmjwT6jwXmRK51SEFt4k",
     "1AFAGF9cwLez7rZNNzjCn2aCcsN53UAyqA",
     "1DUzQfsiUTGwdjh4dUaBtryzGPvZUp8Ke3",
     "14WeBfWZprjHS3YHYChNN2qph1FMG3GAGJ",
     "1DVoEBcYXhwJMFgw9PNT83ETgrxtT7F3Dw",
     "1Psi8iacxVLQwUYwvvMsJCVFQ2VjBkrBK",
     "1NXUBZpppbfGWGbjaNVNSPwxkHeZjHGk61",
     "1JXmDiJA5w9TwJPqTYWPNTdsRGeepYsbos",
     "1LhdxvjDrzPVTpDkS33z4u7EtmRG1DrJw9",
     "1KttDhNiueUxJkpUunbdyDSU7y17TA75Xm",
     "1AgPbpQyXjaDtrStEFodFrmKLrGN1UHvwf",
     "1LDN1trkyrXJLN2jrU91WFAAH2MVnmZsaS",
     "1JFLqz21HzcntBXNJL8Dznyug9KR9yBg6E",
     "18Voeih8jumWK3ndKUo2UrLY594k2uvpEg",
     "16zR9NkL11hy1dzvjX3Tp463z3153aiCxv",
     "1NA9a7naFd4mQQ8H7UtLqaVRM1yAhTYqzM",
     "16LRa7Sw2mvCkCTte2izQkrAWWAJjjhqdt"
     ]
     */


//run(cmd)

    var getmpk = 'xpub661MyMwAqRbcFBkkxv4hif9vijLzxN32DR2uhFKxJxRMFMRFLEUbbVcwm4vJDHx65PmBwuR64LNvg6uhzigtLere2FwuddsAgjrp1wQbzAt'
    getmpk = '[03efb08514aaa2d09206db956318fe6771656beebf4f0e1299c824795674c72591]'
    cmd = self.utils.createCmd('createmultisig -v  1 ' + getmpk)
//run(cmd)

    var PromiseHelperV3 = shelpers.PromiseHelperV3;

    function testCmds() {


        //var self = {}
        self.searchByName = function search(token, cb) {
            console.log('searchByName')
            //asdf.g
            cb();
        }

//27


        self.returnMagnetLink = function returnMagnetLink(token, cb) {

            setTimeout(function () {
                console.log('returnMagnetLink')
                cb()
            }, 200)
            ;
        }

        self.data = {};


        var token = {};
        var chain = new PromiseHelperV3();
        token.silentToken = true
        chain.wait = token.simulate == false;
        chain.startChain(token)
            /*     .add(function listAddress() {
             var cmd = createCmd('listaddresses')
             run(cmd, function onCmdRun(data) {
             data = JSON.parse(data)
             //console.log('data', data)
             self.data.addresses = data;
             console.log('got', data.length, 'addresses')
             chain.cb();
             })
             })*/
            .log()
        function createMultiSig() {


            function getBtcPubKeyOfAddress() {
                chain.add(function getPubKeyOfAddress() {
                    self.data.pubKeyId = sh.dv(self.data.pubKeyId, -1);
                    self.data.keys = sh.dv(self.data.keys, []);
                    self.data.pubKeyId++;
                    var address = self.data.addresses[self.data.pubKeyId];
                    var cmd = self.utils.createCmd('getpubkeys ' + address)
                    self.utils.runCmd(cmd, function onCmdRun(data) {
                        data = JSON.parse(data)
                        self.data.keys.push(data[0]);
                        chain.cb();
                    });
                })
            }

            getBtcPubKeyOfAddress()
            getBtcPubKeyOfAddress()
            getBtcPubKeyOfAddress()
            getBtcPubKeyOfAddress()
            chain.add(function showCreatedKeys() {
                console.log('showCreatedKeys', self.data.keys)
                chain.cb();
            });
            chain.add(function createAddress() {
                chain.cb();
                return;
                var keys = self.data.keys
                var key2 = []
                /*sh.each(keys, function addKey(i, key){
                 "address": "33989TzquNup6qeVfwpE4yriAQnWZbhey2",
                 "redeemScript": "51210334de9ca5fbbd630023f580d6eb39385136d6cce226afad8314a464add19902102103dd3d384a8b4271fd46b06c4695b62ff64c833dd0eeb5073a511befaf8f370f332103df5a3a84f15b7283b99b8450fc67017acafcc31ebf235f1a53398af894fb2a02210249ed610c7f0ce2c435439e0257f7a4a452c04b96da5652c3d021da38b6df886554ae"

                 keys2.push(key)
                 })*/
                keys = JSON.stringify(keys)
                keys = sh.replace(keys, '"', '\\"');
                keys = sh.qq(keys)
                var cmd = self.utils.createCmd('createmultisig' + ' 1 ' + keys)
                self.utils.runCmd(cmd, function onCmdRun(data) {
                    data = JSON.parse(data)
                    self.data.keys.push(data[0]);
                    chain.cb();
                });
            })
        }


        function creatReqyest(amount, exp, memo) {

            chain.add(function createRequest() {
                var mBtc = '.001'
                var btc = amount;
                if (memo) {
                    memo = ' -m ' + sh.qq(memo)
                }
                memo = sh.dv(memo, '')
                if (exp) {
                    exp = ' --expiration ' + exp
                }
                exp = sh.dv(exp, '')
                var cmd = self.utils.createCmd('addrequest ' + btc + memo + exp)
                self.utils.runCmd(cmd, function onCmdRun(data) {
                    data = JSON.parse(data)
                    chain.data.address = data.address;
                    chain.cb();
                });
            })
        }

        creatReqyest(0.001, null, 'test request2')


        /*   chain.add(function listrequests() {
         var requestId = 'db6c48aa28'
         var cmd = createCmd('listrequests ' + requestId)
         run(cmd, function onCmdRun(data) {
         data = JSON.parse(data)
         chain.cb();
         });
         })*/
        //return


        //getRequest('1EdMM86fsLYwDVHUTTjKG7iRWdsrYeofpo');

        // return;
        function getRequest(address) { //address
            chain.add(function getRequest() {
                address = sh.dv(address, chain.data.address)
                var cmd = self.utils.createCmd('getrequest ' + address)
                self.utils.runCmd(cmd, function onCmdRun(data) {
                    data = JSON.parse(data)
                    chain.cb();
                });
            })
        }

        getRequest();

        //return

        function payTo(addressTo, amountBTC) {
            chain.add(function payTo() {
                //var addressTo = '1Bf7SjoR75wKERPhinCaeN5E9K8En1N8FB'
                //var amountBTC = '0.001'
                var fee = ' -f 0.00113'
                var cmd = self.utils.createCmd('-v payto  ' + addressTo + ' ' + amountBTC +
                    fee)
                self.utils.runCmd(cmd, function onCmdRun(data) {
                    data = JSON.parse(data)
                    self.data.payHex = data.hex;
                    chain.cb();
                });
            })

            //return;
            chain.utils.wait(1);
            /*   chain.add(function signTransaction() {
             var hex = self.data.payHex;
             var cmd = createCmd('-v signtransaction ' + hex  )
             run(cmd, function onCmdRun(data) {
             data = JSON.parse(data)
             self.data.payHex = data.hex;
             chain.cb();
             });
             })*/
            //   chain.utils.wait(1)
            chain.add(function broadcast_payTo() {
                var hex = self.data.payHex;
                var cmd = self.utils.createCmd('-v broadcast ' + hex)
                self.utils.runCmd(cmd, function onCmdRun(data) {
                    data = JSON.parse(data)
                    chain.cb();
                });
            })

            /*chain.add(function broadcast_payTo() {
             var hex = self.data.payHex;
             var cmd = createCmd('-v broadcast ' + hex  )
             run(cmd, function onCmdRun(data) {
             data = JSON.parse(data)
             chain.cb();
             });
             })*/
        }

        //payTo('1DUzQfsiUTGwdjh4dUaBtryzGPvZUp8Ke3', '0.001')


        function payTo2(addressTo, amountBTC) {


            var fileName = __dirname + '/' + 'signed' + Math.random() + '.txt'

            chain.add(function payTo() {
                //var addressTo = '1Bf7SjoR75wKERPhinCaeN5E9K8En1N8FB'
                //var amountBTC = '0.001'
                //var fee = ' -f 0.00113'
                var fee = ''
                addressTo = sh.dv(addressTo, chain.data.address)
                amountBTC = sh.dv(amountBTC, 0.001);

                var cmdFile = ' > ' + fileName
                var cmd = self.utils.createCmd('-v payto  ' + addressTo + ' ' + amountBTC +
                    fee + cmdFile)
                self.utils.runCmd(cmd, function onCmdRun(data) {
                    console.log(data, 'results?')
                    chain.cb();
                });
            })

            //return;
            chain.utils.wait(1);

            chain.add(function broadcast_payTo() {
                var hex = self.data.payHex;
                // cat signed.txn | electrum broadcast -
                var cmd = self.utils.createCmd('-v broadcast -')
                cmd = 'cat ' + fileName + '| ' + cmd
                self.utils.runCmd(cmd, function onCmdRun(data) {
                    //data = JSON.parse(data)
                    chain.cb();
                });
            })

            chain.add(function broadcast_payTo() {
                var hex = self.data.payHex;
                // cat signed.txn | electrum broadcast -
                var cmd = self.utils.createCmd('-v broadcast -')
                cmd = 'cat ' + fileName + '| ' + cmd
                self.utils.runCmd(cmd, function onCmdRun(data) {
                    data = JSON.parse(data)
                    chain.cb();
                });
            })
        }

        // payTo2('1DVoEBcYXhwJMFgw9PNT83ETgrxtT7F3Dw', '0.001')
        payTo2()

        return;

//  .add(self.getFirstQuery)
//  .add(self.convertMagnetLinkToTorrent)
//  .log()
//  .add(self.returnMagnetLink)
        chain.end();
    }

    testCmds()
    /*evil combine belt fluid tuition seek blind surround spy palm chief obvious absorb
     electrum payto 1DVoEBcYXhwJMFgw9PNT83ETgrxtT7F3Dw 0.001 --unsigned > unsigned.txn
     cat unsigned.txn | electrum deserialize -
     cat unsigned.txn | electrum signtransaction - > signed.txn
     cat signed.txn | electrum broadcast -



     electrum payto 1DVoEBcYXhwJMFgw9PNT83ETgrxtT7F3Dw 0.001 > signed.txn
     #cat unsigned.txn | electrum deserialize -
     # cat unsigned.txn | electrum signtransaction - > signed.txn
     cat signed.txn | electrum broadcast -
     */

// ./sshuttle --dns -r root@5.79.75.96 0/0

    /*
     sudo apt-get install python-pip python-qt4
     #Check out the code from Github
     git clone git://github.com/spesmilo/electrum.git
     cd electrum
     #Compile the icons 	sudo apt-get install pyqt4-dev-tools
     pyrcc4 icons.qrc -o gui/icons_rc.py
     #Compile protobuf description file 	sudo apt-get install protobuf-compiler
     protoc --proto_path=lib/ --python_out=lib/ lib/paymentrequest.proto

     #Create translations
     sudo apt-get install python-pycurl gettext
     ./contrib/make_locale
     #Install Electrum
     sudo python setup.py install
     */

}