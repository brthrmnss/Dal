/**
 * Created by user on 2/25/16.
 */
/*
 why: b/c I want to ..automate eltrum wallet
 create payments

 */

var shelpers = require('shelpers');
var sh = shelpers.shelpers;

var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');

var PromiseHelperV3 = shelpers.PromiseHelperV3;


function ElectrumAutomator() {
    var p = ElectrumAutomator.prototype;
    p = this;

    var self = this;

    self.data = {};


    p.init = function init(config) {
        self.settings = sh.dv(config, {});
    }
    //run random commmand to ensure functioning
    p.testWallet = function testWallet(fxTestOk, fxTestFault) {
        var cmd = self.utils.createCmd('getbalance');

        if ( self.settings.testMode ) {
            var testResult = self.test['getbalance']
            if (testResult != false )
                fxTestOk(testResult);
            else {
                fxTestFault(testResult);
            }
            return;
        }

        self.utils.runCmd(cmd, function onCmdRun(data) {
            self.proc(data, 'results?')
            sh.callIfDefined(fxTestOk, data);
        }, fxTestFault, self.testWallet);

    }
    self.testWallet.test = function testTestWallet(result) {
        self.test[self.testWallet] = result
    }

    //why: simply testing
    self.startTestModeDefaults = function startTestModeDefaults(result) {
        self.startTestMode();
        self.test.testWallet = 'true'
        self.test.createInvoice = {address:6};
        self.test.getInvoice = {isPaid:false};
        self.test.sendMoney = {address:6,status:true};

        self.test.createInvoice = 6;
        self.test.getInvoice = {isPaid:false};
        self.test.sendMoney = {address:6,status:true};

    }

    //get wallet from onfig - simplify configuration
    self.getWalletFromConfig = function getWalletFromConfig(result) {
        var rh = require('rhelpers');
        var config = rh.loadRServerConfig(true);
        //merge with elecectrum_wallet_manager
        var isWalletDirDefined = !sh.str.isBlank(config.electrum.wallet_dir != null)
        if ( isWalletDirDefined ) {
        } else {
            var fileWallet = rh.getPath('bitcoin_wallet/wallet')
        }
        self.settings.fileWallet = fileWallet;
    }

    p.createInvoice = function createInvoice(amtBtc, memo, fxSendAddress, expiry, fxSendFault) {
        var mBtc = '.001'
        //var mbtc = amtBtc;
        if (memo) {
            memo = ' -m ' + sh.qq(memo)
        }
        memo = sh.dv(memo, '')

        expiry = sh.dv(expiry, 15*60) //seconds
        if (expiry) {
            expiry = ' --expiration ' + expiry
        }
        expiry = sh.dv(expiry, '')

        if ( self.settings.testMode ) {
            var testResult = self.test['createInvoice']
            if (testResult != false )
                fxSendAddress(testResult);
            else {
                fxSendFault(testResult);
            }
            return;
        }

        var force = ' --force '

        var cmd = self.utils.createCmd('addrequest ' + amtBtc + memo + expiry + force)
        self.utils.runCmd(cmd, function onRequest(data) {
            var lines = data.split('\n')
            if ( lines[1].slice(0,1) == '{') {
                //lose first char
                data = lines.slice(1).join('\n')
            }
            data = JSON.parse(data)
            var address = data.address;
            self.data.address = address;
            self.data.createRequest = data;
            sh.callIfDefined(fxSendAddress, address, data);
            //chain.data.address = data.address;
            //chain.cb();
        }, fxSendFault, self.createInvoice);
    }
    p.getInvoice = function getInvoice(address, fxGetInvoiceStatus, fxGetFault) {
        address = sh.dv(address, self.data.address)
        var cmd = self.utils.createCmd('getrequest '  + address)

        if ( self.settings.testMode ) {
            var testResult = self.test['getInvoice']
            if (testResult != false )
                fxGetInvoiceStatus(testResult);
            else {
                fxGetFault(testResult);
            }
            return;
        }

        self.utils.runCmd(cmd, function onCmdRun(data) {
            data = JSON.parse(data);
            var isPaid = data.status =='Paid';
            sh.callIfDefined(fxGetInvoiceStatus, isPaid, data);
        }, fxGetFault, self.getInvoice);
    }

    p.getBalance = function getBalance( fxGetInvoiceStatus, fxGetFault) {
        var cmd = self.utils.createCmd('getbalance '  )

        if ( self.settings.testMode ) {
            var testResult = self.test['getBalance'];
            if (testResult != false )
                fxGetInvoiceStatus(testResult);
            else {
                fxGetFault(testResult);
            }
            return;
        }

        self.utils.runCmd(cmd, function onCmdRun(data) {
            data = JSON.parse(data);
            //var isPaid = data.status =='Paid';
            var balance = data.confirmed;
            sh.callIfDefined(fxGetInvoiceStatus, balance, data);
        }, fxGetFault, self.getInvoice);
    }

    p.createWallet = function createWallet( file_wallet, fxGetInvoiceStatus, fxGetFault) {
        var cmd = self.utils.createCmd('create ' ,file_wallet  )

        if ( self.settings.testMode ) {
            var testResult = self.test['createWallet'];
            if (testResult != false )
                fxGetInvoiceStatus(testResult);
            else {
                fxGetFault(testResult);
            }
            return;
        }

        var child = self.utils.runCmd(cmd, function onCmdRun(data) {
            console.log('data', data)
            //data = JSON.parse(data);
            var start = 'Your wallet generation seed is:'
            var seed = data.split(start)[1]
            seed = seed.split("\n")[1]
            sh.callIfDefined(fxGetInvoiceStatus, seed, data);
        }, fxGetFault, self.getInvoice);

        setTimeout(function () {
            child.stdin.write("\n")
        },400)

    }





    p.sendMoney = function sendMoney(toAddress, amtOrallAvailableFunds , fxSent, fxSendFault) {
        var chainPayment = self.utils.startChain();

        if ( self.settings.testMode ) {
            var testResult = self.test['sendMoney']
            if (testResult != false )
                sh.callIfDefined(fxSent, testResult);
            else {
                sh.callIfDefined(fxSendFault, testResult);
            }
            return;
        }

        payTo2(toAddress, amtOrallAvailableFunds);
        function payTo2(addressTo, amountBTC) {

            var fileName = __dirname + '/' + 'signed' + Math.random() + '.txt'

            chainPayment.add(function payTo() {
                //var addressTo = '1Bf7SjoR75wKERPhinCaeN5E9K8En1N8FB'
                //var amountBTC = '0.001'
                //var fee = ' -f 0.00113'
                var fee = ''
                addressTo = sh.dv(addressTo, self.data.address)
                amountBTC = sh.dv(amountBTC, 0.001);
                if ( amountBTC == true ) {
                    amountBTC = '!';
                }

                var cmdFile = ' > ' + fileName
                var cmd = self.utils.createCmd('-v payto  ' + addressTo + ' ' + amountBTC +
                    fee + cmdFile)
                self.utils.runCmd(cmd, function onCmdRun(data) {
                    console.log(data, 'results?')
                    chainPayment.cb();
                }, fxSendFault);
            })

            //return;
            chainPayment.utils.wait(1);
            chainPayment.data.retries = 0
            chainPayment.add(function broadcast_payTo() {
                var hex = self.data.payHex;
                // cat signed.txn | electrum broadcast -
                var cmd = self.utils.createCmd('-v broadcast -')
                cmd = 'cat ' + fileName + '| ' + cmd
                self.utils.runCmd(cmd, function onCmdRun(data) {
                    var isPaymentComplete = data[0];
                    if ( isPaymentComplete == false ) {
                        chainPayment.data.retries++;
                        if (chainPayment.data.retries > 3) {
                            throw new Error('gave up tring to send payment')
                        }
                        chainPayment.addNext(broadcast_payTo);
                        chainPayment.cb();
                        return;
                    }
                    //data = JSON.parse(data)
                    sh.deleteFile(fileName)
                    chainPayment.cb();
                    sh.callIfDefined(fxSent, data[0], data)
                }, fxSendFault);
            })

            return;

            chain.add(function broadcast_payTo() {
                var hex = self.data.payHex;
                // cat signed.txn | electrum broadcast -
                var cmd = self.utils.createCmd('-v broadcast -')
                cmd = 'cat ' + fileName + '| ' + cmd
                self.utils.runCmd(cmd, function onCmdRun(data) {
                    data = JSON.parse(data)
                    sh.callIfDefined(fxSend, data);
                    chain.cb();
                });
            })
        }

    }


    function defineUtils() {
        p.utils = {};
        p.utils.create = function createCmd(x) {
            x = sh.dv(x, 'history')
            var wallet = "~/.electrum/wallets/default_wallet"
            var cmdWallet = ' ' + '-w ' + (wallet)  +  ' '
            var cmd = "electrum " + cmdWallet

            //cmd += ' -o ' + x //what was o?
            cmd += ' ' + x
            return cmd
        }

        p.utils.runCmd = function run(cmd, fx, fxGetFault)
        {
            var exec = require('child_process').exec;
            var child = exec(cmd,
                function (error, stdout, stderr)   {
                    console.log( cmd, "\n", stdout , '\n');
                    console.log( stderr );
                    try {
                        sh.callIfDefined(fx, stdout);
                    } catch ( e ) {
                        if ( self.settings.fxError ) {
                            sh.callIfDefined( self.settings.fxError, e )
                            return;
                        } else  if ( fxGetFault ) {
                            sh.callIfDefined( self.fxError, e )
                        }
                        else {
                          //  console.error('output', stdout)
                            console.error('error from:', sh.q(cmd), stderr, stdout)
                            throw e
                        }
                    }
                    if (error !== null) {
                        //asdf.g
                        sh.callIfDefined( self.settings.fxError, error )
                        // console.error( error );
                    }
                });
            return child;
        }

        p.utils.createCmd = function createCmd(x, wallet) {
            x = sh.dv(x, 'history');
            var defaultWallet = "~/.electrum/wallets/default_wallet";
            defaultWallet = sh.dv(self.settings.fileWallet, defaultWallet);
            wallet = sh.dv(wallet, defaultWallet)
            var cmdWallet = ' ' + '-w ' + (wallet)  +  ' ';
            var cmd = "electrum " + cmdWallet;

            //cmd += ' -o ' + x //what was o?
            cmd += ' ' + x
            return cmd
        }

        p.utils.startChain = function startChain() {
            var token = {};
            var chain = new PromiseHelperV3();
            token.silentToken = true
            chain.wait = token.simulate == false;
            chain.startChain(token)
            return chain;
        }
    }
    defineUtils();

    function defineTest() {
        self.test = {}
        self.startTestMode = function startTestMode() {
            self.proc('test mode started');
            self.settings.testMode = true;
            self.testMode = function () { return self.settings.testMode; }
        }
    }
    defineTest();

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return;
        }
        sh.sLog(arguments);
    };
}

exports.ElectrumAutomator = ElectrumAutomator;

if (module.parent == null) {
    if ( sh.isMac() ) {
        testMac();
        return
    }

    var instance = new ElectrumAutomator();
    var config = {};
    instance.init(config)
    instance.testWallet(testUbuntu);

    function testUbuntu() {
        var token = {};

        var chain = new PromiseHelperV3();
        token.silentToken = true
        chain.wait = token.simulate == false;
        chain.startChain(token)

        function testBTC() { //address
            chain.add(function getRequest() {
                instance.testWallet(function onCmdRun(data) {
                    chain.cb();
                });
            })
        }
        testBTC();

        function createInvoice(amount, exp, memo) { //address
            chain.add(function getRequest() {
                instance.createInvoice(amount, memo, function onCmdRun(address, data) {
                    chain.data.address = address
                    chain.cb();
                }, exp);
            })
        }
        createInvoice( 0.001, null, 'test request2');

        function getRequest(address) { //address
            chain.add(function getRequest() {
                instance.getInvoice(address, function onCmdRun(isPaid, data) {
                    chain.data.isPaid = isPaid
                    chain.cb();
                });
            })
        }

        getRequest();


        function sendMoney(addressTo, amountBTC) { //address
            chain.add(function sendMoney() {
                instance.sendMoney(addressTo, amountBTC, function onCmdRun( data) {
                    chain.data.paymentDetails = data
                    checkForPayment()
                    // chain.addNext(   )
                    chain.cb();
                });
            })

        }

        sendMoney();
        function checkForPayment(addressTo) { //address
            chain.addNext(function sendMoney() {
                console.log('checking paymet')
                instance.getInvoice(addressTo, function onCmdRun(isPaid, data) {
                    chain.data.isPaid = isPaid
                    console.log('is payment paid', isPaid)
                    if ( isPaid == true ) {
                        console.log('payment is paid')
                        return;
                    }
                    chain.addNext( checkForPayment )
                    chain.addNext( chain.utils.wait(10, false), 1 )
                    chain.cb();

                });
            })
        }

        return;

        //ceck status loop
        function getBtcPubKeyOfAddress() {
            chain.add(function getPubKeyOfAddress() {
                self.data.pubKeyId = sh.dv(self.data.pubKeyId, -1);
                self.data.keys = sh.dv(self.data.keys, []);
                self.data.pubKeyId++;
                var address = self.data.addresses[self.data.pubKeyId];
                var cmd = createCmd('getpubkeys ' + address)
                run(cmd, function onCmdRun(data) {
                    data = JSON.parse(data)
                    self.data.keys.push(data[0]);
                    chain.cb();
                });
            })
        }

        function getBtcPubKeyOfAddress() {
            chain.add(function getPubKeyOfAddress() {
                self.data.pubKeyId = sh.dv(self.data.pubKeyId, -1);
                self.data.keys = sh.dv(self.data.keys, []);
                self.data.pubKeyId++;
                var address = self.data.addresses[self.data.pubKeyId];
                var cmd = createCmd('getpubkeys ' + address)
                run(cmd, function onCmdRun(data) {
                    data = JSON.parse(data)
                    self.data.keys.push(data[0]);
                    chain.cb();
                });
            })
        }

        function getBtcPubKeyOfAddress() {
            chain.add(function getPubKeyOfAddress() {
                self.data.pubKeyId = sh.dv(self.data.pubKeyId, -1);
                self.data.keys = sh.dv(self.data.keys, []);
                self.data.pubKeyId++;
                var address = self.data.addresses[self.data.pubKeyId];
                var cmd = createCmd('getpubkeys ' + address)
                run(cmd, function onCmdRun(data) {
                    data = JSON.parse(data)
                    self.data.keys.push(data[0]);
                    chain.cb();
                });
            })
        }


        // chain.addYX(instance.createInvoice)
        instance.createInvoice();

        instance.checkInvoice();

        instance.sendMoney();
    }
}

function testMac() {
    var instance = new ElectrumAutomator();
    var config = {};
    instance.init(config)
    instance.startTestMode();

    instance.test.testWallet = 'true'
    instance.test.createInvoice = {address:6};
    instance.test.getInvoice = {isPaid:false};
    instance.test.sendMoney = {address:6,status:true};
    instance.testWallet(testOk)

    function testOk() {
        var token = {};

        var chain = new PromiseHelperV3();
        token.silentToken = true
        chain.wait = token.simulate == false;
        chain.startChain(token)

        function testBTC() { //address
            chain.add(function getRequest() {
                instance.testWallet(function onCmdRun(data) {
                    chain.cb();
                });
            })
        }
        testBTC();

        function createInvoice(amount, exp, memo) { //address
            chain.add(function getRequest() {
                instance.createInvoice(amount, memo, function onCmdRun(address, data) {
                    chain.data.address = address;
                    chain.cb();
                }, exp);
            })
        }
        createInvoice( 0.001, null, 'test request2');

        function getInvoice(address) { //address
            chain.add(function getRequest() {
                instance.getInvoice(address, function onCmdRun(isPaid, data) {
                    chain.data.isPaid = isPaid
                    chain.cb();
                });
            })
        }

        getInvoice();


        function sendMoney(addressTo, amountBTC) { //address
            chain.add(function sendMoney() {
                instance.sendMoney(addressTo, amountBTC, function onCmdRun( data) {
                    chain.data.paymentDetails = data
                    checkForPayment()
                    // chain.addNext(   )
                    chain.cb();
                });
            })

        }

        sendMoney();
        function checkForPayment(addressTo) { //address
            chain.addNext(function sendMoney() {
                console.log('checking paymet')
                instance.getInvoice(addressTo, function onCmdRun(isPaid, data) {
                    chain.data.isPaid = isPaid
                    console.log('is payment paid', isPaid)
                    if ( isPaid == true ) {
                        console.log('payment is paid')
                        return;
                    }
                    chain.addNext( checkForPayment )
                    chain.addNext( chain.utils.wait(10, false), 1 )
                    chain.cb();

                });
            })
        }


    }
}

