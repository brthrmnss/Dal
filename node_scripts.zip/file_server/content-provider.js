/**
 * Created by user on 4/15/15.
 */
var fs = require("fs");
var mime = require('mime');
var path = require("path");
var url = require('url');

var config = {} //require('../configuration/config');
config.content = {}
var moment = require('moment');
//var accessRestrictInMinutes = config.content.accessRestrictInMinutes;
//var accessRestrictCount = config.content.accessRestrictCount;
//var validateContent = require('./validate-content');
var validateContent = null;

exports.sendContent = function onSendContent(request, response, next) {
    // We will only accept 'GET' method. Otherwise will return 405 'Method Not Allowed'.
    if (request.method != 'GET') {
        sendResponse(response, 405, {
            'Allow': 'GET'
        }, null);
        return null;
    }
    var filename = request.contentPath;

    if ( request.query.test == "true" ) {
        response.send('test ok');
        return;
    }

    // Check if file exists. If not, will return the 404 'Not Found'.
    if (!fs.existsSync(filename)) {
        console.error('could not find', filename)
        response.status( 404)
        response.send('error')
       // sendResponse(response, 404, null, null);
        return null;
    }


    if ( request.query.testFile == "true" ) {
        response.send('test- found file - ok');
        return;
    }

    var responseHeaders = {};
    var stat = fs.statSync(filename);
    var rangeRequest = readRangeHeader(request.headers['range'], stat.size);

    // If 'Range' header exists, we will parse it with Regular Expression.
    if (rangeRequest === null) {
        console.log('Start downloading...' );
        // validateContent.accessCount(request, response, function (nextData) {
        //      if (nextData === true) {
        responseHeaders['Content-Type'] = getMimeNameFromExt(path.extname(filename));
        responseHeaders['Content-Length'] = stat.size; // File size.
        responseHeaders['Accept-Ranges'] = 'bytes';

        //  If not, will return file directly.
        sendResponse(response, 200, responseHeaders, fs.createReadStream(filename));
        /*        return null;
         } else {
         //next(nextData);
         sendResponse(response, 401, responseHeaders, null);
         }
         });
         */

    } else {

        var start = rangeRequest.Start;
        var end = rangeRequest.End;

        if (start === 0) {
            if ( validateContent != null ) {
                //If user download first time, set access count
                validateContent.accessCount(request, response, function (nextData) {
                    if (nextData !== true) {
                        sendResponse(response, 401, responseHeaders, null);
                    }
                });
            }
        }
        // If the range can't be fulfilled.
        if (start >= stat.size || end >= stat.size) {
            // Indicate the acceptable range.
            responseHeaders['Content-Range'] = 'bytes */' + stat.size; // File size.

            // Return the 416 'Requested Range Not Satisfiable'.
            sendResponse(response, 416, responseHeaders, null);
            return null;
        }
        console.log('Start partial downloading...');
        // Indicate the current range.
        responseHeaders['Content-Range'] = 'bytes ' + start + '-' + end + '/' + stat.size;
        responseHeaders['Content-Length'] = start == end ? 0 : (end - start + 1);
        responseHeaders['Content-Type'] = getMimeNameFromExt(path.extname(filename));
        responseHeaders['Accept-Ranges'] = 'bytes';
        responseHeaders['Cache-Control'] = 'no-cache';
        // Return the 206 'Partial Content'.
        sendResponse(response, 206, responseHeaders, fs.createReadStream(filename, {
            start: start,
            end: end
        }));
    }
};

function sendResponse(response, responseStatus, responseHeaders, readable) {
    response.writeHead(responseStatus, responseHeaders);

    if (readable === null)
        response.end();
    else
        readable.on('open', function () {
            readable.pipe(response);
        });

    return null;
}

function getMimeNameFromExt(ext) {
    var result = mime.lookup(ext);
    if (result === null) {
        result = 'application/octet-stream';
    }

    return result;
}

function readRangeHeader(range, totalLength) {
    /*
     * Example of the method 'split' with regular expression.
     *
     * Input: bytes=100-200
     * Output: [null, 100, 200, null]
     *
     * Input: bytes=-200
     * Output: [null, null, 200, null]
     */

    if (range == null || range.length == 0) {
        return null;
    }

    var array = range.split(/bytes=([0-9]*)-([0-9]*)/);
    var start = parseInt(array[1]);
    var end = parseInt(array[2]);
    var result = {
        Start: isNaN(start) ? 0 : start,
        End: isNaN(end) ? (totalLength - 1) : end
    };

    if (!isNaN(start) && isNaN(end)) {
        result.Start = start;
        result.End = totalLength - 1;
    }

    if (isNaN(start) && !isNaN(end)) {
        result.Start = totalLength - end;
        result.End = totalLength - 1;
    }

    return result;
}