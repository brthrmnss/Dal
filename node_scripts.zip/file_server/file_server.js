/**
 * Created by user on 6/28/15.
 */

var shelpers = require('shelpers');
var sh = shelpers.shelpers;
var EasyRemoteTester = shelpers.EasyRemoteTester;

var rh = require('rhelpers');
//rh.requireSequelizeV2_();

var RestHelperSQLTest = require('shelpers').RestHelperSQLTest;
var cQS = require('./../credentials_server/CredentialServerQuickStartHelper').CredentialServerQuickStartHelper;
var LoginAPIConsumerService = cQS.LoginAPIConsumerService

//rh.requireSequelizeV2();
//  CredentialServerQuickStart

function FileServer() {
    var p = FileServer.prototype;
    p = this;
    var self = this;
    p.init = function init(testMode) {
        var settings = rh.loadRServerConfig(true);
        self.settings = settings;
        self.settings.testMode = testMode;
        self.login = true;
        self.config();
        self.cQS = new cQS();
        sh.waitXSecs(1,self.test);
        return;
    }

    p.config = function config(url, appCode) {
        var cPSettings = {}//settings.contentProviderAPI;
        self.cPSettings = cPSettings;
        cPSettings = {
            defaultContentPath: 'ritv_requests/a.mkv',
            //sendDefaultPath : true,
            port: self.settings.files.port
        };

        //cPSettings.portProducer = self.settings.files.port;
        if ( self.settings.files.testMode_2Servers == true && self.settings.testMode != true) {
            setTimeout(function createTestServer() {
                var f = new FileServer();
                f.init(true);
            }, 500);
        };

        //idea increment port, can use same files
        if ( self.settings.testMode == true ) {
            var ImportVideosScriptV2 =
                rh.loadJSScript('utils/import_script/import_videos_script_v2.js')
                    .ImportVideosScriptV2;
            self.settings.files.port+=1;
            self.settings.testRun = false;
            cPSettings.port = self.settings.files.port;
            setTimeout(function runImportScriptlaterToPrventMysqlOverload () {
                var i = new ImportVideosScriptV2(); //ensure videos are on proper server
                i.init({port:cPSettings.port});
            }, 10000)

            //import test files
        };

        //cPSettings.dirSessions = settings.loginAPIConsumer.dirSessions;
        cPSettings.portProducer = self.settings.loginAPI.port;

        cPSettings.dirSession = self.settings.global.dir_session;
        cPSettings.fxValidateOrigin = rh.validateOrigins;

        //Req: To Set cookies, set on IP address and domain name
        cPSettings.fullUrl = self.settings.ip + ':' + self.settings.files.port

        //create a new server for contentProviderAPI
        if (self.login == true) {
            var c = new LoginAPIConsumerService();
            c.startExampleCredentialsAPIConsumerService2(cPSettings);
            server = c.server;
        } else {
            self.settings.contentProviderAPI.port = self.settings.port;
        }

        self.createRoutes();
    }

    self.createRoutes = function createRoutes() {
        //WARNING: any user can delete
        self.content = RestHelperSQLTest.createHelper('file', server, {
            name:'file',
            readOnly:true,
            //routePrePend:'sim/',
            /*fields:{name: "", src:"", desc: "", user_id: 0, content_id: 0,
             episode:0, season:0, show_name:"",  year:0, imdb_id:"",
             series_imdb_id:""
             },*/
            fields:{originalFilename: "", userId:0
                /* , desc: "", user_id: 0, content_id: 0,
                 episode:0, season:0, show_name:"",  year:0, imdb_id:"",
                 series_imdb_id:""*/
            },
            freezeTableName: true,
            timestamps:false,
            //fxStart:testContentProviderAPIInterface,
            reset:'onlyIfNeeded',
            genData:RestHelperSQLTest.RestHelper.types.GenDataIfEmpty,
            //fxReset :self.utils.generateFakeContentForContentAPI
            sequelize:rh.getSequelize(true, true)
        });

        //http://192.168.81.133:10003/find_content?limit=3&src=game%201x1
        self.find_content = function find_content(req, res) {
            self.proc('getContent', req.query)
            var q = req.query;
            if ( req.query != null && req.query.query != null  ) {
                q = JSON.parse(req.query.query);
            }
            self.content.utils.genRestOkStub(req, res);

            var query_ = {where:q}
            query_.limit = 10;
            req.query = query_;
            self.content.searchItems(req, res)
            // res.end();
        }

        server.get('/api/find_content', self.find_content);

        var contentProvider = require('./content-provider');

        //server.get('/content/:filePath', contentProvider.sendContent);
        /*server.get('/api/get_content/:filePath', function fakeFileRequestMiddleware(req, res) {
         //req.contentPath = 'ritv_requests/b.mkv';
         if ( cPSettings.sendDefaultPath == true ) {
         req.contentPath = cPSettings.defaultContentPath;
         }
         contentProvider.sendContent(req, res)
         });*/
        server.get('/api/get_content', fakeFileRequestMiddleware);
        server.get('/api/get_content/*', fakeFileRequestMiddleware);

        function fakeFileRequestMiddleware(req, res) {
            req.contentPath = req.query.file;

            //if filename sent in url
            if ( req.params[0] != null ) {
                req.contentPath = req.params[0];
            }
            if ( self.cPSettings.sendDefaultPath == true ) {
                req.contentPath = self.cPSettings.defaultContentPath;
            }


            self.proc('fake', req.query)

            //Bug: Hack: we have these media/ preambles in the DB on the file shortUrl field.
            //this block will remove them
            var mediaPreamble = 'media/';
            if ( req.contentPath != null && req.contentPath.indexOf(mediaPreamble) == 0 ) {
                //req.contentPath = sh.replace(req.contentPath, mediaPreamble, '');
                req.contentPath =  req.contentPath.replace(mediaPreamble, '');
            };

            contentProvider.sendContent(req, res);
        }

    }


    p.test = function test() {
        function testContentProviderAPIInterface(fxDone) {

            if ( self.settings.testRun == false  ) {
                console.warn('skipping test')
                return;
            }

            //do search
            //make request for fake content;

            //login

            //do search
            //make fake request

            var c = sh.clone(self.settings.files)
            //c.baseUrl = 'localhost:'+self.settings.files.port;
            c.fxDone = fxDone;
            var t = EasyRemoteTester.create('test Real Content Provider API', c);


            var urls = {}
            urls.search = t.utils.createTestingUrl('api/find_content')
            urls.getContent = t.utils.createTestingUrl('api/get_content')
            urls.file = {};
            //TODO: store on rest helper cpy from props in rest helper .
            urls.file.create = t.utils.createTestingUrl('api/file/create');
            urls.file.delete = t.utils.createTestingUrl('api/file/delete');


            urls.verifyConsumer = t.utils.createTestingUrl('api/verify');
            t.settings.portOverride = self.settings.loginAPI.port;
            urls.login = t.utils.createTestingUrl('api/login');
            t.settings.portOverride = null;

            t.wait(7); //add delay

            if ( self.login != false ) {

                t.add(function doSearchWithNoLogin() {
                        t.quickRequest( urls.search,
                            'get', result, {originalFilename: "randomTask"})
                        function result(body) {
                            console.log(body);
                            t.assert(body.success==false, 'no ok');
                            t.cb();
                        }
                    }
                );

                self.cQS.testUtils.loginFail(t, urls.login, 'mark', 'randomTask')
                self.cQS.testUtils.login(t, urls.login, 'mark', 'randomTask2')
                self.cQS.testUtils.verifyKey(t, urls.verifyConsumer, t.key)
            }
            t.add(function doSearchAfterLogin() {
                    t.quickRequest( urls.search,
                        'get', result, {originalFilename: "randomTask"})
                    function result(body) {
                        t.assert(body.length>=0, 'post-verify did not let me do a search');
                        t.cb();
                    }
                }
            );

            //don't have imdb in the searches yet
            t.xadd(function doSearchWithIMDBId() {
                    t.quickRequest( urls.search,
                        'get', result, {imdb_id: "tt101"})
                    function result(body) {
                        t.assert(body.length>0, 'post-verify did not let me do a search');
                        t.cb();
                    }
                }
            );


            t.add(function createMovie_to_search() {
                    t.quickRequest( urls.file.create,
                        'get', result, {originalFilename: 'jack.mp4'});
                    function result(body) {
                        console.log('body', body);
                        t.data.idOfFakeMovie = body;

                        // t.content = body[0];
                        // asdf.g
                        if ( body.success==false){
                            throw 'not logged in anymore';
                        };
                        t.assert(parseInt(body) > 0, 'could not create new content item .... ');
                        t.cb();
                    }
                }
            );


            t.add(function doSearchWithLikeInName_VerifySearchWorks() {
                    t.quickRequest( urls.search,
                        'get', result, {originalFilename: {like:"%mp4%"}});
                    function result(body) {
                        console.log('body', body);
                        t.content = body[0];
                        if ( body.success==false){
                            throw 'not logged in anymore';
                        };
                        t.assert(body.length>0, 'post-verify did not let me do a search. Searched for mp4 got back 0 results .... ');
                        t.cb();
                    }
                }
            );


            t.add(function createMovie_to_search_delete() {
                    t.quickRequest( urls.file.delete+ '/' + t.data.idOfFakeMovie,
                        'get', result, t.data.idOfFakeMovie );
                    function result(body) {
                        console.log('body', body);
                        t.data.idOfFakeMovie = body;

                        if ( body.success==false){
                            throw 'not logged in anymore';
                        };
                        // t.assert(body.length>0, 'could not create new content item .... ');
                        t.cb();
                    }
                }
            );


            t.add(function reqMovie() {
                    t.quickRequest( urls.getContent,
                        'get', result, {originalFilename: t.content.src, test:true});
                    /*t.quickRequest( urls.getContent+'/'+t.content.src,
                     'get', result );*/
                    function result(body) {
                        console.log('body', body)
                        t.assert(body=='test ok', 'could not get that content');
                        t.cb();
                    }
                }
            );

            sh.fs.resolve = function resolvePath(pathToResolve) {
                var path = require('path')
                return path.resolve(pathToResolve);
            }

            sh.convertArgs = sh.convertArgumentsToArray;

            /**
             * Creates dir path
             * Why: Don't have to write line breaks
             * @returns {*|string}
             */
            sh.fs.makePath = function () {
                var args = sh.convertArgs(arguments)
                var path = args.join('/');
                return path;
            }

            //process.exit()
            t.add(function reqMovie2Download() {
                    //prework to find file
                    var fileTestVid =  sh.fs.makePath(__dirname, 'test', 'Test Space (2015)/content.mp4');
                    fileTestVid = sh.fs.resolve(fileTestVid);
                    console.log('file test', fileTestVid)
                    var fs = require('fs')
                    console.log('can find movie to test viewing/downloading?', fs.existsSync(fileTestVid),fs.existsSync(sh.qq(fileTestVid)))

                    t.quickRequest( urls.getContent + '/media/'+fileTestVid,
                        'get', result, {originalFilename: fileTestVid, testFile:true});
                    /*t.quickRequest( urls.getContent+'/'+t.content.src,
                     'get', result );*/
                    function result(body) {
                        console.log('body', body);
                        t.assert(body=='test- found file - ok', 'could not get that content');
                        t.cb();
                    }
                }
            );





            /* console.log = function () {
             //return;
             }*/
            var res = {}
            res.ok = function ok(o) {
                console.log('response was', o )
            }

            var req = {}
            req.ok = function ok(o) {
                console.log('response was', o )
            }

            req.query = {
                name:"game",
                season: 2,
                episode: 3
            }
            //self.content.searchItems(req, res)
            //self.find_content(req, res)

            req.method = 'GET'
            req.contentPath = self.settings.files.defaultContent;
            //req.contentPath = 'ritv_requests/a.mp4';
            req.headers = {}
            //contentProvider.sendContent(req, res)

        }


        testContentProviderAPIInterface();
    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return
        }
        sh.sLog(arguments)
    }


}


if (module.parent == null) {
    var f = new FileServer();
    f.init();
}


exports.FileServer = FileServer;

exports.SSSD = FileServer;




