/**
 * Created by user on 6/27/15.
 * Temporary fix enables express to host raw
 * php files.
 * TODO: Deprecate and remove
 */

var dir_public = __dirname + '/../../../code-yeti/'

var shelpers = require('shelpers');
var sh = shelpers.shelpers;

function generateIndexHTMLFromPhp(js, title) {
    var file = dir_public + 'index_.html'
    var strHeader = sh.readFile( dir_public + '_header_minimal.php')
    var strContents = sh.readFile(file)
    var php = '<?php echo WEB_ROOT; ?>/';
    var php2 = ' echo WEB_ROOT; '

    RegExp.escape= function(s) {
        return s.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
    };

    var expression = new RegExp(RegExp.escape(php), "gi");
    var matches = strContents.match(expression);

    console.log(matches)

    if ( js == null) { js = '' };
    var start = ' <script type="text/javascript">'+sh.n
    var end =  sh.n+'</script>'
    js = start + js + end

    var footerStr = sh.readFile( dir_public + '_footer.php')
    var str = strHeader +js +  strContents + footerStr
    str = str.replace(expression, '')


    str = sh.replace(str, '<?php echo safeOutputToScreen(PAGE_NAME); ?> - <?php echo SITE_CONFIG_SITE_NAME; ?>', title);


    str = sh.replace(str, '<?php', '<!--')
    str = sh.replace(str,'?>', '-->')

    if ( title == null ) {
        title = ''
    }
    var phpTitle = '<!-- echo SITE_CONFIG_SITE_NAME; --> - <!-- echo safeOutputToScreen(PAGE_NAME); -->';
    str = sh.replace(str, phpTitle,
        title);

    return str;
}


var n = {}
n.generateIndexHTMLFromPhp = generateIndexHTMLFromPhp;
exports.gen = n;


if ( module.parent == null ) {
console.log(generateIndexHTMLFromPhp())
}



