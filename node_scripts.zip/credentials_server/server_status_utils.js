/**
 * Created by user on 3/19/16.
 */
var sh = require('shelpers').shelpers;


sh.runAsync = function runCommandAsync(cmd, fx, opts) {
    console.log('running', cmd)
    var child_process = require('child_process');
    var  ipAdd = child_process.exec(cmd, opts, fx )
}

sh.runAsync('mpstat', function (o,b,c) {
   console.log('...',o,b,c)
});