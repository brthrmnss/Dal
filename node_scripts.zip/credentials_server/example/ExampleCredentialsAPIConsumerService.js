/**
 * Example of login Consumer service
 * @type {*|exports|module.exports}
 */

var express    	= require('express');
var shelpers = require('shelpers');
var sh = shelpers.shelpers;

var CredentialConsumerAPI = require('./../api/CredentialConsumerAPI').CredentialConsumerAPI;
//var CredentialConsumerAPI = require('./../api/CredentialConsumerAPI');


function ExampleCredentialsAPIConsumerService() {
    var p = ExampleCredentialsAPIConsumerService.prototype;
    var self = this;
    p = this;

    /**
     * Starts an example login server. This demonstrates how to use
     * the ConsumerAPI
     * @param config
     */
    self.startExampleCredentialsAPIConsumerService2 = function startExampleCredentialsAPIConsumerService2(config) {
        if (config == null) {
            config = {};
        }
        self.settings = config;

        var port = process.env.PORT || 33331;
        if (self.settings.port != null) {
            port = self.settings.port;
        };

        if (self.settings.dirSessions == null) {
            self.settings.dirSessions = './sessions_test';
            sh.makePathIfDoesNotExist(self.settings.dirSessions);
        }

        // if ( self.settings.loginServiceURL == null ) {
        // self.settings.loginServiceURL = 'http://127.0.0.1:33330';
        var url = '';
        if (self.settings.baseUrl != null) {
            url = self.settings.baseUrl;
        } else {
            url = 'http://127.0.0.1';
        }
        if (self.settings.portProducer != null) {
            url += ':' + self.settings.portProducer;
        }

        self.settings.loginServiceURL = url;

        if (self.settings.loginServiceOverrideURL != null) {
            self.settings.loginServiceURL = self.settings.loginServiceOverrideURL;
        }



        var app = express();
        self.server = app;



        var consumerAPI = new CredentialConsumerAPI();

        consumerAPI.decorateApp(app, self.settings);

        app.post('/test2', function testRoute(req, res) {
            console.log('---test route');
            res.json({success: true, test: 'test route'});
        });
        app.post('/api/test2', function testRoute(req, res) {
            console.log('---test route');
            res.json({success: true, test: 'test route'});
        });

        console.log('LoginConsumerAPI Server Started on ' + port);
        self.app = app.listen(port);

        console.log('http://localhost:' + port);

        if (self.settings.fxDone != null) (self.settings.fxDone(app));

        return app;
    }

}

exports.ExampleCredentialsAPIConsumerService = ExampleCredentialsAPIConsumerService;


if ( module.parent == null ) {
    var c = new ExampleCredentialsAPIConsumerService();
    c.startExampleCredentialsAPIConsumerService2()
}
