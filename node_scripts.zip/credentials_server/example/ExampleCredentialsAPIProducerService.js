var express    	= require('express'); 		    // call express

var bodyParser 	= require('body-parser');
var session 	= require('express-session');

var mysql      	= require('mysql');
var cookieParser= require('cookie-parser');     // the session is stored in a cookie, so we use this to parse it
var Sequelize   = require('sequelize');         // ----- setup sequlize and our database

var FileStore   = require('session-file-store')(session);
var CredentialProducerAPI = require('./../api/CredentialProducerAPI.js');

var shelpers = require('shelpers');
var sh = shelpers.shelpers;

function LoginAPIProducerService(){
    var p = LoginAPIProducerService.prototype
    var self = this;
    p = this;

    self.startCredentialServer = function startCredentialServer(config) {
        if ( config == null ) {
            config = {}
        }

        self.settings = config;
        if (  self.settings.port == null ) {  self.settings.port = 33330};
        if (  self.settings.dirSessions == null ) {   self.settings.dirSessions = './sessions_login_api' };

        self.settings.FileStore = FileStore;

        self.getDatabaseConnection();
        self.startServer();
    }

    //return true if public users can access a route
    self.checkPublicRoutes = function checkPublicRoutes(req) {
        var routes = self.settings.publicRoutes;
        if ( routes == null ){
            return false;
        };
        for ( var i  = 0; i < routes.length; i++) {
            var route = routes[i];
            //console.log('debg request', route, req.originalUrl)
            if ( req.originalUrl.indexOf(route) != -1 ) {
                return true;
            };
        }
        return false;
    };

    self.getDatabaseConnection = function getDatabaseConnection() {

        var sequelize = null;
        if ( self.settings.sequelize == null ) {
            var mysqlSettings = require(__dirname + '/settings_mysql.exld');
            sequelize = new Sequelize('yetidb', mysqlSettings.user, mysqlSettings.pass, {
                host: mysqlSettings.ip,
                dialect: 'mysql',
                port: mysqlSettings.port,
                define: {
                    chareset: 'utf8',
                    collate: 'utf8_general_ci'
                }
            });
        } else {
            sequelize = self.settings.sequelize;
        };

        var mdl_User = sequelize.import('./../../../../utils/database/models' +"/users.js");
        var mdl_Session = sequelize.import('./../../../../utils/database/models' +  "/sessions.js");

        self.data = {};
        self.data.mdl_User = mdl_User;
        self.data.mdl_Session = mdl_Session;
        sequelize.sync({force:false});
    }

    self.startServer = function startServer() {
        var app  = express(); 				                // define our app using express
        var port = process.env.PORT || self.settings.port; 	// set our port

        if ( self.settings.server != null ) {
            app = self.settings.server;
        }


        app.use(bodyParser());
        app.use(cookieParser());

        sh.makePathIfDoesNotExist(self.settings.dirSessions);
        app.sessionStore = new FileStore({path:self.settings.dirSessions}); //store reference to get on verify requests
        app.use(session({ name:'tiffServer',store:  app.sessionStore ,
            secret: 'funkywater', resave: false, saveUninitialized: true }));

        // Add Credentail routes
        var api_routes = express.Router();

        //var api_routes = require( __dirname + '/routes/api.js', 'test string' );//express.Router();

        var producerServer = new CredentialProducerAPI();

        producerServer.decorateApp(app, self.data.mdl_User,
            self.data.mdl_Session ,app, self);
        //app.use('/api', api_routes);

        self.api = api_routes;
        self.api = app;
        self.server = app;

        // start app.
        if ( self.settings.server == null ) {
            app.listen(port);
        }

        console.log('Credential Server Started on ' + port);
        console.log('Credential Server Started on ' + 'http://localhost:' + port);

       // asdf.g
        if ( self.settings.setupRoutes != null ) self.settings.setupRoutes(self.server);
        if ( self.settings.fxDone != null ) (self.settings.fxDone());
    }
}

/*var CredentialProducerAPI = require('./../api/CredentialProducerAPI.js')*/

//LoginAPIProducerService.topMiddleware_BlockUsersWithoutSessions=
//    CredentialProducerAPI.topMiddleware_BlockUsersWithoutSessions;
exports.ExampleCredentialsAPIProducerService = LoginAPIProducerService;

if ( module.parent == null ) {

    var c = new LoginAPIProducerService();
    c.startCredentialServer()
}



