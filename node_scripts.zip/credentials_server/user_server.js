/**
 * Created by user on 6/27/15.
 */
/*
 Server creates login instance and express dir
 */
var rh = require('rhelpers');
var shelpers = require('shelpers');
var sh = shelpers.shelpers;
var express = require("express");
var request = require('request');
var path = require('path');
var _ = require('underscore');
var path = require('path')

var CredentialServerQuickStartHelper =
    require('./CredentialServerQuickStartHelper').CredentialServerQuickStartHelper;


function UserServer() {
    var p = UserServer.prototype;
    p = this;
    var self = this;

    self.consumerPort = 10006; //port used by consumer to test
    //comm with master
    self.dir_public = __dirname + '/../../code-yeti/';


    p.init = function init(url, appCode) {
        self.loadSettings();
    }

    p.loadSettings = function loadSettings() {
        //rh.requireSequelizeV2();
        self.server_config = rh.loadRServerConfig(true);
        if ( self.server_config.loginAPI == null ) {
            throw new Error('need loginAPI set in settings')
        }
        self.createSessionsDirs()
    }

    /**
     * Ensure directories exist for sessions
     */
    p.createSessionsDirs = function createSessionsDirs() {

        self.dirDefaultProducerSessionDir = sh.getUserHome() + '/' + "sessions_login_api";
        //TODO: Move to rhelpers ... how do consumers get this now?
        self.dirDefaultConsumerSessionDir = sh.getUserHome() + '/' + "sessions_login_consumer_api";

        self.settings = {};
        self.settings.loginAPI = self.server_config.loginAPI;
        self.settings.loginAPIConsumer = sh.dv( self.server_config.loginAPIConsumer, {});

        var loginAPI = self.settings.loginAPI;
        var loginAPIConsumer = self.settings.loginAPIConsumer;

        //set default sessions location, if not defined in config.
        loginAPI.dirSesstions = sh.defaultValue(loginAPI.dirSessions,
            self.dirDefaultProducerSessionDir);
        loginAPI.publicRoutes = sh.defaultValue(loginAPI.publicRoutes,
            ['favicon.ico', 'output.html', 'output/sparrow',
                '/output/scripts', '/output/', '/proxy?']);

        loginAPIConsumer.dirSesstions = sh.defaultValue(
            loginAPIConsumer.dirSesstions,
            self.server_config.global.dir_login_consumer_sessions);

        loginAPIConsumer.dirSesstions = sh.defaultValue(
            loginAPIConsumer.dirSesstions,
            self.dirDefaultConsumerSessionDir);

        sh.makePathIfDoesNotExist(loginAPI.dirSesstions);
        sh.makePathIfDoesNotExist(loginAPIConsumer.dirSesstions);

        //self.settings.loginAPI = loginAPI;
        //self.settings.loginAPIConsumer = loginAPIConsumer;

        self.createCredentialServer();
    }


    p.createCredentialServer = function createCredentialServer() {
        var cQS = new CredentialServerQuickStartHelper() ;
        //var cQS = new cQS();
        self.cQS = cQS;
        //cQS.startLoginAPIServer(self.settings.loginAPI);

        self.defineCredentialServer_Settings()
    }

    p.defineCredentialServer_Settings = function defineCredentialServer_Settings() {
        //Settings for the credential Server
        var cSettings = {};

        cSettings.loginAPI = self.settings.loginAPI;
        cSettings.loginAPIConsumer = self.settings.loginAPIConsumer;

        //provide Db connection to helper
        cSettings.sequelize = rh.getSequelize(false, true);

        //configure ports
        cSettings.loginAPI.port =  self.server_config.loginAPI.port;
        cSettings.loginAPIConsumer.portProducer =  self.server_config.loginAPI.port; //port is for testing.

        //TODO: Remove ...what is significance?
        cSettings.setupRoutes = function setupGenericRoutes(server) {
            console.log('setup routes');
        }

        cSettings.loginAPI.fxPreLoginRoutes = function fxPreLoginRoutes(server) {
            console.log('fxPreLoginRoutes');
            // server.get('/index.html', function )
            server.get('/logout', function(req, res) {
                cSettings.loginAPI.wrapper.destroySession(req);
                res.redirect('/login.html');
                return;
            })


            function middleware_RedirectToIndex(req, res, next) {
                console.error('login check 2', req.isLoggedIn,  req.originalUrl);

                next();
                //console.error('logged in...', req.originalUrl);
                return;

                res.status(404);
                res.json({msg: 'user not logged in', success: false});
            };

            server.use(middleware_RedirectToIndex);
            server.use(express.static(self.dir_public));
        }
        cSettings.loginAPI.debugMiddleware = false;

        var fileHTMLLoginPage = path.resolve(   self.dir_public + '/login.html'   );

        /**
         * Redirect unauthenticated users to login page
         * @param req
         * @param res
         * @param next
         * @param loggedIn
         */
        cSettings.loginAPI.fxGenericPreUserAuthBounceRouteHandler = function fxGenericPreUserAuthBounceRouteHandler(req, res, next,  loggedIn) {
            if ( cSettings.loginAPI.debugMiddleware )
                console.log('fxGenericPreUserAuthBounceRouteHandler', req.isLoggedIn)
            if ( sh.endsWith(req.originalUrl, '.html') && req.isLoggedIn == false) {
                console.error('user not logged in ...')
                res.sendFile(
                    fileHTMLLoginPage
                );
                return false;
            }
        }

        cSettings.loginAPI.fxUserNotLoggedInResultSize = sh.readFile(fileHTMLLoginPage).length;

        /**
         * Route handles all non-authenticated routes.
         * Create 'aliases' for old php routes
         * This method is invoked on every request.
         * if request's url matches php like route, send relevant file
         * @param req
         * @param res
         * @param next
         * @param loggedIn
         * @returns {boolean}
         */
        cSettings.loginAPI.fxGenericRouteHandler = function fxGenericRouteHandler(req, res, next,  loggedIn) {
            if ( cSettings.loginAPI.debugMiddleware )
                console.log('fxGenericRouteHandler', req.isLoggedIn, req.originalUrl, loggedIn )


            var url = req.originalUrl;
            if ( url == '/') {
                // res.redirect('index.html');
                // return false;
            }
            /*  if ( url == '/account.php') {
             //cSettings.loginAPI.wrapper.destroySession(req);
             //res.render('account.php');
             // return;
             var js = sh.toJSONString(csClone);
             res.send(gen.generateIndexHTMLFromPhp("window.config="+ js, cluster_settings.global.title));
             };*/

            if ( url == '/account.html') {
                if ( loggedIn == false  ) {
                    res.sendFile( path.resolve( self.dir_public + '/login.html' ) );
                    return false;
                }

                res.send('account.html');
                return true;
            };

        /*    if ( url == ('/getServerInfo') ) {

                var config = _.pick(self.server_config,
                    'frontend',
                    'searchserver_hostname',
                    'server_hostname',
                    'files'
                );

                res.json( config );
            }*/

            if ( url == '/logout.php') {
                cSettings.loginAPI.wrapper.destroySession(req);
                res.redirect('/');
                return;
            }
            if ( url == '/countUsers') {
                cSettings.loginAPIMasterService.api.test.countUsers(
                    function onCountedUsers(count) {
                    console.log('onCountedUsers', count);
                    var countJSON = {};
                    countJSON.count = count;
                    res.json(countJSON);
                    return;
                });
                return false;
            }
            if ( url == '/clearUserSessions') {
                sh.fs.removeDir(self.dirDefaultProducerSessionDir)
                res.json({deleted:true});
                return false;
            }
            if ( url == '/getCPU') {

                sh.runAsync = function runCommandAsync(cmd, fx, opts) {
                    console.log('running', cmd)
                    var child_process = require('child_process');
                    var  ipAdd = child_process.exec(cmd, opts, fx )
                }

                sh.runAsync('mpstat', function (o,b,c) {
                    console.log('...',o,b,c)
                    res.json({output:o+b+c});
                });
                return false;
            }
            if ( url == ('/index.html') ||  url == '/' || sh.startsWith(url, '/index.html?')) {
                res.setHeader('content-type','text/html');
                if ( loggedIn == false  ) {
                    //if user is not logged in, send login page
                    //replace with port ...
                    res.sendFile(
                        path.resolve(
                            self.dir_public + '/login.html'
                        )
                    );
                } else {
                    /*

                     function getIndex() {
                     var shelpers = require('shelpers');
                     var sh = shelpers.shelpers;

                     var file = dir_public + 'index.php'
                     var strHeader = sh.readFile( dir_public + '_header_minimal.php')

                     sh.replace("<?php echo WEB_ROOT; ?>/", '');

                     var footerStr = sh.readFile( dir_public + '_footer.php')
                     var str = strHeader + sh.readFile(file) + footerStr


                     return str;
                     }
                     */


                    var gen = require('./utils/ExpressUtil_ConvertYetiPhpToRawHTML').gen;

                    //var gen_ = new gen();

                    var loginAPI = self.server_config.loginAPI
                    self.server_config.loginAPI = null;
                    function createUIVersionOfUserSessionObject() {
                        //give UI config object to find servers
                        var csClone = sh.clone(self.server_config)
                        csClone.session = req.session.key;
                        //TODO: Why the wierd names? fustration when debugging
                        csClone.session_tiff = req.cookies.tiffServer;
                        if (req.session.accountExpired ) {
                            csClone.alert = 'Your account has expired. Please go to My Account to extend your account'
                            csClone.expired = true;
                        }
                        csClone.y = '555';
                        delete csClone.mysql
                        delete csClone.scripts
                        delete csClone.email //email password
                        delete csClone.downloads //users cannot see dl locations
                        return csClone;
                    }
                    var js = sh.toJSONString(createUIVersionOfUserSessionObject());
                    res.send(gen.generateIndexHTMLFromPhp("window.config="+ js, self.server_config.global.title));

                    /*res.sendFile(
                     path.resolve(
                     dir_public+'/index.php'
                     )
                     );*/


                }
                return false;
            }


           if (loggedIn) {
                if ( url == ('/getUserInfo') ) {
                    var userInfo = {};
                    userInfo.session = req.session
                    cSettings.sequelize
                    console.log('api', cSettings.loginApi);

                    cSettings.loginAPIMasterService.api.test.getUser(req.session.username, function x(user) {
                        console.log('...');
                        userInfo = sh.clone(user);
                        delete userInfo['id'];
                        delete userInfo['password'];

                        userInfo.username = user.username;
                        res.json(userInfo);

                        return;
                    });
                    // self.credentialsServer.api.test.createUser( newUser, result)
                    return false;
                };

            }


            // server.get('/index.html', function )
        }

        cSettings.fxDone = function loginServerRunning(){
            console.info('Login Server running')
            self.loginServer = self.cQS.credentialsServer;
            self.urls = {}
            self.urls.loginAPI = self.cQS.urlsLogin;

            var EasyRemoteTester = shelpers.EasyRemoteTester;
            var config = {showBody:false};
            //config.baseUrl = ip;
            var t = EasyRemoteTester.create('...---...', config);
            //var t = cSettings.testO.clone();
            t.urls = {};
            t.urls.getIndex = cSettings.testO.utils.createTestingUrl('index.html');
            t.add(function getIndexPage() {
                //pro
                //asdf.g.d.s.d
                t.quickRequest(t.urls.getIndex,
                    'get', result, {})
                function result(body, resp) {
                    t.assert( body!= null, 'could not get index page' );
                    t.assert( resp.statusCode==200, 'could not get index page, , status not 200' );
                    t.cb();
                };

            });


            function verifyExpiredSessionsGetBorked() {


            }
            verifyExpiredSessionsGetBorked()


//            asdf.g.d.d;
            try {
                //end ConsumerService server to prevent spoofing attempts
                self.cQS.api2.app.close();
            } catch ( error ) {}
            //sh.callIfDefined(cb);
        }

        self.cQS.testCredentialsServer(cSettings);
    }



    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return
        }
        sh.sLog(arguments);
    };


}

exports.UserServer = UserServer;
exports.SSSD = UserServer;

if (module.parent == null) {
    var r = new UserServer();
    r.init();
}

