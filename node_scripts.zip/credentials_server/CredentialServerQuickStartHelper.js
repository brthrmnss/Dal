/**
 * Script Provides credential producer-consumer functionality to servers
 * test calls
 * @param sequelize
 * @param DataTypes
 * @returns {*}
 */
//invite.js
var shelpers = require('shelpers');
var sh = shelpers.shelpers;
var ExpressServerHelper = shelpers.ExpressServerHelper;
var TestHelper = shelpers.TestHelper;
var reqPost = TestHelper.reqPost;

var PromiseHelperV3 = shelpers.PromiseHelperV3;

//var TestServer = require('./sparkserver').TestServer;
var EasyRemoteTester = shelpers.EasyRemoteTester;
var SettingsHelper = shelpers.SettingsHelper;

//var LoginAPIConsumerService = require('./example_consumer_service/LoginAPIConsumerService.js').LoginAPIConsumerService;
var ExampleCredentialsAPIConsumerService = require('./example/ExampleCredentialsAPIConsumerService.js').ExampleCredentialsAPIConsumerService;
var ExampleCredentialsAPIProducerService = require('./example/ExampleCredentialsAPIProducerService.js').ExampleCredentialsAPIProducerService;

function CredentialServerQuickStartHelper() {
    var p = CredentialServerQuickStartHelper.prototype;
    p = this;
    var self = this;

    self.settings = {};

    self.testCredentialsServer = function testCredentialsServer(settings) {
        var testCachedRoute = 'd';

        if (settings != null) {
            //only overide null properties
            SettingsHelper.mergeSettings(settings, self.settings)
            //ugh, TODO: why was this necessary
            self.settings = settings;
        }

        //Setting param list:
        SettingsHelper.param(self.settings, 'fxDone', 'called when helper complete');
        SettingsHelper.param(self.settings, 'forceDB', 'create database if exists', false);

        SettingsHelper.param(self.settings, 'loginAPI', 'config for api', {});
        SettingsHelper.param(self.settings.loginAPI, 'server', 'Server to use');
        SettingsHelper.param(self.settings.loginAPI, 'port', 'port for login server', 33530);
        SettingsHelper.param(self.settings.loginAPI, 'dirSessions',
            'directory for sessions for login api',
            sh.getUserHome() + '/' + 'trash/vidserv/'+'login_api_sessions');

        SettingsHelper.param(self.settings, 'loginAPIConsumer', 'config for loginAPIConsumer', {});
        SettingsHelper.param(self.settings.loginAPIConsumer, 'port', 'port for login  consumer server', 37331);
        SettingsHelper.param(self.settings.loginAPIConsumer, 'dirSessions',
            'directory for sessions for test server',
            sh.getUserHome()+'/trash/vidserv/'+'test_login_consumer_api_sessions');
        SettingsHelper.param(self.settings.loginAPIConsumer, 'portProducer',
            'what port does the producer use?',
            self.settings.loginAPI.port);
        SettingsHelper.param(self.settings.loginAPIConsumer, 'baseUrl',
            'what url is url for producer?',
            null);
        /*SettingsHelper.param(self.settings.loginAPIConsumer, 'loginServiceOverrideURL',
         'how does the consumer service talk to api? ',
         'http://127.0.0.1:'+ self.settings.loginAPI.port);*/

        //pass port to createTestingUrl will use proper port
        self.settings.port = self.settings.loginAPI.port;

        if ( self.settings.sequelize == null ) {
            var rh = require('rhelpers');
            self.settings.sequelize = rh.getSequelize(false, true);
        }

        self.setupCredentialProducerAndConsumer();
    }

    /**
     * Starts work chain
     *
     */
    p.setupCredentialProducerAndConsumer = function setupCredentialProducerAndConsumer() {
        self.settings.silent = true;
        //console.error('is this it')
        var t = EasyRemoteTester.create('test login server', self.settings);
       // console.error('is this it2')
        self.t = t;
        function testChain() {
            console.log('testChain');
            t.cb();
        }

        t.add(testChain);

        t.add(function testChain() {
            console.log('testChain');
            t.cb();
        });

        //create database if user wants to force it
        //if ( self.settings.forceDB != false ) {
        //Get models for user and session
        t.add(function createTables() {
            console.log('creating tables')
            var session = require('./../utils/database/models/sessions.js');
            var user = require('./../utils/database/models/users.js');
            var SequelizeHelper = shelpers.SequelizeHelper;
            SequelizeHelper.updateDatabase({
                tables: [session, user],
                fxDone: tablesSycnedOrCreated,
                force: self.settings.forceDB,
                sequelize: self.settings.sequelize
            })
            function tablesSycnedOrCreated(token) {
                //TODO: fix enum definition issue
                //asdf.h
                self.sequelize = token.sequelize
                t.cb();
            }
        });

        self.runFunctionalTestCredentialServers();
    }

    /**
     * Run url functional tests to verify functionality
     */
    p.runFunctionalTestCredentialServers = function runFunctionalTestCredentialServers() {
        var t = self.t;
        var urls = {}
        urls.login = t.utils.createTestingUrl('api/login');
        urls.logout = t.utils.createTestingUrl('api/logout');
        urls.api_otherMethod = t.utils.createTestingUrl('api/test');

        self.urlsLogin = urls;
        var newUser = {username: 'mark', password: "randomTask2"};
        var newUser2 = {username: 'mark2', password: "randomTask2"};

        var expiredDate = new Date();
        expiredDate.setTime((expiredDate).getTime()+(24*60*60*1000))
        //console.error(expiredDate)
        //process.exit();
        newUser.paidExpiryDate = expiredDate;
        newUser2.paidExpiryDate = expiredDate;


        var newUserMarkExpired = {username: 'markExpired', level:"NEOPHITE", password: "randomTask2"};

        var tH = {};

        function defineHighLevelHelpers() {
            tH.login = function te(u,p, fx) {
                if (u.username ) {
                    fx = p;
                    p = u.password;
                    u = u.username;

                }


                t.add(function login_withBadUsername() {
                    console.error('logging in with', u, p)
                    t.quickRequest(urls.login,
                        'post', result, {username: u, password: p})
                    function result(body) {
                        t.assert(body != 'Cannot POST /api/login', 'api/login route not working ' + urls.login)
                        t.assert(body.success== true, 'cannot login ' + u + ' ' + p)
                        console.error('logging in with', body)
                        t.key = body.key;
                        t.keyFor = u;
                        sh.callIfDefined(fx,t, body)
                        t.cb();
                    }

                });

            }

            tH.ensureLoggedOut = function ensureLoggedOut(){ //log out current user ...
                t.add(function testLoginAction() {
                    t.quickRequest(urls.logout,
                        'post', result)
                    function result(body) {
                        //t.assert( body.success == true, 'user was not able to logout' );
                        t.cb();
                    }
                });
                t.add(function testLoginAction() {
                    t.quickRequest(urls.logout,
                        'post', result)
                    function result(body) {
                       console.error('body', sh.q(body))
                         t.assert( body.trim() == 'Cannot POST /api/logout', 'user was not able to logout' );
                        t.cb();
                    }
                });
            }


            tH.resetLogin = function resetLogin(user){ //log out current user ...
                tH.c.ensureLoggedOut();
                tH.ensureLoggedOut()
                tH.login(user)
            }




        }
        defineHighLevelHelpers();


        t.add(function launchServer() {
            // asdf.h

            var c = new ExampleCredentialsAPIProducerService( );
            self.credentialsServer = c;
            self.settings.loginAPIMasterService = c; //store for later use
            var cSettings = self.settings.loginAPI;
            cSettings.fxDone = credentialServerStarted;
            cSettings.sequelize = self.sequelize; //use overridden if required
            cSettings.setupRoutes = self.settings.setupRoutes; //copy callback manually
            c.startCredentialServer(  cSettings  );

            function credentialServerStarted() {
                c
                t.cb();
            }
        });

        //begin testing ....

        t.workChain.utils.wait(1);
        t.workChain.utils.wait(1);
        t.add(function login_withBadUsername() {
            t.quickRequest(urls.login,
                'post', result, {username: 'mark', password: "randomTask"})
            function result(body) {
                //t.assert(body=='4', 'msg .... ');
                //console.log('body', body)
                t.assert(body != 'Cannot POST /api/login', 'api/login route not working ' + urls.login)
                t.assert(body.success== false, 'allowed bad username to login')
                t.cb();
            }

        });
        t.add(function deleteExistingUser() {
            self.credentialsServer.api.test.deleteUser( newUser,
                t.cb)
        })
        t.add(function deleteExistingUser__newUser2 () {
            self.credentialsServer.api.test.deleteUser( newUser2,
                t.cb)
        })

        t.add(function addRecord() {
            /*var user = self.credentialsServer.data.mdl_User.build(
             {username: 'mark', password: "randomTask2"})
             user.save()
             .complete(function(err) {
             if (!!err) {
             console.log('The instance has not been saved:', err)
             } else {
             console.log('We have a persisted instance now')
             t.cb();
             }
             })*/
            //var newUser = {username: 'mark', password: "randomTask2"}
            self.credentialsServer.api.test.createUser( newUser,
                t.cb)
        });

        self.testUtils.createUser(t,newUser2 );

        self.testUtils.desc('test if user can hit method on same server as loginapi')
        //i expect it should pass
        self.testUtils.makeTestRequestFail(t, urls.api_otherMethod)


        t.add(function testLoginWithNewUser() {
            t.quickRequest(urls.login,
                'post', result, {username: 'mark', password: "randomTask2"})
            function result(body) {
                t.assert(body.msg=='success' , 'did not successfully login')
                t.key = body.key;
                t.cb();
            }
        });

        self.testUtils.makeTestRequest(t, urls.api_otherMethod);



        function testExpiredAccounts () { //newUserMarkExpired
            t.add(function deleteExistingUser() {
                console.info('deleting mark expired')
                self.credentialsServer.api.test.deleteUser( newUserMarkExpired,
                    t.cb)
            })
            t.add(function deleteExistingUser() {
                console.info('deleting mark expired-after')
                //process.exit();
                self.credentialsServer.api.test.deleteUser( newUserMarkExpired,
                    t.cb)
            })
            var paidExpiryDate =  new Date();
            paidExpiryDate.setTime( new Date().getTime()- 3*24*60*60*1000 ); //3 days ago
            newUserMarkExpired.paidExpiryDate = paidExpiryDate;
            self.testUtils.createUser(t,newUserMarkExpired)
            tH.login(newUserMarkExpired, function verifyExpired(t, data){
                t.assert(data.accountExpired==true, 'expired user not expired')
            });
            tH.ensureLoggedOut()

            tH.login(newUser, function verifyExpired(t, data){
                t.assert(data.accountExpired!=true, 'non-expired user expired')
            });

            tH.ensureLoggedOut()

        }
        testExpiredAccounts();



        function testLoginConsumerServer() {

            //generate urls for future links
            t.settings.portOverride = self.settings.loginAPIConsumer.port;
            urls.testConsumer = t.utils.createTestingUrl('api/test');

            urls.testConsumer2 = t.utils.createTestingUrl('test2');
            urls.testConsumer2_api = t.utils.createTestingUrl('api/test2');
            urls.testConsumer_logout = t.utils.createTestingUrl('api/logout');

            urls.verifyConsumer = t.utils.createTestingUrl('api/verify');
            urls.testConsumer_expireKey = t.utils.createTestingUrl('api/expireKey');
            urls.getUserInfo = t.utils.createTestingUrl('getUserInfo');
            urls.getUserInfo = 'http://localhost:'+self.settings.loginAPI.port + '/getUserInfo';


            function defineHellpersForConsumerServer() {
                tH.c = {}
                tH.c.ensureLoggedOut = function ensureLoggedOut(){ //log out current user ...
                    t.add(function testLateAddedRoute() {
                        t.quickRequest(urls.testConsumer_logout,
                            'post', result)
                        function result(body) {
                            t.cb();
                        }
                    });
                }
            }
            defineHellpersForConsumerServer()

            t.urls = urls;

            t.settings.portOverride = null;
            self.settings.testO = t;

            t.add(function launchLoginConsumerServer() {
                var c = new ExampleCredentialsAPIConsumerService();
                self.api2 = c

                var cCSettings = self.settings.loginAPIConsumer;
                cCSettings.fxDone = credentialConsumerServerStarted;
                cCSettings.sequelize = self.sequelize; //use overridden if required
                c.startExampleCredentialsAPIConsumerService2( cCSettings );

                function credentialConsumerServerStarted() {
                    t.cb();
                }
            });
            t.workChain.utils.wait(1);
            t.add(function makeRequestToConsumerAPI_WithoutLoggingIn() {
                t.quickRequest(urls.testConsumer,
                    'get', result, {username: 'mark', password: "randomTask"})
                function result(body) {
                    t.assert( body.success == false, 'user was able to communicate without trying' );
                    t.cb();
                }
            });

            tH.resetLogin(newUser);
            /**
             * Test interface, can user define a route, after the api and still
             * have the api block it
             */
            t.add(function testLateAddedRoute_EnsuresConsumerHelperGuardsPreExistingRoutes() {
                t.quickRequest(urls.testConsumer2,
                    'get', result )//, {username: 'mark', password: "randomTask"})
                function result(body) {
                    t.assert( body.success == false, 'user was able to communicate without trying' );
                    t.cb();
                }
            });

            t.add(function tryVerify_LoginUserToRemoteAPI() {
                console.log('tryVerify_LoginUserToRemoteAPI', t.keyFor)
                t.quickRequest(urls.verifyConsumer+'?key='+ t.key,
                    'post', result, {key:t.key})
                function result(body) {
                    console.error('what is body', body)
                    t.assert( body.msg == 'success', 'could not verify with key' );
                    t.cb();
                }
            });
            t.add(function tryRouteAFterVerify() {
                t.quickRequest(urls.testConsumer,
                    'post', result);
                function result(body) {
                    //t.assert(body=='4', 'msg .... ');
                    t.cb();
                }

            });



            return;

            t.add(function testLateAddedRoute() {
                t.quickRequest(urls.testConsumer2,
                    'post', result)
                function result(body) {
                    t.assert( body.success == true, 'verified user could not communicate' );
                    t.cb();
                }
            });
            t.add(function testLateAddedRoute() {
                t.quickRequest(urls.testConsumer2_api,
                    'post', result, {username: 'mark', password: "randomTask"})
                function result(body) {
                    t.assert( body.success == true, 'user was able to communicate without trying' );
                    t.cb();
                }
            });

            function ensureLoggedOut(){ //log out current user ...
                t.add(function testLateAddedRoute() {
                    t.quickRequest(urls.testConsumer_logout,
                        'post', result)
                    function result(body) {
                        //t.assert( body.success == true, 'user was not able to logout' );
                        t.cb();
                    }
                });
            }
            function tryLoggingOUt(){
                t.add(function testLateAddedRoute() {
                    t.quickRequest(urls.testConsumer_logout,
                        'post', result)
                    function result(body) {
                        t.assert( body.success == true, 'user was not able to logout' );
                        t.cb();
                    }
                });
                t.add(function verifyLoggedOutUserCannotTalkToServer() {
                    t.quickRequest(urls.testConsumer2_api,
                        'post', result, {username: 'mark', password: "randomTask"})
                    function result(body) {
                        t.assert( body.success != true, 'user was able to communicate without trying' );
                        t.cb();
                    }
                });
            }
            tryLoggingOUt();


            function tryToUseFakeKey(){
                t.add(function testFakeKey() {
                    t.quickRequest(urls.testConsumer,
                        'get', result, {username: 'mark', password: "randomTask", key:'fakekey'})
                    function result(body) {
                        t.assert( body.success == false, 'user was able to communicate without trying' );
                        t.cb();
                    }
                });
            }
            tryToUseFakeKey();


            function testExpiringCookie(){
                self.testUtils.verifyKey(t, urls.verifyConsumer);

                t.add(function expireKey() {
                    t.quickRequest(urls.testConsumer_expireKey,
                        'get', result )
                    function result(body) {
                        t.assert( body.success == true, 'could not exprie key' );
                        t.cb();
                    }
                });

                t.workChain.utils.wait(2);
                self.testUtils.makeTestRequestFail(t,urls.testConsumer)
            }
            testExpiringCookie();



            function testKeyInQuery(){

                //authenticating to client-consumer-service directly when key not present
                ensureLoggedOut();
                //send up request
                t.add(function testFakeKey() {
                    t.quickRequest(urls.testConsumer,
                        'get', result, {username: 'mark',
                            password: "randomTask",
                            session_id: t.key})
                    function result(body) {
                        t.assert( body.success, 'User could not use query session id to make request' );
                        t.cb();
                    }
                });
            }
            testKeyInQuery();

            function testExpiredUserConsumerAPI(){
              /*  t.add(function breakTest() {
                    asdf.gggg
                });*/
                //authenticating to client-consumer-service directly when key not present
                tH.c.ensureLoggedOut();
                tH.ensureLoggedOut()

                tH.login(newUserMarkExpired)


                t.add(function testLateAddedRoute_EnsuresConsumerHelperGuardsPreExistingRoutes() {
                    t.quickRequest(urls.testConsumer2,
                        'get', result )
                    function result(body) {
                        t.assert( body.success == false, 'user was able to communicate without trying' );
                        t.cb();
                    }
                });

                t.add(function tryVerify_LoginUserToRemoveAPI() {
                    t.quickRequest(urls.verifyConsumer+'?key='+ t.key,
                        'post', result, {key:t.key})
                    function result(body) {
                        t.assert( body.msg == 'success', 'could not verify with key' );
                        t.cb();
                    }
                });

                t.add(function tryRouteAFterVerify() {
                    t.quickRequest(urls.testConsumer,
                        'post', result);
                    function result(body) {
                        console.error('body', body)
                        //process.exit()
                         t.assert(body.msg=='account expired', 'expired user can make cals on client server ');
                        t.cb();
                    }
                });

                t.add(function testLateAddedRoute() {
                    t.quickRequest(urls.testConsumer2,
                        'post', result, {username: 'mark', password: "randomTask"})
                    function result(body) {
                        t.assert(body.msg=='account expired', 'expired user can make cals on client server ');
                        t.cb();
                    }
                });

                t.add(function testLateAddedRoute() {
                    t.quickRequest(urls.testConsumer2_api,
                        'post', result, {username: 'mark', password: "randomTask"})
                    function result(body) {
                        t.assert(body.msg=='account expired', 'expired user can make cals on client server ');
                        t.cb();
                    }
                });

                //send up request
                t.add(function testFakeKey() {
                    t.quickRequest(urls.testConsumer,
                        'get', result, {
                            session_id: t.key})
                    function result(body) {
                        t.assert(body.msg=='account expired', 'expired user can make cals on client server ');
                        t.cb();
                    }
                });
            }
            testExpiredUserConsumerAPI();



        }
        testLoginConsumerServer()


        function testGetUserInfo(){
            t.add(function testLoginWithNewUser() {
                console.log('test Get User Info ...............')
                t.quickRequest(urls.login,
                    'post', result, {username: 'mark', password: "randomTask2"});
                function result(body) {
                    t.assert(body.msg=='success' , 'did not successfully login');
                    t.key = body.key;
                    t.keyFor = 'mark'
                    t.cb();
                };
            });
            t.add(function testGetUserInfoX() {
                console.log('log', urls.getUserInfo);
                t.quickRequest(urls.getUserInfo,
                    'get', result )
                function result(body) {
                    console.log('body:', body);
                    console.log('body.success:', body.success,  body.success === false);

                    t.assert( body != null, 'coulfd not get account' );
                    t.assert( body.success != false , 'not logged' );
                    t.cb();
                }
            });
        }
        testGetUserInfo();


        //t.workChain.utils.wait(2);
        //self.testUtils.makeTestRequestFail(t,urls.testConsumer)


        t.xadd(function createTablesCreateFakeValues() {
            var session = require('./../../utils/database/models/sessions.js');
            var user = require('./../../utils/database/models/users.js');
            var SequelizeHelper = shelpers.SequelizeHelper;
            SequelizeHelper.updateDatabase({
                tables:[session,user],
                fxDone: tablesCreated, force:false
            })
            function tablesCreated() {
                t.cb();
            }
        });


        t.addS(function testChain2(token, cb) {
            t.quickRequest(self.createTestingUrl(testCachedRoute),
                'get', result, {name: "randomTask"})
            function result(body) {
                //t.assert(body=='4', 'msg .... ');
                t.cb();
            }
        })
    }

    self.startLoginAPIServer = function startLoginAPIServer(config) {

        var c = new ExampleCredentialsAPIProducerService( );
        self.credentialsServer = c;

        var cSettings = config
        cSettings.fxDone = credentialServerStarted;
        //cSettings.sequelize = self.sequelize; //use overridden if required
        c.startCredentialServer(  cSettings  );

        function credentialServerStarted() {
            sh.callIfDefined(config.cb)
        }
    }


    /**
     * Another level of nesting. Pass the RemoteTestHelper and
     * a method will be defined for the behavior.
     */
    function defineTestHelpers() {

        //asdf.c.


        self.testUtils= {};
        self.testUtils.login = function login(t, url, username, password ) {
            t.add(function testLoginWithNewUser() {
                t.quickRequest(url,
                    'post', result, {username: username, password:password});

                function result(body) {
                    console.log('login', body)
                    t.assert(body!=null ,'could not communicate with login server '+ url);
                    //console.error('could not communicate with login server', url)
                    t.assert(body.msg=='success' , 'did not succesfufly login');
                    t.key = body.key;
                    t.user_id = body.user_id;
                    t.keyFor = username;
                    t.cb(t.key);
                    return;
                }
            });
            return;
        }

        self.testUtils.loginFail = function loginFail(t, url, username, password ) {
            t.add(function testLoginWithNewUser() {
                t.quickRequest(url,
                    'post', result, {username: username, password:password})
                function result(body) {
                    t.assert(body!=null ,'could not communicate with login server '+ url);
                    t.assert(body.success==false , 'bad username logged in')
                    t.cb();
                }
            });
        }
        self.testUtils.logout = function logout(t, url  ) {
            t.add(function testLogout() {
                t.quickRequest(url,
                    'get', result )
                function result(body) {
                    t.assert(body.success==true ||
                        body.success==false, 'could not log out ' + body);
                    t.cb();
                }
            });
        }
        self.testUtils.createUser = function createUser(t, newUser  ) {
            t.add(function testLogout() {
                //var newUser  = {username: 'mark', password: "randomTask2"}
                self.credentialsServer.api.test.createUser( newUser,
                    result)
                function result(body) {
                    t.cb();
                }
            });
        }

        self.testUtils.verifyKey = function verifyKey(t, url ) {
            t.add(function tryVerify_LoginUserToRemoveAPI() {
                t.assert(t.key != null , 'key is not specified');
                t.quickRequest(url+'?key='+ t.key,
                    'post', result, {key: t.key})
                function result(body) {
                    t.assert( body.msg == 'success', 'could not verify with key' );
                    t.cb();
                }
            });
        }
        self.testUtils.makeTestRequest = function makeTestRequest(t, url ) {
            t.add(function tryToMakeRequestAgainstServer() {
                t.assert(t.key != null , 'key is not specified');
                t.quickRequest(url+'?key='+ t.key,
                    'post', result, {key: t.key})
                function result(body) {
                    t.assert( body.success != false, 'user not was able to communicate ' );
                    t.cb();
                }
            });
        }
        self.testUtils.makeTestRequestFail = function makeTestRequestFail(t, url ) {
            t.add(function tryToMakeRequestAgainstServer_ExpectFailure() {
                t.quickRequest(url+'?key='+ t.key,
                    'post', result, {key: t.key})
                function result(body) {

                    console.error('bodoy', body)
                    console.error(self.settings.loginAPIMasterService.settings.fxUserNotLoggedInResultSize, 'what is this....')
                    //var ok = ( body.length ==  self.settings.loginAPIMasterService.settings.fxUserNotLoggedInResultSize)
                    //asdf.g
                    var expectedSize = self.settings.loginAPIMasterService.settings.fxUserNotLoggedInResultSize;
                    if ( body.success !=  false && expectedSize != null  ) {
                        t.assert( expectedSize == body.length,url +' did not get a valid ... non-auth user result ' + expectedSize + ' ' +  body.length );
                    } else {
                        t.assert( body.success == false,url +'user was able to communicate without trying' );
                    }

                    t.cb();
                }
            });
        }

        /**
         * add description to next method
         */
        self.testUtils.desc = function () {

        }
    }
    defineTestHelpers();

}


exports.CredentialServerQuickStartHelper = CredentialServerQuickStartHelper;
exports.CredentialServerQuickStartHelper.LoginAPIConsumerService = ExampleCredentialsAPIConsumerService;
exports.CredentialServerQuickStartHelper.ExampleCredentialsAPIProducerService = ExampleCredentialsAPIProducerService

exports.CredentialServerQuickStartHelper.createServer = function createServer() {

};


if ( module.parent  == null ) {
    //return;
    var s = new CredentialServerQuickStartHelper()
    s.testCredentialsServer();

}


