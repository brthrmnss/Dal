// server.js
// =============================================================================
var express    	= require('express');

var bodyParser 	= require('body-parser');
var session 	= require('express-session');
var FileStore   = require('session-file-store')(session);
var cookieParser= require('cookie-parser');
var cookie = require('cookie')
var shelpers = require('shelpers');
var sh = shelpers.shelpers;
var credentialAPI = require('cookie')

var ExampleCredentialsAPIConsumerService =
    require('./../example/ExampleCredentialsAPIConsumerService').ExampleCredentialsAPIConsumerService;

function CredentialConsumerAPI() {
    var p = CredentialConsumerAPI.prototype;
    var self = this;
    p = this;


    self.decorateApp = function decorateApp(app, settings) {
        self.settings = settings;
        app.use(bodyParser());

        console.log('starting', 'LoginAPIConsumerService', settings.dirSessions)//, new Error().stack);

        sh.makePathIfDoesNotExist(self.settings.dirSessions);

        var dirSession = settings.dirSessions+ '/'+Math.random() //randomize session dir to prevent collisions
       // sh.fs.mkdirp(dirSession)

        //need to set session or we cannot communicate between servers
        app.use(session({
                name: 'logCred',
                store: new FileStore(
                    {
                        path: dirSession
                    }
                ),
                //cookie:{path:'192.168.81.133:10003/', httpOnly:true, secure:false, maxAge:null},
                //{path:'192.168.81.133:10003/', httpOnly:true, secure:false, maxAge:null},
                secret: 'spaceyok',
                resave: false,
                saveUninitialized: false
                //saveUninitialized: true
            }
        ));
        //var api_routes = express.Router();
        self.createRoutes(app, settings);
        //app.use('/api', api_routes);
    }

    self.pullSessionIDFromRequest = function pullSessionIDFromRequest(req, useQuery) {
        var sessionId_cookie    = (typeof req.cookie !== 'undefined') ? req.cookie.key : undefined
        var sessionId_querystr  = (typeof req.query !== 'undefined') ? req.query.key : undefined
        var sessionId_bodystr   = (typeof req.body !== 'undefined') ? req.body.key : undefined
        //sessionId_postdata 	=  (typeof req.body !== 'undefined')? req.body.key : undefined,
        var sessionId_session   = (typeof req.session !== 'undefined') ? req.session.key : undefined;
        var sessionId_session2   =   req.query.session_id;
        var sessionId_session3   =   req.headers.session_id;

        if (useQuery) {
            if (sessionId_querystr != null) {
                //have to verify this is a valid non-expired session
            }
            return sessionId_session || sessionId_querystr || sessionId_bodystr
                || sessionId_session2 || sessionId_session3;
        }
        else {
            return sessionId_session;
        }
    }


    /**
     * Creates routes for API
     * @param router
     */
    self.createRoutes = function createRoutes(router, settings) {
        var md5 = require('MD5');
        var request = require('request');
        var PasswordHash = require('phpass').PasswordHash;
        var passwordHash = new PasswordHash();


        function isUserLoggedInViaSession(req) {
            //we have no way of verifying sessions
            //risk: user can send any query string and be let through
            //if you use the query string ... then yo u need to make
            // a new request against the server

            // return false;
            sh.callIfDefined(self.settingsfxValidateOrigin);

            //Allow non-authenticated users to hit the verify route
            if (req.originalUrl.indexOf('/api/verify') != -1) {
                //only allow req.query.key if using verify route
                //console.log('isUserLoggedInViaSession', LoginAPIConsumerService.pullSessionIDFromRequest( req , false),
                //   LoginAPIConsumerService.pullSessionIDFromRequest( req , true));
                //return LoginAPIConsumerService.pullSessionIDFromRequest( req , true);
                return true;
            }

            console.log('LoginAPIConsumerService', 'key', req.session.key, req.session, req.cookies, req.query);
            /*req.session.reload(function (err) {
             console.log('reload', req.session);
             })*/
            return self.pullSessionIDFromRequest(req, false);
        }

        function isUserLoggedInAtMainCreateLocalSession(sessionKey, req, res) {

            request.post(
                { qs: { key: sessionKey },
                    uri: settings.loginServiceURL + '/api/verify', json: true
                },
                function onResult(error, resp, body) {
                    if (!error && resp.statusCode == 200) {
                        console.log('isUserLoggedInAtMainCreateLocalSession', 'result', body);
                        if (body.success) {
                            //create a local session key
                            var sess = req.session;
                            sess.key = sessionKey;
                            sess.account_expired = body.account_expired;
                            console.log(sess, '...', '7')
                            if ( sess.account_expired)
                            {
                                console.error('>>>>>>>>>>>>>>>>account is expired .......')
                                // asdf.g
                            }
/*
                            var c2 = cookie.serialize('filehostingX', sessionKey);
                            res.setHeader('Set-Cookie', c2);
                            res.cookie2 = function (k, v, hsh) {
                                var c2 = cookie.serialize(k, v, hsh);
                                res.append('Set-Cookie', c2);
                            }
                            res.cookie2('filehosting',sessionKey, {
                                domain: '127.0.0.1:33037',
                                domain: '127.0.0.1:33037',
                                maxAge: 900000,
                                httpOnly:true});

                            res.cookie2('filehostingG',sessionKey, {
                                domain: '127.0.0.1:33037',
                                domain: self.settings.fullUrl,
                                maxAge: 900000,
                                httpOnly:true});
                            res.cookie2('filehostingDDD',sessionKey, {
                                domain: '127.0.0.1:33037',
                                domain: self.settings.fullUrl,
                                maxAge: 900000,
                                httpOnly:true})

                            console.error('filehostingDDDD', self.settings.fullUrl)
                            res.cookie2('filehostingDDD',sessionKey, {
                                domain: self.settings.fullUrl,
                                maxAge: 900000,
                                httpOnly:true})

*/
                            console.error('headers', res.headers, res.getHeader('Set-Cookie'))
                            if ( res.fxDone != null ) {
                                res.fxDone(true)
                                return
                            }
                            res.json({ msg: 'success', success: true });

                        }
                        else {
                            console.error('user not found on xverify',
                                settings.loginServiceURL,
                            'body was', body)

                            process.exit();
                            /*if ( res.fxDone != null ) {
                                res.fxDone(false)
                                return
                            }*/
                            res.statusCode = 401
                            res.json({ msg: 'not found xv', success: false });
                            return;
                        }
                    }
                    else {
                        console.error('--isUserLoggedInAtMainCreateLocalSession', error, body, resp.statusCode);
                        /*if ( res.fxDone != null ) {
                            res.fxDone(false)
                            return
                        }*/
                        res.json({ msg: 'An error occurred while searching for users: ', success: false});
                        return false;
                    }
                }
            )

        }


        function LoginServiceConsumerAPI(router) {

            router.use(function topMiddleware_BlockUsersWithoutSessions(req, res, next) {
                res.header("Access-Control-Allow-Credentials", 'true');
                var origin = req.headers.origin
                if ( origin != null ){
                    res.header("Access-Control-Allow-Origin", origin);

                } else
                {
                    res.header("Access-Control-Allow-Origin", "*");
                }
                res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");


                if (req.session != null &&
                    req.session.cookie != null &&
                    req.session.cookie.expires == 0) {
                    //try to see if user is logged in in main server
                    req.session.destroy();
                }
                console.log('checking if user is logged in', req.originalUrl);
                if (isUserLoggedInViaSession(req)) {

                    console.error('isUser expired?', req.session, req.session.account_expired)
                    if (req.originalUrl.indexOf('/api/verify') == -1) { //if not verify route
                        if (req.session.account_expired == true) { //if account expired
                            res.status(404)
                            res.json({msg: 'account expired', success: false});
                            return;
                        }
                    }
                    //check if ip address is valid
                    //check if session is valid
                    next();
                    return true
                }
                else {
                    /*req.session.reload(function(err){
                     var y = req.session
                     console.log('x');
                     })*/

                    //if no session try to do a lookup //wtf is this?
                    if ( req.query.session_id ) {
                        console.log('no session but have a search id')
                        res.fxDone  = function onK(result) {
                            next();
                        }
                        verifyOnUserSession(req, res);
                        return;
                    }


                    console.log("\n", 'consumer', 'not logged in')

                    res.status(404)
                    res.json({msg: 'user not logged in', success: false});
                }
            });

            router.get('/', function generalRoute(req, res) {
                var sessioninfo = req.cookies;
                res.json({ message: 'hooray! welcome to our root!' });
                if (sessioninfo != null) {
                    console.log("someone is coming in", sessioninfo.filehosting);
                }
            });

            router.post('/api/test', function testRoute(req, res) {
                console.log('---test route');
                console.log('---expires', req.session.cookie.maxAge / 1000);
                res.json({success: true, test: 'test route'});

            });
            //used to verify get secuiry key risk
            router.get('/api/test', function testRoute(req, res) {
                console.log('---test route');
                console.log('---expires', req.session.cookie.maxAge / 1000);
                console.log('---session', req.sessio);
                res.json({success: true, test: 'test route'});
            });

            /**
             * Will maxAge cookie to 1 second
             */
            router.get('/api/expireKey', function testRoute(req, res) {
                req.session.cookie.maxAge = 1;
                console.log('max age', req.session.cookie.expires);
                req.session.save();
                res.json({success: true, test: 'test route'});
            });


            function verifyOnUserSession(req, res) {
                var sessionKey = self.pullSessionIDFromRequest(req, true);
                console.log("\n", '/api/verify', 'sent session key', sessionKey);
                if (sessionKey != null) {
                    isUserLoggedInAtMainCreateLocalSession(sessionKey, req, res);
                    return;
                };

                res.status(404);
                res.send('unknown. verify apache')

            }

            router.post('/api/verify', verifyOnUserSession);
            router.get('/api/verify', verifyOnUserSession);

            router.post('/api/logout', function logoutUser(req, res) {
                req.session.destroy();
                res.json({success: true });

            });

        };


        //module.exports = LoginServiceConsumerAPI;


        LoginServiceConsumerAPI(router)


    }

}

exports.CredentialConsumerAPI = CredentialConsumerAPI;


if ( module.parent == null ) {
    var c = new ExampleCredentialsAPIConsumerService();
    c.startExampleCredentialsAPIConsumerService2()
}
