var md5 			= require('MD5');
var PasswordHash 	= require('phpass').PasswordHash;
var passwordHash 	= new PasswordHash();
var sh = require('shelpers').shelpers;

var rh = require('rhelpers')

function CredentialServerAPI() {

    var self = this;
    var p = self;

    self.db = {};
    self.settings = {};

    p.init = function init() {

    };


    p.decorateApp = function decorateApp (router, User, Session, app, _self) {


        self.db.User = User;
        self.db.Session = Session;
        self._self = _self; //TODO: what is this a reference to?

        router.use(function (req, res, next) {
            //console.log('Something is happening.yo');
            next();
        });

        //self.FileStore = _self.settings.FileStore;
        self.fileStore = app.sessionStore;
     /*   self.fileStore.get('2334', function (ccc) {
            console.log('...', ccc)
        })
*/
        function handleRouting() {

            self.utils.createTestingAPI(router);

            //Any method defined here will be called before invalid session check
            app.get('/api2/', function generalRoute(req, res) {
                res.json({message: 'hooray! before block!'});
            });

            app.use(self.topMiddleware_DetectLoggedInUsers);

            app.use(function topMiddleware_AllowCrossDomain_forTesting(req, res, next) {
                if ( req.isLoggedIn == true ) {
                    //if is in testing mode allow any origin ... for testing ...
                    console.error('block block block', req.originalUrl)
                    rh.validateOrigins(req,res, true);
                }
                next();
            });

            if (_self.settings.fxPreLoginRoutes != null) {
                _self.settings.fxPreLoginRoutes(app);
            }
            app.use(self.topMiddleware_BlockUsersWithoutSessions);

            router.fxSecure = self.topMiddleware_BlockUsersWithoutSessions

            router.get('api/', function generalRoute(req, res) {
                var sessioninfo = req.cookies;
                res.json({message: 'hooray! welcome to our root!'});
                console.log("someone is coming in", sessioninfo.filehosting);
            });
            self.router = router;
        }

        handleRouting();

        self.createAPIRoutes(_self, router);
    }

    function defineMiddleware() {


        /**
         * Detects logged in users
         * First midldware
         * will put on req isLoggedIn
         * @param req
         * @param res
         * @param next
         */
        p.topMiddleware_DetectLoggedInUsers = function topMiddleware_DetectLoggedInUsers(req, res, next) {
            var _self = self._self;
            if ( _self.settings.debugMiddleware ) {
                console.error('topMiddleware_DetectLoggedInUsers', req.originalUrl);
            }
            if (req.session != null &&
                req.session.cookie != null &&
                req.session.cookie.expires == 0) {
                req.session.destroy();
            }

            req.userId = req.session.user_id;
            //console.log('checking if user is logged in', req.originalUrl);
            var isUserLoggedIn_ = self.isUserLoggedIn(req)
            req.isLoggedIn = isUserLoggedIn_

            if (_self.settings.fxGenericPreUserAuthBounceRouteHandler) {
                var continueToNext = _self.settings.fxGenericPreUserAuthBounceRouteHandler(req, res, next, isUserLoggedIn_);
            }

            if (continueToNext == false) {
                return;
            }


            next();
        };


        /**
         * Block users with sessions
         * @param req
         * @param res
         * @param next
         */
        p.topMiddleware_BlockUsersWithoutSessions = function topMiddleware_BlockUsersWithoutSessions(req, res, next) {
            var _self = self._self;
            if ( _self.settings.debugMiddleware ) {
                console.error('topMiddleware_BlockUsersWithoutSessions', req.isLoggedIn, req.originalUrl);
            }
            var isUserLoggedIn_ = req.isLoggedIn;



            //invoke extended routes with session data.
            if (_self.settings.fxGenericRouteHandler) {
                var continueToNext = _self.settings.fxGenericRouteHandler(req, res, next, isUserLoggedIn_);
            }

            if (continueToNext == false) {
                return;
            }

            //onto routes? ... not sure
            if (isUserLoggedIn_ || _self.checkPublicRoutes(req)) {
                next();
                console.error('topMiddleware_BlockUsersWithoutSessions', 'logged in...', req.originalUrl);
                return;
            }
            console.error('topMiddleware_BlockUsersWithoutSessions', 'not logged in');

            res.status(404);
            res.json({msg: 'user not logged in', success: false});
        };

    }
    defineMiddleware();

    p.createAPIRoutes = function createAPIRoutes(_self, router) {
        var User = self.db.User;

        //var router = self.routes;
        router.post('/api/login', function handleAuthentication(req,res){

            console.log( "-- someone is logging in" );

            var sessionID 	= self.pullSessionIDFromRequest( req, true )
            var    sess		= req.session;

            var input_password	= req.body.password,
                input_username	= req.body.username;

            //console.log( md5( 'req.query.password' ) );
            //check if session already exists in cookeis
            if ( req.body.loginPassword != null ) {
                input_password	= req.body.loginPassword;
                input_username	= req.body.loginUsername;
            };
            if ( input_username ) {
                var promise =  User
                    .find({ where: {username: input_username, password: md5(input_password) } })

                promise.complete(
                    function onGoUser(err,user){
                        var return_val = {msg: 'error'};
                        if (!!err) {
                            var msg  = '/api/login An error occurred while searching for users: '
                            return_val = { msg: msg , success: false};
                            console.log(msg, err   );
                        }
                        else if( user ) {



                            var session_key = md5(input_username + new Date().getTime());

                            user.updateAttributes({
                                lastlogindate 	: new Date().getTime(),
                                lastloginip		: req.headers["X-Forwarded-For"] || req.ip
                            });

                            // create session if dne
                            sess.key = session_key;
                            sess.username = input_username;
                            sess.user_id = user.id;



                            //client service can use this session key to verify
                            res.cookie('filehosting',session_key, { maxAge: 900000});




                            return_val =  { msg: 'success', success:true, key:session_key, user_id:user.id };

                            sess.accountExpired = false; //Is some other cod setting this value?
                            // sess.accountExpired = 5;
                            //resetting it here to be safe


                            var unlimitedLevels = ['free user', 'admin']
                            if (unlimitedLevels.indexOf(user.dataValues.level) == -1) {
                                //asdf.g
                                var time = user.paidExpiryDate
                                var time = user.dataValues.paidExpiryDate
                                var currentTime = new Date()
                                if (currentTime.getTime() > time.getTime() ) {
                                    sess.accountExpired = true;
                                    return_val.accountExpired = true;
                                }
                            }

                           // var FileStore   = require('session-file-store')(session);

                            sess.save(function (err){
                                console.log('saved session complete', err)
                                console.log(self.FileStore)

                            });

                            /*var y = self.fileStore.get(sess.id, function (session_stored) {
                                console.log('got it back', ses.id, session_stored)
                            })*/

                            var sessionData = {username:input_username, user_id:user.id};
                            sessionData.account_expired = sess.accountExpired;

                            console.error('>>>','store session id', session_key)
                            self.db.Session
                                .findOrCreate({
                                    where:{
                                        id: session_key,
                                        data: JSON.stringify(sessionData)
                                    }
                                }).then(
                                function postAction_UserLoginAction(ee, oo) {





                                    function convertParamsToObject(x) {
                                        if ( x == null ) {
                                            return {};
                                        }
                                        var  query = x;
                                        if (x.indexOf('?')  != -1 ) {
                                            query = x.split('?')[1];//[1];
                                        }

                                        var query_string = {};
                                        var vars = query.split("&");
                                        for (var i=0;i<vars.length;i++) {
                                            var pair = vars[i].split("=");
                                            // If first entry with this name
                                            if (typeof query_string[pair[0]] === "undefined") {
                                                query_string[pair[0]] = decodeURIComponent(pair[1]);
                                                // If second entry with this name
                                            } else if (typeof query_string[pair[0]] === "string") {
                                                var arr = [ query_string[pair[0]],decodeURIComponent(pair[1]) ];
                                                query_string[pair[0]] = arr;
                                                // If third or later entry with this name
                                            } else {
                                                query_string[pair[0]].push(decodeURIComponent(pair[1]));
                                            }
                                        }
                                        return query_string;
                                    }
                                    //uncomment to test parasing
                                    //req.body.params = '#asdf?asdf=3&y=4&fff=222&redirectTest=456';
                                    var params = convertParamsToObject(req.body.params)

                                    var filteredParams = {};

                                    sh.each(params, function filterForParams(i,x){
                                        if (i.indexOf('redirect')!= -1 ) {
                                            var kWithoutRedirectPrepended = i.replace('redirect', '');
                                            kWithoutRedirectPrepended = kWithoutRedirectPrepended.slice(0,1).toLowerCase()
                                                + kWithoutRedirectPrepended.slice(1)
                                            filteredParams[kWithoutRedirectPrepended] = x;
                                        }
                                    })
                                    var qs = require('qs')
                                    var str= qs.stringify(filteredParams)
                                    //  console.error('s' ,str, params, filteredParams, str)

                                    if ( req.body.testMode = 'textModeX') { //only allow testing clients to hit route
                                        rh.validateOrigins(req, res, true)
                                    }

                                    if ( return_val.success == true ) {
                                        if ( req.body.redirect != null ) {
                                            res.redirect('/index.html?'+str)
                                            return;
                                        }
                                    }

                                    res.json( return_val );



                                }
                            );

                        }

                        else {
                            return_val = {msg: 'no user found', success: false}
                            res.json( return_val );
                            return;
                        }



                    });
            }

            else{
                res.json( { msg:'no info supplied' } );
            }
            //check upsername / password combo

            //res.json({login:'not implemented'});
            return true;
        });
        router.post('/api/verify', function verifyOnUserSession(req, res){


            var sessionKey 	= self.pullSessionIDFromRequest( req, true );
            console.log('Producer: api verify', req.originalUrl, sessionKey)
            if( sessionKey == null ) {
                //TODO: send failure response failure be here?
                var return_val = { msg: 'no session found (null)', success:false }
                res.json( return_val );
                return;
            }
            self.db.Session
                .find({ where: {id: sessionKey} })
                .complete(function(err,session){
                    var return_val = {msg: 'error'};

                    if (!!err) {
                        return_val = { msg: 'An error occurred while search for users: ', success: false };
                        console.error('--------------------An error occurred while search for users: ' , err   );
                        // asdf.g
                    }
                    else if( session ){
                        var session_data 		= JSON.parse(session.get('data'));
                        var    session_key 		= session.get('id'),
                            session_username 	= session_data.username,
                            session_user_id		= session_data.user_id;

                        return_val =  { msg:'success', success:true,
                            key: session_key, username: session_username, user_id: session_user_id,
                            account_expired: session_data.account_expired
                        } ;

                        return_val['account_expired'] = session_data.account_expired;
                    }
                    else{
                        return_val = { msg: 'no session found', success:false }
                    }
                    res.json( return_val );
                })


        });
        /*router.route('/login').post(function(){ // domain/api/medialookup:id
         );*/

        router.get('/api/logout', function logout(req,res){ // domain/api/medialookup:id
            if ( req.session != null  ) {

                self.db.Session
                    .destroy({
                        where:{
                            id: req.session.key
                        }
                    });
                req.session.destroy();
            }

            //delete from database?
            console.log(  "someone is logging out");
            res.json( {success:true } );
        });

        /**
         * Used for external consumers
         * TODO:fix after you refactor this class to
         * refer to self
         * @type {{}}
         */
        _self.settings.wrapper = {};
        _self.settings.wrapper.destroySession = function destroySession(req) {
            if ( req.session != null  ) {

                self.db.Session
                    .destroy({
                        where:{
                            id: req.session.key
                        }
                    });
                req.session.destroy();
            }
        }

        router.post('/api/test', function testRoute(req,res) {
            console.log('---test route');
            //var debugApp = app
            console.log('---expires', req.session.cookie.maxAge/1000);
            res.json( {success:true, test:'test route'} );

        });

    };




    function defineUtils() {
        self.utils = {};
        self.pullSessionIDFromRequest = function pullSessionIDFromRequest(req, useQuery){
            var sessionId_cookie 	= (typeof req.cookie !== 'undefined')? req.cookie.key : undefined,
                sessionId_querystr 	=  (typeof req.query !== 'undefined')? req.query.key : undefined,
                sessionId_session 	= (typeof req.session !== 'undefined')?  req.session.key : undefined ;
            if( useQuery )
                return sessionId_session || sessionId_cookie || sessionId_querystr;
            else
                return sessionId_session || sessionId_cookie;
        }

        /**
         * Used by middleware. Restricts public access to login and verify
         * @param req
         * @returns {boolean}
         */
        self.isUserLoggedIn = function isUserLoggedIn( req ){
            //return;

            if ( req.originalUrl.indexOf('/api/login') != -1 ){
                return true;
            };
            if ( req.originalUrl.indexOf('/api/verify') != -1 ){
                return true;
            };
            console.error('user session id', req.session.id)
            if ( req.session.key != null ){
                return true;
            }

            return false;
        }

        //define Testing objects
        /**
         * Enables consumer services scripts to quicly make users to test functionality.
         */
        self.utils.createTestingAPI = function defineTestingAPI(api){
            var testAPI = {}
            api.test = testAPI;
            testAPI.createUser = function createUser(userP, cb){
                var user = self.db.User.build(userP)

                user.password = md5(user.password);
                user.save()
                    .complete(function(err) {
                        if (!!err) {
                            console.log('The instance has not been saved:', err)
                            throw err
                        } else {
                            console.log('We have a persisted instance now')
                            cb()
                        }
                    })

                return
            }

            testAPI.getUser = function getUser(username, cb){
                var promise =  self.db.User
                    .find({ where: {username: username } })

                promise.complete(
                    function(err,user) {
                        // var return_val = {msg: 'error'};
                        //var return_val = {msg: 'error'};
                        if (!!err) {
                            //return_val = { msg: 'An error occurred while searching for users: ' , success: false};
                            console.log('An error occurred while search for users: ' , err   );
                        }

                        if( user ) {
                            if ( cb ) cb(user.dataValues)
                        } else {
                            if ( cb ) cb(null)
                        }

                    })
                return
            }


            testAPI.deleteUser = function deleteUser(userP, cb){
                console.error('delete username?', userP.username)
                var promise =  self.db.User
                    .find({ where: {username: userP.username } })

                promise.complete(
                    function(err,user) {

                        // var return_val = {msg: 'error'};
                        if (!!err) {
                            // return_val = { msg: 'An error occurred while searching for users: ' , success: false};
                            console.log('An error occurred while search for users: ' , err   );
                        }
                        else if( user ) {
                            user.destroy();
                        }
                        console.info(2, 'delete username?', userP.username, user==null, err)
                        if ( cb ) cb()

                    })
                return
            }


            testAPI.countUsers = function countUsers( cb){
                var promise =  self.db.User
                    .count({ where: { } })

                promise.complete(
                    function(err,count) {
                        if (!!err) {
                            // return_val = { msg: 'An error occurred while searching for users: ' , success: false};
                            console.log('An error occurred while search for users: ' , err   );
                        }


                        if ( cb ) cb(count)

                    })
                return
            }
        }



    }

    defineUtils();
}



module.exports = CredentialServerAPI;