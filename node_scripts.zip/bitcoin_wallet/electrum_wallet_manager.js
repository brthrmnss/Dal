/**
 * Created by user on 3/12/16.
 * 2 concerns:
 *
 * 1. make wallet if exists
 * 2. thorw if can't list balance
 */

var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');
var rh = require('rhelpers');
var ElectrumAutomator =
    rh.loadJSScript('bitcoinorder_server2/electrum_wallet/ElectrumAutomator.js')
        .ElectrumAutomator;

var PromiseHelperV3 = shelpers.PromiseHelperV3;

function ElectrumWalletManager() {
    var p = ElectrumWalletManager.prototype;
    p = this;
    var self = this;
    p.init = function init() {
        var settings = rh.loadRServerConfig(true);
        self.settings = settings;
        self.testWallet();
    }

    p.testWallet = function testWallet() {
        var token = {};

        var chain = new PromiseHelperV3();
        token.silentToken = true
        chain.wait = token.simulate == false;
        chain.startChain(token)

        function createWalletObj() {
            chain.add(function getRequest() {
                var wallet = new ElectrumAutomator();
                wallet.init();
                self.wallet = wallet;
                var fileWallet = '';

                var isWalletDirDefined = !sh.str.isBlank(self.settings.electrum.wallet_dir != null)
                if ( isWalletDirDefined ) {

                } else {
                    fileWallet = rh.getPath('bitcoin_wallet/wallet')
                }

                self.wallet.settings.fileWallet = fileWallet;
                if ( sh.fs.fileExists(fileWallet) ) {
                        chain.cb();
                } else {
                    self.wallet.createWallet(fileWallet, function onCmdRun(data) {
                        chain.cb();
                    });
                }

            })
        }
        createWalletObj();


        function getBalance(amount, exp, memo) { //address
            chain.add(function getRequest() {
                self.wallet.settings.fileWallet = 'xsdf' //fail fail
                self.wallet.getBalance( function onCmdRun(address, data) {
                    chain.cb();
                }, function onFailed() {
                    console.error('failed to get  balance on wallet wallet ... ')
                    process.exit();
                });
            })
        }
        getBalance(  );


        //wallet.getBalance();
    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return;
        };
        sh.sLog(arguments)
    };

}

exports.ElectrumWalletManager = ElectrumWalletManager;
exports.SSSD = ElectrumWalletManager;

if (module.parent == null) {
    var e = new ElectrumWalletManager();
    e.init();
}



